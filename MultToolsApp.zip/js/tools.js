/**
 * This file serves as a "database" for all the tools available on the site.
 * The 'category' property is used to construct the file path for dynamic module loading.
 * The 'export' keyword makes this array available to other modules.
 */
export const tools = [
     // Image & Media Tools (11)
    { id: 'image-converter', title: 'Image Converter', description: 'Convert images between JPG, PNG, and WebP formats.', category: 'image' },
    { id: 'image-compressor', title: 'Image Compressor', description: 'Reduce image file size with adjustable quality.', category: 'image' },
    { id: 'image-cropper', title: 'Image Cropper', description: 'Upload, select an area, and crop your images.', category: 'image' },
    // { id: 'image-resizer', title: 'Image Resizer', description: 'Resize image dimensions with aspect ratio lock.', category: 'image' },
    { id: 'image-rotator', title: 'Image Rotator', description: 'Rotate images by 90 or -90 degrees.', category: 'image' },
    { id: 'image-grayscale-converter', title: 'Grayscale Converter', description: 'Convert any color image to black and white.', category: 'image' },
    { id: 'image-flip-mirror-tool', title: 'Image Flip & Mirror', description: 'Flip images horizontally or vertically.', category: 'image' },
    { id: 'image-watermark-adder', title: 'Image Watermark Adder', description: 'Add a text watermark to your images.', category: 'image' },
    { id: 'webp-to-png-converter', title: 'WebP to PNG Converter', description: 'Quickly convert WebP images to the PNG format.', category: 'image' },
    { id: 'image-previewer', title: 'Image Previewer', description: 'Preview an image instantly before uploading.', category: 'image' },
   // { id: 'video-thumbnail-generator', title: 'Thumbnail Generator', description: 'Generate a thumbnail image from a video file.', category: 'image' },

    // Audio & Video Tools (8)
    { id: 'video-converter', title: 'Video Converter', description: 'Re-encode video files into the WebM format.', category: 'audio' },
    { id: 'audio-converter', title: 'Audio Converter', description: 'Convert audio to WAV format.', category: 'audio' },
    { id: 'audio-trimmer', title: 'Audio Trimmer', description: 'Trim audio files by start and end times.', category: 'audio' },
    { id: 'video-mute-tool', title: 'Video Mute Tool', description: 'Remove the audio track from a video file.', category: 'audio' },
    { id: 'audio-volume-booster', title: 'Audio Volume Booster', description: 'Increase the volume of your audio files.', category: 'audio' },
    { id: 'video-speed-controller', title: 'Video Speed Controller', description: 'Change the playback speed of a video.', category: 'audio' },
    { id: 'screen-recorder-tool', title: 'Screen Recorder', description: 'Record your screen with optional audio.', category: 'audio' },
    { id: 'live-audio-recorder', title: 'Live Audio Recorder', description: 'Record audio directly from your microphone.', category: 'audio' },
    
    // Calculator Tools (7)
    { id: 'age-calculator', title: 'Age Calculator', description: 'Calculate exact age from a date of birth.', category: 'calculators' },
    { id: 'emi-calculator', title: 'EMI Calculator', description: 'Calculate your Equated Monthly Installment for loans.', category: 'calculators' },
    { id: 'sip-calculator', title: 'SIP Calculator', description: 'Estimate the future value of your SIP investments.', category: 'calculators' },
    { id: 'bmi-calculator', title: 'BMI Calculator', description: 'Calculate your Body Mass Index (BMI).', category: 'calculators' },
    { id: 'discount-calculator', title: 'Discount Calculator', description: 'Calculate the final price after a discount.', category: 'calculators' },
    { id: 'percentage-calculator', title: 'Percentage Calculator', description: 'Perform various percentage calculations.', category: 'calculators' },
    { id: 'gst-calculator', title: 'GST Calculator', description: 'Calculate Goods and Services Tax (India).', category: 'calculators' },

    // Generator Tools (5)
    { id: 'qr-code-generator', title: 'QR Code Generator', description: 'Generate a downloadable QR code from any text or URL.', category: 'generators' },
    { id: 'password-generator', title: 'Password Generator', description: 'Create strong, secure passwords with options.', category: 'generators' },
    { id: 'dummy-text-generator', title: 'Lorem Ipsum Generator', description: 'Generate placeholder "Lorem Ipsum" text.', category: 'generators' },
    { id: 'hash-generator', title: 'Hash Generator', description: 'Generate SHA-256 and MD5 hashes from text.', category: 'generators' },
    { id: 'uuid-generator', title: 'UUID Generator', description: 'Generate universally unique identifiers (UUIDs).', category: 'generators' },
     {  id: 'meta-tag-generator',   title: 'Meta Tag Generator',    description: 'Create SEO-friendly meta tags for your website pages.',   category: 'generators'     },

    // Text & Data Tools (6)
    { id: 'word-counter', title: 'Word Counter', description: 'Live count of words, characters, and sentences.', category: 'text' },
    { id: 'base64-tool', title: 'Base64 Encoder/Decoder', description: 'Encode to Base64 or decode from Base64.', category: 'text' },
    { id: 'json-formatter', title: 'JSON Formatter', description: 'Format and validate your JSON data.', category: 'text' },
   /*  { id: 'case-converter', title: 'Case Converter', description: 'Convert text to various cases (UPPER, lower, etc).', category: 'text' },
    { id: 'text-reverser', title: 'Text Reverser', description: 'Reverse the characters in your text.', category: 'text' },
    { id: 'palindrome-checker', title: 'Palindrome Checker', description: 'Check if a word or phrase is a palindrome.', category: 'text' },
     */
    // Math Tools (5)
   /*  { id: 'prime-number-checker', title: 'Prime Number Checker', description: 'Check if a number is prime.', category: 'math' },
    { id: 'number-to-words-converter', title: 'Number to Words', description: 'Convert a number into its word representation.', category: 'math' },
    { id: 'roman-numeral-converter', title: 'Roman Numeral Converter', description: 'Convert between numbers and Roman numerals.', category: 'math' },
    { id: 'percentage-change-calculator', title: 'Percentage Change Calc', description: 'Calculate % change between two values.', category: 'math' },
    { id: 'statistics-calculator', title: 'Statistics Calculator', description: 'Calculate mean, median, and mode.', category: 'math' },
 */
    // Conversion Tools (7)
   /*  { id: 'unit-converter', title: 'Unit Converter', description: 'Convert between various units of measurement.', category: 'conversion' },
    { id: 'timestamp-converter', title: 'Timestamp Converter', description: 'Convert between Unix and human-readable dates.', category: 'conversion' },
    { id: 'base-converter', title: 'Base Converter', description: 'Convert numbers between binary, decimal, and hex.', category: 'conversion' },
    { id: 'csv-to-json-converter', title: 'CSV to JSON Converter', description: 'Convert CSV data to JSON format.', category: 'conversion' },
    { id: 'json-to-csv-converter', title: 'JSON to CSV Converter', description: 'Convert JSON data to CSV format.', category: 'conversion' },
    { id: 'markdown-editor-previewer', title: 'Markdown Editor', description: 'Write and preview Markdown in real-time.', category: 'conversion' },
    { id: 'url-encoder-decoder', title: 'URL Encoder/Decoder', description: 'Encode or decode URL components.', category: 'conversion' },
 */
    // Web API & Device Tools (7)
    { id: 'text-to-speech', title: 'Text to Speech', description: 'Convert text into natural-sounding speech.', category: 'web-apis' },
    { id: 'speech-to-text', title: 'Speech to Text', description: 'Use your mic to convert spoken words into text.', category: 'web-apis' },
    
    { id: 'battery-status-checker', title: 'Battery Status Checker', description: 'Check the battery status of your device.', category: 'web-apis' },
    { id: 'geolocation-viewer', title: 'Geolocation Viewer', description: 'View your current location on a map.', category: 'web-apis' },
    { id: 'device-info-viewer', title: 'Device Info Viewer', description: 'View your user agent, resolution, and more.', category: 'web-apis' },
   
    
    
];