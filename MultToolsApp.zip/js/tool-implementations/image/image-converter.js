// This module provides the functionality for the Image Converter tool.
import { downloadBlob } from '../../utils.js';

/**
 * Initializes the Image Converter tool UI and logic.
 * @param {HTMLElement} container - The container element to populate with the tool's UI.
 */
export function init(container) {
    // The UI is now cloned from a <template> in index.html, so we just add event listeners.
     const fileInput = container.querySelector('#img-conv-input');
    const formatSelect = container.querySelector('#img-conv-format');
    const convertBtn = container.querySelector('#img-conv-btn');

    convertBtn.addEventListener('click', () => {
        if (!fileInput.files.length) {
            alert('Please upload an image first.');
            return;
        }

        const file = fileInput.files[0];
        const reader = new FileReader();

        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                canvas.width = img.width;
                canvas.height = img.height;
                canvas.getContext('2d').drawImage(img, 0, 0);

                const format = formatSelect.value;
                const newFileName = file.name.split('.').slice(0, -1).join('.') + '.' + format.split('/')[1];
                
                canvas.toBlob((blob) => {
                    // Use the shared utility function to download the result
                    downloadBlob(blob, newFileName);
                }, format, 0.95);
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
}