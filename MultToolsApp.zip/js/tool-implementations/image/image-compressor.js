import { downloadBlob } from '../../utils.js';
export function init(container) {
    const fileInput = container.querySelector('#img-comp-input');
    const qualitySlider = container.querySelector('#img-comp-quality');
    const compressBtn = container.querySelector('#img-comp-btn');
    const infoDiv = container.querySelector('#img-comp-output');
    compressBtn.addEventListener('click', () => {
        if (!fileInput.files.length) return alert('Please upload an image.');
        const file = fileInput.files[0];
        const quality = parseFloat(qualitySlider.value);
        infoDiv.textContent = 'Compressing...';
        const reader = new FileReader();
        reader.onload = e => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                canvas.width = img.width;
                canvas.height = img.height;
                canvas.getContext('2d').drawImage(img, 0, 0);
                canvas.toBlob(blob => {
                    const oSize = (file.size / 1024).toFixed(2);
                    const nSize = (blob.size / 1024).toFixed(2);
                    infoDiv.innerHTML = `Original: <strong>${oSize} KB</strong> | Compressed: <strong>${nSize} KB</strong> | Reduction: <strong>${((1 - nSize / oSize) * 100).toFixed(1)}%</strong>`;
                    downloadBlob(blob, `compressed-${file.name.replace(/\.[^/.]+$/, "")}.jpg`, 'image/jpeg', quality);
                }, 'image/jpeg', quality);
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
}