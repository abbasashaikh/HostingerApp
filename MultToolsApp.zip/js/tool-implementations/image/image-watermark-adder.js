import { downloadBlob } from '../../utils.js';
export function init(container) {
    const fileInput = container.querySelector('#wm-file-input');
    const textInput = container.querySelector('#wm-text-input');
    const addBtn = container.querySelector('#wm-btn');
    addBtn.addEventListener('click', () => {
        if (!fileInput.files.length) return alert('Please upload an image.');
        const text = textInput.value;
        if (!text) return alert('Please enter watermark text.');
        const reader = new FileReader();
        reader.onload = e => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                canvas.width = img.width;
                canvas.height = img.height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0);
                const fontSize = Math.floor(canvas.width / 20);
                ctx.font = `bold ${fontSize}px Arial`;
                ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText(text, canvas.width / 2, canvas.height / 2);
                canvas.toBlob(blob => downloadBlob(blob, 'watermarked.png'));
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(fileInput.files[0]);
    });
}