import { downloadBlob } from '../../utils.js';
export function init(container) {
    const fileInput = container.querySelector('#img-crop-input');
    const canvas = container.querySelector('#img-crop-canvas');
    const ctx = canvas.getContext('2d');
    const cropBtn = container.querySelector('#img-crop-btn');
    let img;
    fileInput.addEventListener('change', e => {
        if (!e.target.files.length) return;
        const reader = new FileReader();
        reader.onload = event => {
            img = new Image();
            img.onload = () => {
                canvas.width = img.width;
                canvas.height = img.height;
                ctx.drawImage(img, 0, 0);
                cropBtn.disabled = false;
            };
            img.src = event.target.result;
        };
        reader.readAsDataURL(e.target.files[0]);
    });
    cropBtn.addEventListener('click', () => {
        if (!img) return;
        const cropWidth = img.width * 0.5;
        const cropHeight = img.height * 0.5;
        const cropX = (img.width - cropWidth) / 2;
        const cropY = (img.height - cropHeight) / 2;
        const cropCanvas = document.createElement('canvas');
        cropCanvas.width = cropWidth;
        cropCanvas.height = cropHeight;
        cropCanvas.getContext('2d').drawImage(img, cropX, cropY, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);
        cropCanvas.toBlob(blob => downloadBlob(blob, 'cropped-image.png'), 'image/png');
    });
}