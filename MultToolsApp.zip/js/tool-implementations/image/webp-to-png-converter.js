import { downloadBlob } from '../../utils.js';
export function init(container) {
    const fileInput = container.querySelector('#webp-input');
    const convertBtn = container.querySelector('#webp-btn');
    convertBtn.addEventListener('click', () => {
        if (!fileInput.files.length) return alert('Please upload a WebP image.');
        const file = fileInput.files[0];
        if (file.type !== 'image/webp') return alert('Uploaded file is not a WebP image.');
        const reader = new FileReader();
        reader.onload = e => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                canvas.width = img.width;
                canvas.height = img.height;
                canvas.getContext('2d').drawImage(img, 0, 0);
                canvas.toBlob(blob => downloadBlob(blob, file.name.replace(/\.webp$/i, ".png")), "image/png");
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
}