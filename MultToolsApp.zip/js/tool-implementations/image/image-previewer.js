export function init(container) {
    const fileInput = container.querySelector('input');
    const imgPreview = container.querySelector('img');
    fileInput.addEventListener('change', e => {
        if (e.target.files && e.target.files[0]) {
            imgPreview.src = URL.createObjectURL(e.target.files[0]);
            imgPreview.style.display = 'block';
        }
    });
}