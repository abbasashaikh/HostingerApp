import { downloadBlob } from '../../utils.js';
export function init(container) {
    const fileInput = container.querySelector('#gray-input');
    const canvas = container.querySelector('#gray-canvas');
    const ctx = canvas.getContext('2d');
    const convertBtn = container.querySelector('#gray-btn');
    convertBtn.addEventListener('click', () => {
        if (!fileInput.files.length) return alert('Please upload an image.');
        const reader = new FileReader();
        reader.onload = event => {
            const img = new Image();
            img.onload = () => {
                canvas.width = img.width;
                canvas.height = img.height;
                ctx.drawImage(img, 0, 0);
                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                const data = imageData.data;
                for (let i = 0; i < data.length; i += 4) {
                    const avg = (data[i] + data[i + 1] + data[i + 2]) / 3;
                    data[i] = avg;     // red
                    data[i + 1] = avg; // green
                    data[i + 2] = avg; // blue
                }
                ctx.putImageData(imageData, 0, 0);
                downloadBlob(canvas.toDataURL(), 'grayscale.png');
            };
            img.src = event.target.result;
        };
        reader.readAsDataURL(fileInput.files[0]);
    });
}