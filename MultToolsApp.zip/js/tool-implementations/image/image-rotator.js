import { downloadBlob } from '../../utils.js';
export function init(container) {
    const fileInput = container.querySelector('input');
    const canvas = container.querySelector('canvas');
    const ctx = canvas.getContext('2d');
    let img;
    fileInput.addEventListener('change', e => {
        if (!e.target.files.length) return;
        const reader = new FileReader();
        reader.onload = event => {
            img = new Image();
            img.onload = () => {
                canvas.width = img.width;
                canvas.height = img.height;
                ctx.drawImage(img, 0, 0);
            };
            img.src = event.target.result;
        };
        reader.readAsDataURL(e.target.files[0]);
    });
    container.querySelectorAll('button').forEach(button => {
        button.addEventListener('click', () => {
            if (!img) return alert('Please upload an image.');
            const angle = parseInt(button.dataset.angle);
            const rad = angle * Math.PI / 180;
            const ow = img.width;
            const oh = img.height;
            canvas.width = Math.abs(ow * Math.cos(rad)) + Math.abs(oh * Math.sin(rad));
            canvas.height = Math.abs(ow * Math.sin(rad)) + Math.abs(oh * Math.cos(rad));
            ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.rotate(rad);
            ctx.drawImage(img, -ow / 2, -oh / 2);
            ctx.setTransform(1, 0, 0, 1, 0, 0); // reset transform
            downloadBlob(canvas.toDataURL(), `rotated-${angle}deg.png`);
        });
    });
}