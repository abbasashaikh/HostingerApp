import { downloadBlob } from '../../utils.js';
export function init(container) {
    const fileInput = container.querySelector('#flip-input');
    const canvas = container.querySelector('#flip-canvas');
    const ctx = canvas.getContext('2d');
    let img;
    fileInput.addEventListener('change', e => {
        if (!e.target.files.length) return;
        const reader = new FileReader();
        reader.onload = event => {
            img = new Image();
            img.onload = () => {
                canvas.width = img.width;
                canvas.height = img.height;
                ctx.drawImage(img, 0, 0);
            };
            img.src = event.target.result;
        };
        reader.readAsDataURL(e.target.files[0]);
    });
    container.querySelectorAll('button').forEach(button => {
        button.addEventListener('click', () => {
            if (!img) return alert('Please upload an image.');
            const w = canvas.width;
            const h = canvas.height;
            ctx.clearRect(0, 0, w, h);
            ctx.save();
            if (button.dataset.flip === 'horizontal') {
                ctx.translate(w, 0);
                ctx.scale(-1, 1);
            } else {
                ctx.translate(0, h);
                ctx.scale(1, -1);
            }
            ctx.drawImage(img, 0, 0);
            ctx.restore();
            downloadBlob(canvas.toDataURL(), 'flipped.png');
        });
    });
}