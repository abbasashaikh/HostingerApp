import { downloadBlob } from '../../utils.js';
export function init(container) {
    const fileInput = container.querySelector('#thumb-vid-input');
    const timeInput = container.querySelector('#thumb-time-input');
    const genBtn = container.querySelector('#thumb-btn');
    const canvas = container.querySelector('#thumb-canvas');
    genBtn.addEventListener('click', () => {
        if (!fileInput.files.length) return alert('Please select a video file.');
        const file = fileInput.files[0];
        const videoURL = URL.createObjectURL(file);
        const video = document.createElement('video');
        video.src = videoURL;
        video.addEventListener('loadedmetadata', () => {
            video.currentTime = parseFloat(timeInput.value) || 1;
        });
        video.addEventListener('seeked', () => {
            const ctx = canvas.getContext('2d');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            downloadBlob(canvas.toDataURL('image/jpeg'), 'thumbnail.jpg');
            URL.revokeObjectURL(videoURL);
        });
    });
}