import { downloadBlob, bufferToWave } from '../../utils.js';
export function init(container) {
    const fileInput = container.querySelector('#aud-conv-input');
    const convertBtn = container.querySelector('#aud-conv-btn');
    const statusDiv = container.querySelector('#aud-conv-output');
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    convertBtn.addEventListener('click', async () => {
        if (!fileInput.files.length) return alert('Please select an audio file.');
        const file = fileInput.files[0];
        statusDiv.textContent = 'Processing...';
        try {
            const arrayBuffer = await file.arrayBuffer();
            const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
            const wavBlob = bufferToWave(audioBuffer);
            downloadBlob(wavBlob, file.name.split('.')[0] + '.wav');
            statusDiv.textContent = 'WAV conversion complete!';
        } catch (error) {
            statusDiv.textContent = 'Error processing audio file.';
        }
    });
}