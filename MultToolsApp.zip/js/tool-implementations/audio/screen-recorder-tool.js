import { downloadBlob } from '../../utils.js';
export function init(container) {
    const startBtn = container.querySelector('#screen-rec-start');
    const stopBtn = container.querySelector('#screen-rec-stop');
    const statusDiv = container.querySelector('#screen-rec-output');
    let mediaRecorder, chunks = [];
    startBtn.addEventListener('click', async () => {
        statusDiv.textContent = 'Requesting permission...';
        try {
            const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
            mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
            mediaRecorder.ondataavailable = e => chunks.push(e.data);
            mediaRecorder.onstop = () => {
                const blob = new Blob(chunks, { type: 'video/webm' });
                downloadBlob(blob, 'screen-recording.webm');
                chunks = [];
                statusDiv.textContent = 'Recording stopped. Download started.';
                stream.getTracks().forEach(track => track.stop());
            };
            mediaRecorder.start();
            startBtn.disabled = true;
            stopBtn.disabled = false;
            statusDiv.textContent = 'Recording screen...';
        } catch (err) {
            statusDiv.textContent = 'Error: Could not start screen recording.';
        }
    });
    stopBtn.addEventListener('click', () => {
        if (mediaRecorder && mediaRecorder.state === 'recording') {
            mediaRecorder.stop();
            startBtn.disabled = false;
            stopBtn.disabled = true;
        }
    });
}