import { downloadBlob } from '../../utils.js';
export function init(container) {
    const fileInput = container.querySelector('#vid-conv-input');
    const convertBtn = container.querySelector('#vid-conv-btn');
    const statusDiv = container.querySelector('#vid-conv-output');
    convertBtn.addEventListener('click', () => {
        if (!fileInput.files.length) return alert('Please select a video file.');
        const file = fileInput.files[0];
        const url = URL.createObjectURL(file);
        const video = document.createElement('video');
        video.src = url;
        video.muted = true;
        video.onloadedmetadata = () => {
            video.play();
            const stream = video.captureStream();
            const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
            const chunks = [];
            recorder.ondataavailable = e => chunks.push(e.data);
            recorder.onstart = () => statusDiv.textContent = 'Converting...';
            recorder.onstop = () => {
                const blob = new Blob(chunks, { type: 'video/webm' });
                downloadBlob(blob, file.name.split('.')[0] + '.webm');
                statusDiv.textContent = 'Conversion complete!';
                video.pause();
                URL.revokeObjectURL(url);
            };
            recorder.start();
            video.onended = () => recorder.stop();
        };
    });
}