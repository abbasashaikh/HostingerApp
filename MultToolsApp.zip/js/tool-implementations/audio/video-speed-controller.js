export function init(container) {
    const fileInput = container.querySelector('#vid-speed-input');
    const speedSelect = container.querySelector('#vid-speed-select');
    const videoPlayer = container.querySelector('#vid-speed-player');
    fileInput.addEventListener('change', e => {
        if (!e.target.files.length) return;
        const fileURL = URL.createObjectURL(e.target.files[0]);
        videoPlayer.src = fileURL;
    });
    speedSelect.addEventListener('change', () => {
        videoPlayer.playbackRate = parseFloat(speedSelect.value);
    });
}