import { downloadBlob } from '../../utils.js';
export function init(container) {
    const startBtn = container.querySelector('#aud-rec-start');
    const stopBtn = container.querySelector('#aud-rec-stop');
    const statusDiv = container.querySelector('#aud-rec-output');
    let mediaRecorder, chunks = [];
    startBtn.addEventListener('click', async () => {
        statusDiv.textContent = 'Requesting permission...';
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorder = new MediaRecorder(stream);
            mediaRecorder.ondataavailable = e => chunks.push(e.data);
            mediaRecorder.onstop = () => {
                const blob = new Blob(chunks, { type: 'audio/webm' });
                downloadBlob(blob, 'audio-recording.webm');
                chunks = [];
                statusDiv.textContent = 'Recording stopped. Download started.';
                stream.getTracks().forEach(track => track.stop());
            };
            mediaRecorder.start();
            startBtn.disabled = true;
            stopBtn.disabled = false;
            statusDiv.textContent = 'Recording...';
        } catch (err) {
            statusDiv.textContent = 'Error: Could not access microphone.';
        }
    });
    stopBtn.addEventListener('click', () => {
        if (mediaRecorder && mediaRecorder.state === 'recording') {
            mediaRecorder.stop();
            startBtn.disabled = false;
            stopBtn.disabled = true;
        }
    });
}