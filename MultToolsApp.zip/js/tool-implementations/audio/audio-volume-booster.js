import { downloadBlob, bufferToWave } from '../../utils.js';
export function init(container) {
    const fileInput = container.querySelector('#vol-boost-input');
    const volumeSlider = container.querySelector('#vol-boost-slider');
    const boostBtn = container.querySelector('#vol-boost-btn');
    const statusDiv = container.querySelector('#vol-boost-output');
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    boostBtn.addEventListener('click', async () => {
        if (!fileInput.files.length) return alert('Please upload an audio file.');
        statusDiv.textContent = 'Boosting...';
        const file = fileInput.files[0];
        const gainValue = parseFloat(volumeSlider.value);
        const arrayBuffer = await file.arrayBuffer();
        const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
        const newBuffer = audioCtx.createBuffer(audioBuffer.numberOfChannels, audioBuffer.length, audioBuffer.sampleRate);
        for (let i = 0; i < audioBuffer.numberOfChannels; i++) {
            const inputData = audioBuffer.getChannelData(i);
            const outputData = newBuffer.getChannelData(i);
            for (let sample = 0; sample < inputData.length; sample++) {
                outputData[sample] = inputData[sample] * gainValue;
            }
        }
        const wavBlob = bufferToWave(newBuffer);
        downloadBlob(wavBlob, `boosted-${file.name}`);
        statusDiv.textContent = 'Volume boosted successfully!';
    });
}