import { downloadBlob } from '../../utils.js';
export function init(container) {
    const fileInput = container.querySelector('#vid-mute-input');
    const muteBtn = container.querySelector('#vid-mute-btn');
    const statusDiv = container.querySelector('#vid-mute-output');
    muteBtn.addEventListener('click', () => {
        if (!fileInput.files.length) return alert('Please select a video file.');
        const file = fileInput.files[0];
        statusDiv.textContent = 'Processing...';
        const videoURL = URL.createObjectURL(file);
        const video = document.createElement('video');
        video.src = videoURL;
        video.onloadedmetadata = () => {
            const stream = video.captureStream();
            const videoTrack = stream.getVideoTracks()[0];
            const mutedStream = new MediaStream([videoTrack]);
            const recorder = new MediaRecorder(mutedStream, { mimeType: 'video/webm' });
            const chunks = [];
            recorder.ondataavailable = e => chunks.push(e.data);
            recorder.onstop = () => {
                const blob = new Blob(chunks, { type: 'video/webm' });
                downloadBlob(blob, `muted-${file.name.split('.')[0]}.webm`);
                statusDiv.textContent = 'Muting complete!';
                URL.revokeObjectURL(videoURL);
            };
            recorder.start();
            setTimeout(() => recorder.stop(), (video.duration + 1) * 1000);
        };
    });
}