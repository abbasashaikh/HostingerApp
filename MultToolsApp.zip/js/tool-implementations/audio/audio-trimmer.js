import { downloadBlob, bufferToWave } from '../../utils.js';
export function init(container) {
    const fileInput = container.querySelector('#aud-trim-input');
    const startInput = container.querySelector('#aud-trim-start');
    const endInput = container.querySelector('#aud-trim-end');
    const trimBtn = container.querySelector('#aud-trim-btn');
    const infoDiv = container.querySelector('#aud-trim-output');
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    let mainAudioBuffer;
    fileInput.addEventListener('change', async e => {
        if (!e.target.files.length) return;
        const file = e.target.files[0];
        infoDiv.textContent = 'Loading audio...';
        const arrayBuffer = await file.arrayBuffer();
        mainAudioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
        endInput.value = mainAudioBuffer.duration.toFixed(2);
        infoDiv.textContent = `Audio loaded. Duration: ${mainAudioBuffer.duration.toFixed(2)}s`;
    });
    trimBtn.addEventListener('click', () => {
        if (!mainAudioBuffer) return alert('Please load an audio file.');
        const startTime = parseFloat(startInput.value);
        const endTime = parseFloat(endInput.value);
        if (startTime >= endTime || endTime > mainAudioBuffer.duration) return alert('Invalid start or end time.');
        const startOffset = Math.floor(startTime * mainAudioBuffer.sampleRate);
        const endOffset = Math.floor(endTime * mainAudioBuffer.sampleRate);
        const frameCount = endOffset - startOffset;
        const newBuffer = audioCtx.createBuffer(mainAudioBuffer.numberOfChannels, frameCount, mainAudioBuffer.sampleRate);
        for (let i = 0; i < mainAudioBuffer.numberOfChannels; i++) {
            newBuffer.getChannelData(i).set(mainAudioBuffer.getChannelData(i).subarray(startOffset, endOffset));
        }
        const wavBlob = bufferToWave(newBuffer);
        downloadBlob(wavBlob, 'trimmed-audio.wav');
    });
}