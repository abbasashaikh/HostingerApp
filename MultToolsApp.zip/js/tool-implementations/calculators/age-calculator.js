export function init(container) {
    const dobInput = container.querySelector('#age-dob-input');
    const calcBtn = container.querySelector('#age-calc-btn');
    const outputBox = container.querySelector('#age-output');

    calcBtn.addEventListener('click', () => {
        const dobString = dobInput.value;
        if (!dobString) {
            outputBox.textContent = 'Please enter your date of birth.';
            return;
        }
        const dob = new Date(dobString);
        const today = new Date();
        if (dob > today) {
            outputBox.textContent = 'Date of birth cannot be in the future.';
            return;
        }

        let years = today.getFullYear() - dob.getFullYear();
        let months = today.getMonth() - dob.getMonth();
        let days = today.getDate() - dob.getDate();

        if (days < 0) {
            months--;
            days += new Date(today.getFullYear(), today.getMonth(), 0).getDate();
        }
        if (months < 0) {
            years--;
            months += 12;
        }
        outputBox.textContent = `You are ${years} years, ${months} months, and ${days} days old.`;
    });
}