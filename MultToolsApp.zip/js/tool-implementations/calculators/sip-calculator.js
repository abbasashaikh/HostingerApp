export function init(container) {
    const monthlyInput = container.querySelector('#sip-monthly');
    const rateInput = container.querySelector('#sip-rate');
    const tenureInput = container.querySelector('#sip-tenure');
    const calcBtn = container.querySelector('#sip-calc-btn');
    const outputBox = container.querySelector('#sip-output');

    calcBtn.addEventListener('click', () => {
        const P = parseFloat(monthlyInput.value);
        const annualRate = parseFloat(rateInput.value);
        const n_years = parseFloat(tenureInput.value);
        if (isNaN(P) || isNaN(annualRate) || isNaN(n_years) || P <= 0 || n_years <= 0) {
            outputBox.textContent = 'Please enter valid positive numbers for all fields.';
            return;
        }
        const i = (annualRate / 100) / 12;
        const n = n_years * 12;
        
        const M = P * ((Math.pow(1 + i, n) - 1) / i) * (1 + i);
        const totalInvested = P * n;
        const wealthGained = M - totalInvested;

        outputBox.innerHTML = `
            Total Invested: <strong>$${totalInvested.toFixed(2)}</strong><br>
            Wealth Gained: <strong style="color: var(--accent-cyan);">$${wealthGained.toFixed(2)}</strong><br>
            Estimated Future Value: <strong style="font-size: 1.2em;">$${M.toFixed(2)}</strong>
        `;
    });
}