export function init(container) {
    const priceInput = container.querySelector('#disc-price');
    const discountInput = container.querySelector('#disc-percent');
    const calcBtn = container.querySelector('#disc-calc-btn');
    const outputBox = container.querySelector('#disc-output');

    function calculate() {
        const price = parseFloat(priceInput.value);
        const discount = parseFloat(discountInput.value);
        if (isNaN(price) || isNaN(discount)) {
            outputBox.textContent = 'Please enter valid numbers.';
            return;
        }
        if (discount < 0 || discount > 100) {
            outputBox.textContent = 'Discount must be between 0 and 100.';
            return;
        }
        const amountSaved = price * (discount / 100);
        const finalPrice = price - amountSaved;
        outputBox.innerHTML = `
            Final Price: <strong style="font-size: 1.2em; color: var(--accent-cyan);">$${finalPrice.toFixed(2)}</strong><br>
            You Saved: <strong>$${amountSaved.toFixed(2)}</strong>
        `;
    }
    calcBtn.addEventListener('click', calculate);
    priceInput.addEventListener('input', calculate);
    discountInput.addEventListener('input', calculate);
    calculate();
}