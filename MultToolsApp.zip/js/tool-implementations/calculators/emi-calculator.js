export function init(container) {
    const principalInput = container.querySelector('#emi-principal');
    const rateInput = container.querySelector('#emi-rate');
    const tenureInput = container.querySelector('#emi-tenure');
    const calcBtn = container.querySelector('#emi-calc-btn');
    const outputBox = container.querySelector('#emi-output');

    calcBtn.addEventListener('click', () => {
        const P = parseFloat(principalInput.value);
        const annualRate = parseFloat(rateInput.value);
        const tenureYears = parseFloat(tenureInput.value);
        if (isNaN(P) || isNaN(annualRate) || isNaN(tenureYears) || P <= 0 || annualRate <= 0 || tenureYears <= 0) {
            outputBox.textContent = 'Please enter valid positive numbers for all fields.';
            return;
        }
        const R = (annualRate / 12) / 100;
        const N = tenureYears * 12;
        
        const EMI = (P * R * Math.pow(1 + R, N)) / (Math.pow(1 + R, N) - 1);
        const totalPayable = EMI * N;
        const totalInterest = totalPayable - P;

        outputBox.innerHTML = `
            Monthly EMI: <strong style="color: var(--accent-cyan);">$${EMI.toFixed(2)}</strong><br>
            Total Interest Payable: <strong>$${totalInterest.toFixed(2)}</strong><br>
            Total Payment (Principal + Interest): <strong>$${totalPayable.toFixed(2)}</strong>
        `;
    });
}