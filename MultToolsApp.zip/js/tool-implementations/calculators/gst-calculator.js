export function init(container) {
    const amountInput = container.querySelector('#gst-amount');
    const rateSelect = container.querySelector('#gst-rate');
    const calcBtn = container.querySelector('#gst-calc-btn');
    const outputBox = container.querySelector('#gst-output');

    function calculate() {
        const amount = parseFloat(amountInput.value);
        const rate = parseFloat(rateSelect.value);
        if (isNaN(amount)) {
            outputBox.textContent = 'Please enter a valid amount.';
            return;
        }
        const gstAmount = amount * (rate / 100);
        const totalAmount = amount + gstAmount;
        outputBox.innerHTML = `
            Base Amount: <strong>₹${amount.toFixed(2)}</strong><br>
            GST (${rate}%): <strong>₹${gstAmount.toFixed(2)}</strong><br>
            Total Amount (incl. GST): <strong style="color: var(--accent-cyan);">₹${totalAmount.toFixed(2)}</strong>
        `;
    }
    calcBtn.addEventListener('click', calculate);
    amountInput.addEventListener('input', calculate);
    rateSelect.addEventListener('change', calculate);
}