export function init(container) {
    const percentInput = container.querySelector('#perc-val1');
    const numInput = container.querySelector('#perc-val2');
    const calcBtn = container.querySelector('#perc-calc-btn');
    const outputBox = container.querySelector('#perc-output');

    function calculate() {
        const percent = parseFloat(percentInput.value);
        const num = parseFloat(numInput.value);
        if (isNaN(percent) || isNaN(num)) {
            outputBox.textContent = 'Enter numbers in both fields.';
            return;
        }
        const result = (percent / 100) * num;
        outputBox.innerHTML = `${percent}% of ${num} is <strong style="color: var(--accent-cyan);">${result.toLocaleString()}</strong>`;
    }
    calcBtn.addEventListener('click', calculate);
    percentInput.addEventListener('input', calculate);
    numInput.addEventListener('input', calculate);
}