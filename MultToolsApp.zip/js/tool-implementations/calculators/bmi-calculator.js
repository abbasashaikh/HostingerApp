export function init(container) {
    const weightInput = container.querySelector('#bmi-weight');
    const heightInput = container.querySelector('#bmi-height');
    const calcBtn = container.querySelector('#bmi-calc-btn');
    const outputBox = container.querySelector('#bmi-output');

    calcBtn.addEventListener('click', () => {
        const weight = parseFloat(weightInput.value);
        const height = parseFloat(heightInput.value);
        if (isNaN(weight) || isNaN(height) || weight <= 0 || height <= 0) {
            outputBox.textContent = 'Please enter a valid positive weight and height.';
            return;
        }
        const heightInMeters = height / 100;
        const bmi = weight / (heightInMeters * heightInMeters);
        let category = '';
        let color = 'var(--accent-cyan)';

        if (bmi < 18.5) { category = 'Underweight'; color = '#3498db'; }
        else if (bmi < 24.9) { category = 'Normal weight'; color = '#2ecc71'; }
        else if (bmi < 29.9) { category = 'Overweight'; color = '#f1c40f'; }
        else { category = 'Obesity'; color = '#e74c3c'; }
        
        outputBox.innerHTML = `
            Your BMI is: <strong style="font-size: 1.5em;">${bmi.toFixed(2)}</strong><br>
            Category: <strong style="color: ${color};">${category}</strong>
        `;
    });
}