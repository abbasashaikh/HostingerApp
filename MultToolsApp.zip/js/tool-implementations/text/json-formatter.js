/**
 * Initializes the JSON Formatter and Validator tool.
 */
export function init(container) {
    const input = container.querySelector('#json-input');
    const formatBtn = container.querySelector('#json-format-btn');
    const output = container.querySelector('#json-output');

    formatBtn.addEventListener('click', () => {
        const jsonString = input.value.trim();
        if (!jsonString) {
            output.textContent = 'Please paste your JSON data.';
            return;
        }

        try {
            // Attempt to parse the string into a JavaScript object.
            const jsonObj = JSON.parse(jsonString);
            
            // Re-stringify it with an indentation of 2 spaces for "pretty printing".
            output.textContent = JSON.stringify(jsonObj, null, 2);
            output.style.color = 'var(--accent-cyan)'; // Use a success color
        } catch (e) {
            // If JSON.parse fails, it's invalid JSON. Display the error message.
            output.textContent = `Invalid JSON: ${e.message}`;
            output.style.color = '#FF5C5C'; // Use a distinct error color
        }
    });
}