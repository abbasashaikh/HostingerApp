/**
 * Initializes the Word Counter tool.
 * Provides a real-time count of words, characters, and sentences.
 */
export function init(container) {
    const textInput = container.querySelector('#wc-input');
    const outputBox = container.querySelector('#wc-output');

    function updateCounts() {
        const text = textInput.value;

        // Count characters (including spaces)
        const charCount = text.length;

        // Count words by splitting by whitespace. Filter out empty strings that can result from multiple spaces.
        const words = text.trim().split(/\s+/).filter(word => word.length > 0);
        const wordCount = words.length === 1 && words[0] === '' ? 0 : words.length;

        // Count sentences by looking for sentence-ending punctuation.
        const sentenceCount = (text.match(/[.!?…]+(\s|$)/g) || []).length;

        // Update the display
        outputBox.innerHTML = `
            Words: <strong style="color: var(--accent-cyan);">${wordCount}</strong> | 
            Characters: <strong style="color: var(--accent-cyan);">${charCount}</strong> | 
            Sentences: <strong style="color: var(--accent-cyan);">${sentenceCount}</strong>
        `;
    }

    // Add an event listener to update counts as the user types.
    textInput.addEventListener('input', updateCounts);

    // Initial count when the tool is opened.
    updateCounts();
}