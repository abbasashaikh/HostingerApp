/**
 * Initializes the Base64 Encoder/Decoder tool.
 * Handles UTF-8 characters correctly during encoding and decoding.
 */
export function init(container) {
    const input = container.querySelector('#b64-input');
    const output = container.querySelector('#b64-output');
    const encodeBtn = container.querySelector('[data-action="encode"]');
    const decodeBtn = container.querySelector('[data-action="decode"]');

    encodeBtn.addEventListener('click', () => {
        try {
            // btoa can fail on non-latin characters. This two-step process handles UTF-8 correctly.
            const utf8Encoded = unescape(encodeURIComponent(input.value));
            output.textContent = btoa(utf8Encoded);
            output.style.color = 'var(--text-color)';
        } catch (e) {
            output.textContent = 'Error: Could not encode text. ' + e.message;
            output.style.color = '#FF5C5C';
        }
    });

    decodeBtn.addEventListener('click', () => {
        try {
            // The reverse process for handling UTF-8 characters from a Base64 string.
            const utf8Decoded = atob(input.value);
            output.textContent = decodeURIComponent(escape(utf8Decoded));
            output.style.color = 'var(--text-color)';
        } catch (e) {
            output.textContent = 'Error: Invalid Base64 string. ' + e.message;
            output.style.color = '#FF5C5C';
        }
    });
}