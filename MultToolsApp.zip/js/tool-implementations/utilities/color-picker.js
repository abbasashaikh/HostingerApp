// This module provides color picking and value conversion functionality.
import { hexToRgb, rgbToHsl } from '../../utils.js';

/**
 * Initializes the Color Picker tool UI and logic.
 * @param {HTMLElement} container - The container element to populate with the tool's UI.
 */
export function init(container) {
    const colorInput = container.querySelector('#color-input');
    const valuesBox = container.querySelector('#color-values');
    
    function updateValues() {
        const hex = colorInput.value.toUpperCase();
        const rgb = hexToRgb(hex);
        const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
        
        valuesBox.innerHTML = `
            HEX: <strong>${hex}</strong><br>
            RGB: <strong>rgb(${rgb.r}, ${rgb.g}, ${rgb.b})</strong><br>
            HSL: <strong>hsl(${hsl.h}, ${hsl.s}%, ${hsl.l}%)</strong>
        `;
    }
    
    colorInput.addEventListener('input', updateValues);
    updateValues(); // Initial call to display default color values
}