/**
 * Initializes the Unit Converter tool.
 * Handles conversions for length, weight, and temperature with special logic for temperature.
 */
export function init(container) {
    // Data structure defining conversion factors relative to a base unit (e.g., meter, kilogram).
    const categories = {
        length: {
            meter: 1,
            kilometer: 1000,
            centimeter: 0.01,
            millimeter: 0.001,
            mile: 1609.34,
            foot: 0.3048,
            inch: 0.0254
        },
        weight: {
            kilogram: 1,
            gram: 0.001,
            milligram: 0.000001,
            pound: 0.453592,
            ounce: 0.0283495
        },
        temperature: { // Temperature uses formulas, not factors, so values are just identifiers.
            celsius: 'c',
            fahrenheit: 'f',
            kelvin: 'k'
        }
    };

    // --- DOM Elements ---
    const categorySelect = container.querySelector('#unit-category');
    const fromSelect = container.querySelector('#unit-from');
    const toSelect = container.querySelector('#unit-to');
    const input = container.querySelector('#unit-input');
    const output = container.querySelector('.output-box');

    // --- Functions ---
    function populateCategories() {
        categorySelect.innerHTML = Object.keys(categories).map(cat => `<option value="${cat}">${cat.charAt(0).toUpperCase() + cat.slice(1)}</option>`).join('');
        populateUnits(); // Initial population of unit dropdowns
    }

    function populateUnits() {
        const category = categorySelect.value;
        const units = Object.keys(categories[category]);
        fromSelect.innerHTML = units.map(u => `<option value="${u}">${u}</option>`).join('');
        toSelect.innerHTML = units.map(u => `<option value="${u}">${u}</option>`).join('');
        toSelect.selectedIndex = 1; // Default to a different unit
        convert(); // Perform initial conversion
    }

    function convert() {
        const category = categorySelect.value;
        const fromUnit = fromSelect.value;
        const toUnit = toSelect.value;
        const inputValue = parseFloat(input.value);

        if (isNaN(inputValue)) {
            output.textContent = '';
            return;
        }
        
        let result;
        if (category === 'temperature') {
            // Temperature requires specific formulas.
            if (fromUnit === toUnit) result = inputValue;
            else if (fromUnit === 'celsius' && toUnit === 'fahrenheit') result = (inputValue * 9/5) + 32;
            else if (fromUnit === 'fahrenheit' && toUnit === 'celsius') result = (inputValue - 32) * 5/9;
            else if (fromUnit === 'celsius' && toUnit === 'kelvin') result = inputValue + 273.15;
            else if (fromUnit === 'kelvin' && toUnit === 'celsius') result = inputValue - 273.15;
            else if (fromUnit === 'fahrenheit' && toUnit === 'kelvin') result = (inputValue - 32) * 5/9 + 273.15;
            else if (fromUnit === 'kelvin' && toUnit === 'fahrenheit') result = (inputValue - 273.15) * 9/5 + 32;
        } else {
            // Other units use a factor-based conversion.
            const fromFactor = categories[category][fromUnit];
            const toFactor = categories[category][toUnit];
            result = inputValue * fromFactor / toFactor;
        }
        
        // Display the result with a reasonable number of decimal places.
        output.textContent = result.toFixed(5).replace(/\.?0+$/, "");
    }

    // --- Event Listeners ---
    categorySelect.addEventListener('change', populateUnits);
    input.addEventListener('input', convert);
    fromSelect.addEventListener('change', convert);
    toSelect.addEventListener('change', convert);

    // --- Initial Setup ---
    populateCategories();
}