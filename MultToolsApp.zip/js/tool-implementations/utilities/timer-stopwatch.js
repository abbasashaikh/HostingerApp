/**
 * Initializes the Timer and Stopwatch tool.
 * Manages separate intervals for the countdown timer and the stopwatch.
 */
export function init(container) {
    // --- State Variables ---
    let timerInterval = null;
    let stopwatchInterval = null;
    let timerSeconds = 0;
    let stopwatchSeconds = 0;

    // --- DOM Elements ---
    const timerInput = container.querySelector('#timer-input');
    const timerDisplay = container.querySelector('[data-type="timer"]');
    const stopwatchDisplay = container.querySelector('[data-type="stopwatch"]');

    // --- Timer Logic ---
    function formatTime(totalSeconds) {
        const mins = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
        const secs = (totalSeconds % 60).toString().padStart(2, '0');
        return `${mins}:${secs}`;
    }

    function startTimer() {
        clearInterval(timerInterval); // Clear any existing timer
        timerSeconds = parseInt(timerInput.value);
        if (isNaN(timerSeconds) || timerSeconds <= 0) {
            alert('Please enter a valid number of seconds.');
            return;
        }
        timerDisplay.textContent = formatTime(timerSeconds);
        timerInterval = setInterval(() => {
            timerSeconds--;
            timerDisplay.textContent = formatTime(timerSeconds);
            if (timerSeconds <= 0) {
                clearInterval(timerInterval);
                timerDisplay.style.color = 'var(--accent-cyan)';
                alert('Timer Finished!');
            }
        }, 1000);
    }

    function resetTimer() {
        clearInterval(timerInterval);
        timerInput.value = '';
        timerDisplay.textContent = '00:00';
        timerDisplay.style.color = 'var(--text-color)';
    }

    // --- Stopwatch Logic ---
    function formatStopwatch(totalSeconds) {
        const hours = Math.floor(totalSeconds / 3600).toString().padStart(2, '0');
        const mins = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, '0');
        const secs = (totalSeconds % 60).toString().padStart(2, '0');
        return `${hours}:${mins}:${secs}`;
    }

    function startStopwatch() {
        clearInterval(stopwatchInterval); // Clear if already running
        const startTime = Date.now() - (stopwatchSeconds * 1000); // Resume from where it was stopped
        stopwatchInterval = setInterval(() => {
            stopwatchSeconds = Math.floor((Date.now() - startTime) / 1000);
            stopwatchDisplay.textContent = formatStopwatch(stopwatchSeconds);
        }, 100); // Update frequently for a responsive feel
    }
    
    function stopStopwatch() {
         clearInterval(stopwatchInterval);
    }

    function resetStopwatch() {
        clearInterval(stopwatchInterval);
        stopwatchSeconds = 0;
        stopwatchDisplay.textContent = '00:00:00';
    }
    
    // --- Event Listeners ---
    container.querySelector('[data-action="timer-start"]').addEventListener('click', startTimer);
    container.querySelector('[data-action="timer-reset"]').addEventListener('click', resetTimer);
    container.querySelector('[data-action="stopwatch-start"]').addEventListener('click', startStopwatch);
    container.querySelector('[data-action="stopwatch-stop"]').addEventListener('click', stopStopwatch);
    container.querySelector('[data-action="stopwatch-reset"]').addEventListener('click', resetStopwatch);
}