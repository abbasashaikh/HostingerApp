/**
 * Initializes the UUID Generator tool.
 * Uses the native Web Crypto API to generate version 4 UUIDs.
 */
export function init(container) {
    const generateBtn = container.querySelector('#uuid-btn');
    const outputBox = container.querySelector('#uuid-output');

    function generate() {
        // crypto.randomUUID() is a modern, secure way to generate UUIDs.
        outputBox.textContent = crypto.randomUUID();
    }

    generateBtn.addEventListener('click', generate);

    // Generate a UUID immediately when the tool is opened.
    generate();
}