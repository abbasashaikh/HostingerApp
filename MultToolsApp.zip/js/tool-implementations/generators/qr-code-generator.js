/**
 * Initializes the QR Code Generator tool.
 * Uses a free public API to generate QR code images from user input.
 */
export function init(container) {
    const textInput = container.querySelector('#qr-text');
    const generateBtn = container.querySelector('#qr-btn');
    const outputDiv = container.querySelector('#qr-output');

    generateBtn.addEventListener('click', () => {
        const text = textInput.value.trim();
        if (!text) {
            alert('Please enter text or a URL to generate a QR code.');
            return;
        }

        // Display a loading message while the image is being fetched.
        outputDiv.innerHTML = 'Generating...';
        
        // Construct the URL for the qrserver.com API.
        const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(text)}`;
        
        // Create an image element and a download link.
        outputDiv.innerHTML = `
            <img src="${qrApiUrl}" alt="Generated QR Code" style="border: 5px solid var(--border-color); border-radius: 8px;">
            <br><br>
            <a href="${qrApiUrl}&download=1" download="qrcode.png" class="tool-btn">Download QR Code</a>
        `;
    });
}