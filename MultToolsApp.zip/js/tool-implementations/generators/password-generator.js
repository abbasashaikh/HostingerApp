/**
 * Initializes the Password Generator tool.
 * Creates secure, random passwords with customizable options.
 */
export function init(container) {
    const lengthSlider = container.querySelector('#pass-len-slider');
    const lengthValueSpan = container.querySelector('#pass-len-val');
    const numbersCheckbox = container.querySelector('#pass-inc-nums');
    const symbolsCheckbox = container.querySelector('#pass-inc-syms');
    const generateBtn = container.querySelector('#pass-gen-btn');
    const outputBox = container.querySelector('#pass-output');

    // Update the length display when the slider is moved.
    lengthSlider.addEventListener('input', () => {
        lengthValueSpan.textContent = lengthSlider.value;
    });

    generateBtn.addEventListener('click', () => {
        const length = parseInt(lengthSlider.value);
        const includeNumbers = numbersCheckbox.checked;
        const includeSymbols = symbolsCheckbox.checked;

        const lowerChars = 'abcdefghijklmnopqrstuvwxyz';
        const upperChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const numberChars = '0123456789';
        const symbolChars = '!@#$%^&*()_+~`|}{[]:;?><,./-=';

        // Build the character set based on user options.
        let charset = lowerChars + upperChars;
        if (includeNumbers) charset += numberChars;
        if (includeSymbols) charset += symbolChars;

        let password = '';
        for (let i = 0; i < length; i++) {
            const randomIndex = Math.floor(Math.random() * charset.length);
            password += charset.charAt(randomIndex);
        }

        outputBox.textContent = password;
        outputBox.title = "Click to copy!"; // Update title for user feedback
    });

    // Add click-to-copy functionality to the output box.
    outputBox.addEventListener('click', () => {
        if (outputBox.textContent) {
            navigator.clipboard.writeText(outputBox.textContent)
                .then(() => {
                    alert('Password copied to clipboard!');
                })
                .catch(err => {
                    console.error('Failed to copy password: ', err);
                });
        }
    });

    // Generate a password on initial load.
    generateBtn.click();
}