/**
 * Initializes the Lorem Ipsum (Dummy Text) Generator tool.
 */
export function init(container) {
    const countInput = container.querySelector('#lorem-count');
    const generateBtn = container.querySelector('#lorem-btn');
    const outputDiv = container.querySelector('#lorem-output');

    // A standard Lorem Ipsum paragraph.
    const loremParagraph = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";

    function generateText() {
        const count = parseInt(countInput.value);
        if (isNaN(count) || count < 1) {
            outputDiv.innerHTML = '<p>Please enter a valid number of paragraphs.</p>';
            return;
        }

        // Build the HTML by repeating the paragraph tag.
        let resultHTML = '';
        for (let i = 0; i < count; i++) {
            resultHTML += `<p style="margin-bottom: 1rem;">${loremParagraph}</p>`;
        }
        outputDiv.innerHTML = resultHTML;
    }

    generateBtn.addEventListener('click', generateText);
    
    // Generate text immediately when the tool is opened.
    generateText();
}