/**
 * @file Implements the Geolocation Viewer tool.
 * This tool uses the `navigator.geolocation` API to request the user's
 * current position and displays the coordinates. It includes robust error handling.
 */

/**
 * Initializes the Geolocation Viewer.
 * @param {HTMLElement} container - The container element for the tool's UI.
 */
export function init(container) {
    const getBtn = container.querySelector('button');
    const outputBox = container.querySelector('.output-box');

    getBtn.addEventListener('click', () => {
        // Check if the Geolocation API is available on the browser
        if (!navigator.geolocation) {
            outputBox.textContent = 'Geolocation is not supported by your browser.';
            return;
        }

        outputBox.textContent = 'Requesting location... Please approve the browser prompt.';

        // The API takes a success callback and an error callback
        navigator.geolocation.getCurrentPosition(handleSuccess, handleError);
    });

    /**
     * Handles the successful retrieval of the user's position.
     * @param {GeolocationPosition} position - The position object returned by the API.
     */
    function handleSuccess(position) {
        const { latitude, longitude, accuracy } = position.coords;

        // Create a link to view the location on Google Maps
        const mapLink = `https://www.google.com/maps?q=${latitude},${longitude}`;

        outputBox.innerHTML = `
            <ul>
                <li><strong>Latitude:</strong> ${latitude.toFixed(6)}</li>
                <li><strong>Longitude:</strong> ${longitude.toFixed(6)}</li>
                <li><strong>Accuracy:</strong> Approximately ${accuracy.toFixed(0)} meters</li>
            </ul>
            <a href="${mapLink}" target="_blank" rel="noopener noreferrer" class="tool-btn" style="display:inline-block; margin-top:1rem;">View on Google Maps</a>
        `;
    }

    /**
     * Handles errors that occur during location retrieval.
     * @param {GeolocationPositionError} error - The error object returned by the API.
     */
    function handleError(error) {
        let errorMessage = 'An unknown error occurred.';
        switch (error.code) {
            case error.PERMISSION_DENIED:
                errorMessage = 'Permission to access location was denied.';
                break;
            case error.POSITION_UNAVAILABLE:
                errorMessage = 'Location information is unavailable.';
                break;
            case error.TIMEOUT:
                errorMessage = 'The request to get user location timed out.';
                break;
        }
        outputBox.style.color = '#FF5C5C'; // Use an error color
        outputBox.textContent = `Error: ${errorMessage}`;
    }
}