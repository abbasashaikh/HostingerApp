export function init(container) {
    // HIGHLIGHT: Using specific IDs from the corrected template
    const textInput = container.querySelector('#tts-input');
    const voiceSelect = container.querySelector('#tts-voices');
    const speakBtn = container.querySelector('#tts-speak-btn');
    let voices = [];
    
    function populateVoiceList() {
        voices = speechSynthesis.getVoices();
        // This check prevents the error if voiceSelect is not found
        if (voiceSelect) {
            voiceSelect.innerHTML = voices
                .map(voice => `<option value="${voice.name}">${voice.name} (${voice.lang})</option>`)
                .join('');
        }
    }
    
    populateVoiceList();
    if (speechSynthesis.onvoiceschanged !== undefined) {
        speechSynthesis.onvoiceschanged = populateVoiceList;
    }
    
    speakBtn.addEventListener('click', () => {
        if (speechSynthesis.speaking) speechSynthesis.cancel();
        if (textInput.value) {
            const utterance = new SpeechSynthesisUtterance(textInput.value);
            utterance.voice = voices.find(voice => voice.name === voiceSelect.value);
            speechSynthesis.speak(utterance);
        }
    });
}