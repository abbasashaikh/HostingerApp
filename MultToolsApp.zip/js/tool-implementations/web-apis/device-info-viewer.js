/**
 * @file Implements the Device Info Viewer tool.
 * This tool uses the `navigator` and `screen` browser objects to display
 * information about the user's device and browser environment.
 */

/**
 * Initializes the Device Info Viewer.
 * @param {HTMLElement} container - The container element for the tool's UI.
 */
export function init(container) {
    const outputBox = container.querySelector('.output-box');

    // Gather all the device information.
    const info = {
        'User Agent': navigator.userAgent,
        'Screen Resolution': `${screen.width} x ${screen.height}`,
        'Viewport Size': `${window.innerWidth} x ${window.innerHeight}`,
        'Platform': navigator.platform,
        'Languages': navigator.languages.join(', '),
        'Online Status': navigator.onLine ? 'Online' : 'Offline',
        'Cookies Enabled': navigator.cookieEnabled ? 'Yes' : 'No',
        'CPU Cores': navigator.hardwareConcurrency ? `${navigator.hardwareConcurrency} cores` : 'Not Available',
    };

    // Format the information as a list of key-value pairs.
    let content = '<ul>';
    for (const [key, value] of Object.entries(info)) {
        content += `<li style="margin-bottom: 0.5rem;"><strong>${key}:</strong> <span style="color: var(--accent-cyan);">${value}</span></li>`;
    }
    content += '</ul>';

    // Display the formatted information.
    outputBox.innerHTML = content;
}