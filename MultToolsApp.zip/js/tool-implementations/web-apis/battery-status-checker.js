/**
 * @file Implements the Battery Status Checker tool.
 * This tool uses the asynchronous `navigator.getBattery()` API to provide
 * real-time updates on the device's battery level and charging status.
 */

/**
 * Initializes the Battery Status Checker.
 * @param {HTMLElement} container - The container element for the tool's UI.
 */
export function init(container) {
    const outputBox = container.querySelector('.output-box');

    // The Battery API is promise-based and might not be supported on all browsers.
    if ('getBattery' in navigator) {
        navigator.getBattery().then(battery => {
            /**
             * Updates the UI with the latest battery information.
             */
            function updateBatteryStatus() {
                const level = (battery.level * 100).toFixed(0);
                const isCharging = battery.charging ? 'Yes' : 'No';
                
                // Determine a color based on battery level for better UX
                let levelColor = 'var(--accent-cyan)';
                if (level <= 20) levelColor = '#FF5C5C'; // Red for low battery
                else if (level <= 50) levelColor = '#FFD700'; // Yellow for medium

                outputBox.innerHTML = `
                    <ul>
                        <li><strong>Status:</strong> <span style="color: var(--accent-cyan);">${battery.charging ? 'Charging' : 'Discharging'}</span></li>
                        <li><strong>Level:</strong> <strong style="font-size: 1.5em; color: ${levelColor};">${level}%</strong></li>
                        <li><strong>Plugged In:</strong> <span style="color: var(--accent-cyan);">${isCharging}</span></li>
                    </ul>
                `;
            }

            // Initial call to display status immediately
            updateBatteryStatus();

            // Set up event listeners to update the UI in real-time
            battery.addEventListener('chargingchange', updateBatteryStatus);
            battery.addEventListener('levelchange', updateBatteryStatus);
        });
    } else {
        // Handle cases where the browser does not support the Battery API
        outputBox.textContent = 'Battery Status API is not supported on this browser or device.';
    }
}