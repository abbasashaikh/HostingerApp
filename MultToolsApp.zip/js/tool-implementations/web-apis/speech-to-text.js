/**
 * Initializes the Speech to Text tool.
 * Utilizes the browser's Web Speech API for real-time voice transcription.
 */
export function init(container) {
    const startBtn = container.querySelector('#stt-start-btn');
    const stopBtn = container.querySelector('#stt-stop-btn');
    const outputBox = container.querySelector('#stt-output');

    // Check for browser support and handle vendor prefixes.
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    // If the API is not supported, disable the tool.
    if (!SpeechRecognition) {
        outputBox.textContent = 'Speech Recognition API is not supported in this browser. Please try Chrome or Edge.';
        startBtn.disabled = true;
        return;
    }

    const recognition = new SpeechRecognition();
    
    // Configure the recognition instance.
    recognition.continuous = true; // Keep listening even after a pause.
    recognition.interimResults = true; // Show results as they are being processed.
    recognition.lang = 'en-US'; // Set language.

    // --- Event Handlers for the Recognition API ---

    // This event fires every time the API has a new result.
    recognition.onresult = (event) => {
        let interimTranscript = '';
        let finalTranscript = '';

        // Iterate through all the results captured so far.
        for (let i = event.resultIndex; i < event.results.length; ++i) {
            // If the result is final, append it to the final transcript.
            if (event.results[i].isFinal) {
                finalTranscript += event.results[i][0].transcript;
            } else {
                // Otherwise, it's an interim (in-progress) result.
                interimTranscript += event.results[i][0].transcript;
            }
        }
        
        // Update the UI with both final and interim parts.
        // Final text is solid, interim is styled differently for user feedback.
        outputBox.innerHTML = `${finalTranscript}<em style="color: var(--accent-cyan);">${interimTranscript}</em>`;
    };

    // Handle errors, like permission denied.
    recognition.onerror = (event) => {
        outputBox.textContent = 'Error occurred in recognition: ' + event.error;
        startBtn.disabled = false;
        stopBtn.disabled = true;
    };

    // When recognition ends, reset the button states.
    recognition.onend = () => {
        startBtn.disabled = false;
        stopBtn.disabled = true;
    };

    // --- Button Event Listeners ---

    startBtn.addEventListener('click', () => {
        // Clear previous results and start listening.
        outputBox.innerHTML = '<em>Listening...</em>';
        recognition.start();
        startBtn.disabled = true;
        stopBtn.disabled = false;
    });

    stopBtn.addEventListener('click', () => {
        // Manually stop the recognition process.
        recognition.stop();
        startBtn.disabled = false;
        stopBtn.disabled = true;
    });
}