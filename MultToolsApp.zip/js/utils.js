/**
 * Triggers a browser download for a given Blob object.
 * This is a common utility for tools that generate files (images, audio, etc.).
 * @param {Blob} blob - The Blob data to download.
 * @param {string} filename - The desired name for the downloaded file.
 */
export function downloadBlob(blob, filename) {
    // Create a temporary URL for the blob data
    const url = URL.createObjectURL(blob);
    
    // Create a temporary anchor element to trigger the download
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    
    // Append, click, and then remove the anchor element
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    // Revoke the temporary URL to free up memory
    URL.revokeObjectURL(url);
}

/**
 * Converts a hex color string to an RGB object.
 * @param {string} hex - The hex color string (e.g., "#FFD700").
 * @returns {{r: number, g: number, b: number}} An object with r, g, b values from 0-255.
 */
export function hexToRgb(hex) {
    let r = 0, g = 0, b = 0;
    
    // Handle shorthand hex (e.g., #F0C)
    if (hex.length === 4) {
        r = parseInt(hex[1] + hex[1], 16);
        g = parseInt(hex[2] + hex[2], 16);
        b = parseInt(hex[3] + hex[3], 16);
    } 
    // Handle full hex (e.g., #FF00CC)
    else if (hex.length === 7) {
        r = parseInt(hex.substring(1, 3), 16);
        g = parseInt(hex.substring(3, 5), 16);
        b = parseInt(hex.substring(5, 7), 16);
    }
    
    return { r, g, b };
}

/**
 * Converts RGB color values to an HSL object.
 * @param {number} r - Red value (0-255).
 * @param {number} g - Green value (0-255).
 * @param {number} b - Blue value (0-255).
 * @returns {{h: number, s: number, l: number}} An object with hue (0-360), saturation (0-100), and lightness (0-100).
 */
export function rgbToHsl(r, g, b) {
    r /= 255;
    g /= 255;
    b /= 255;
    
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0, s, l = (max + min) / 2;

    if (max === min) {
        // achromatic
        h = s = 0;
    } else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r: h = (g - b) / d + (g < b ? 6 : 0); break;
            case g: h = (b - r) / d + 2; break;
            case b: h = (r - g) / d + 4; break;
        }
        h /= 6;
    }

    return {
        h: Math.round(h * 360),
        s: Math.round(s * 100),
        l: Math.round(l * 100)
    };
}

/**
 * Converts an AudioBuffer to a WAV file Blob.
 * This is a crucial utility for audio processing tools.
 * @param {AudioBuffer} abuffer - The AudioBuffer to convert.
 * @returns {Blob} A Blob object representing the WAV file.
 */
export function bufferToWave(abuffer) {
    const numOfChan = abuffer.numberOfChannels;
    const len = abuffer.length * numOfChan * 2 + 44;
    const buffer = new ArrayBuffer(len);
    const view = new DataView(buffer);
    const channels = [];
    let offset = 0;
    let pos = 0;

    // Helper functions for writing data to the view
    function setUint16(data) {
        view.setUint16(pos, data, true);
        pos += 2;
    }
    function setUint32(data) {
        view.setUint32(pos, data, true);
        pos += 4;
    }

    // Write WAV header
    setUint32(0x46464952); // "RIFF"
    setUint32(len - 8); // file length - 8
    setUint32(0x45564157); // "WAVE"
    setUint32(0x20746d66); // "fmt " chunk
    setUint32(16); // length of fmt data
    setUint16(1); // PCM - integer samples
    setUint16(numOfChan); // number of channels
    setUint32(abuffer.sampleRate); // samples per second
    setUint32(abuffer.sampleRate * 2 * numOfChan); // byte rate
    setUint16(numOfChan * 2); // block align
    setUint16(16); // bits per sample
    setUint32(0x61746164); // "data" chunk
    setUint32(len - pos - 4); // chunk length

    // Get channel data
    for (let i = 0; i < numOfChan; i++) {
        channels.push(abuffer.getChannelData(i));
    }

    // Write interleaved PCM data
    while (pos < len) {
        for (let i = 0; i < numOfChan; i++) {
            // Clamp and convert to 16-bit PCM
            const sample = Math.max(-1, Math.min(1, channels[i][offset] || 0));
            view.setInt16(pos, sample < 0 ? sample * 32768 : sample * 32767, true);
            pos += 2;
        }
        offset++;
    }

    return new Blob([view], { type: "audio/wav" });
}
/**
 * HIGHLIGHT: New reusable function to copy text to the clipboard.
 * Provides user feedback by temporarily changing the button's text.
 * @param {string} text - The text to be copied.
 * @param {HTMLElement} buttonElement - The button that was clicked.
 */
export function copyToClipboard(text, buttonElement) {
    if (!navigator.clipboard) {
        alert("Clipboard API not available in your browser.");
        return;
    }
    navigator.clipboard.writeText(text).then(() => {
        const originalText = buttonElement.innerHTML;
        buttonElement.innerHTML = `<i class="bi bi-check-lg"></i> Copied!`;
        buttonElement.style.backgroundColor = '#10B981'; // A success green
        setTimeout(() => {
            buttonElement.innerHTML = originalText;
            buttonElement.style.backgroundColor = ''; // Revert to original style
        }, 2000);
    }).catch(err => {
        console.error('Failed to copy text: ', err);
        alert("Failed to copy text.");
    });
}