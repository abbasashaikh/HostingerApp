/**
 * Main application script for Multi Tool Hub.
 * Handles: Navigation, Homepage Accordion, Modals, Search, and dynamic script loading.
 */
import { tools } from './tools.js';

document.addEventListener('DOMContentLoaded', () => {

    // --- CORE ELEMENTS & STATE ---
    const modal = document.getElementById('modal');
    const groupedByCategory = groupToolsByCategory();

    // --- INITIALIZATION ROUTER ---
    function initializePage() {
        if (document.getElementById('main-nav-menu')) {
            initNavigation();
        }
        if (document.getElementById('category-accordion')) {
            initHomePage();
        }
        if (modal) {
            initModalControls();
        }
    }

    // --- FEATURE IMPLEMENTATIONS ---

    function groupToolsByCategory() {
        return tools.reduce((acc, tool) => {
            const category = tool.category.charAt(0).toUpperCase() + tool.category.slice(1);
            if (!acc[category]) acc[category] = [];
            acc[category].push(tool);
            return acc;
        }, {});
    }

    function initNavigation() {
        const mainNavMenu = document.getElementById('main-nav-menu');
        const mobileNavToggle = document.querySelector('.mobile-nav-toggle');
        if (!mainNavMenu || mainNavMenu.querySelector('.dropdown')) return;

        const toolsLi = document.createElement('li');
        toolsLi.className = 'dropdown';
        toolsLi.innerHTML = `<a href="#">Tools <i class="bi bi-chevron-down" style="font-size: 0.7em;"></i></a>`;
        const toolsDropdown = document.createElement('ul');
        toolsDropdown.className = 'dropdown-menu';
        const sortedCategories = Object.keys(groupedByCategory).sort();

        for (const category of sortedCategories) {
            const categoryLi = document.createElement('li');
            categoryLi.className = 'dropdown';
            const categoryLink = document.createElement('a');
            categoryLink.href = `/?category=${category.toLowerCase()}`;
            categoryLink.className = 'nav-category-link';
            categoryLink.textContent = category;
            categoryLi.appendChild(categoryLink);
            const subDropdown = document.createElement('ul');
            subDropdown.className = 'dropdown-menu';
            groupedByCategory[category].forEach(tool => {
                const toolLi = document.createElement('li');
                toolLi.innerHTML = `<a href="#" class="tool-link" data-tool-id="${tool.id}">${tool.title}</a>`;
                subDropdown.appendChild(toolLi);
            });
            categoryLi.appendChild(subDropdown);
            toolsDropdown.appendChild(categoryLi);
        }
        toolsLi.appendChild(toolsDropdown);
        mainNavMenu.prepend(toolsLi);

        mainNavMenu.addEventListener('click', (e) => {
            if (e.target.classList.contains('tool-link')) {
                e.preventDefault();
                openTool(e.target.dataset.toolId);
                if (mainNavMenu.classList.contains('mobile-active')) mobileNavToggle.click();
            }
            if (e.target.classList.contains('nav-category-link')) {
                e.preventDefault();
                const categoryId = e.target.getAttribute('href').split('=')[1];
                const categoryElement = document.getElementById(`category-${categoryId}`);
                if (categoryElement) {
                    categoryElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    if (!categoryElement.classList.contains('active')) {
                        categoryElement.querySelector('.category-header').click();
                    }
                } else {
                    window.location.href = e.target.href;
                }
            }
        });
        
        if (mobileNavToggle) {
            mobileNavToggle.addEventListener('click', () => {
                const isActive = mainNavMenu.classList.toggle('mobile-active');
                mobileNavToggle.querySelector('i').className = isActive ? 'bi bi-x' : 'bi bi-list';
            });
        }
    }

    function initHomePage() {
        const accordionContainer = document.getElementById('category-accordion');
        const loader = document.getElementById('loader');
        const noResults = document.getElementById('no-results');
        const searchInput = document.getElementById('searchInput');

        function buildAccordionUI(filter = '') {
            accordionContainer.innerHTML = '';
            const lowerCaseFilter = filter.toLowerCase();
            const filteredCategories = Object.keys(groupedByCategory).filter(category => {
                if (!filter) return true;
                return category.toLowerCase().includes(lowerCaseFilter) || 
                       groupedByCategory[category].some(t => t.title.toLowerCase().includes(lowerCaseFilter));
            }).sort();

            if (filteredCategories.length === 0) {
                noResults.classList.remove('d-none');
                return;
            }
            noResults.classList.add('d-none');
            
            filteredCategories.forEach(category => {
                const group = document.createElement('div');
                group.className = 'category-group';
                group.id = `category-${category.toLowerCase()}`;
                const header = document.createElement('div');
                header.className = 'category-header';
                header.innerHTML = `<div><span class="category-title">${category}</span><span class="category-count">(${groupedByCategory[category].length} tools)</span></div><span class="category-toggle-icon">+</span>`;
                const cardContainer = document.createElement('div');
                cardContainer.className = 'tool-card-container';
                groupedByCategory[category].forEach(tool => {
                    const card = document.createElement('div');
                    card.className = 'tool-card';
                    card.innerHTML = `<h2>${tool.title}</h2><p>${tool.description}</p>`;
                    card.addEventListener('click', () => openTool(tool.id));
                    cardContainer.appendChild(card);
                });
                group.appendChild(header);
                group.appendChild(cardContainer);
                accordionContainer.appendChild(group);
                header.addEventListener('click', () => {
                    const isActive = group.classList.contains('active');
                    document.querySelectorAll('.category-group.active').forEach(openGroup => {
                         if(openGroup !== group) {
                            openGroup.classList.remove('active');
                            openGroup.querySelector('.tool-card-container').style.maxHeight = '0px';
                            openGroup.querySelector('.category-toggle-icon').style.transform = 'rotate(0deg)';
                         }
                    });
                    group.classList.toggle('active');
                    const icon = group.querySelector('.category-toggle-icon');
                    if (!isActive) {
                        icon.style.transform = 'rotate(45deg)';
                        cardContainer.style.maxHeight = cardContainer.scrollHeight + 'px';
                    } else {
                        icon.style.transform = 'rotate(0deg)';
                        cardContainer.style.maxHeight = '0px';
                    }
                });
            });
        }
        
        searchInput.addEventListener('keyup', (e) => buildAccordionUI(e.target.value));
        document.getElementById('searchButton').addEventListener('click', () => buildAccordionUI(searchInput.value));

        buildAccordionUI();
        if (loader) loader.style.display = 'none';

        const urlParams = new URLSearchParams(window.location.search);
        const categoryToOpen = urlParams.get('category');
        if(categoryToOpen) {
            setTimeout(() => {
                const categoryElement = document.getElementById(`category-${categoryToOpen}`);
                if (categoryElement && !categoryElement.classList.contains('active')) {
                    categoryElement.querySelector('.category-header').click();
                }
            }, 100);
        }
    }

    function initModalControls() {
        const closeModalBtn = modal.querySelector('.modal-close');
        closeModalBtn.addEventListener('click', closeModal);
    }
    
    async function openTool(toolId) {
        const tool = tools.find(t => t.id === toolId);
        if (!tool) { console.error(`Tool '${toolId}' not found.`); return; }
        modal.querySelector('#modal-title').textContent = tool.title;
        const body = modal.querySelector('#modal-body');
        body.innerHTML = '<div class="spinner"></div>';
        modal.style.display = 'block';
        
        const template = document.getElementById(`template-${toolId}`);
        if (!template) {
             body.innerHTML = `<p>Error: UI Template for '${toolId}' not found.</p>`;
             return;
        }
        
        body.innerHTML = '';
        body.appendChild(template.content.cloneNode(true));
        
        try {
            const toolModule = await import(`./tool-implementations/${tool.category}/${tool.id}.js`);
            if (toolModule.init) {
                toolModule.init(body);
            } else {
                console.warn(`Tool module for '${toolId}' does not export an 'init' function.`);
            }
        } catch (error) {
            console.error(`Failed to load script for tool '${toolId}':`, error);
            body.innerHTML += `<p style="color:#FF5C5C; margin-top:1rem;">Error: Could not load the logic for this tool.</p>`;
        }
    }
    
    function closeModal() {
        if (modal) modal.style.display = 'none';
    }

    initializePage();
});