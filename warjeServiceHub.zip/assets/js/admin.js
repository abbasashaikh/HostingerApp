document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const loginSection = document.getElementById('login-section');
    const dashboardSection = document.getElementById('dashboard-section');
    const loginForm = document.getElementById('loginForm');
    const logoutBtn = document.getElementById('logoutBtn');
    
    // Dashboard Containers & Forms
    const adminAccordion = document.querySelector('.admin-accordion');
    const categoryListContainer = document.getElementById('category-list');
    const addCategoryForm = document.getElementById('addCategoryForm');
    const pendingListingsContainer = document.getElementById('pending-listings');
    const approvedListingsBody = document.getElementById('approved-listings-table-body');
    
    // Action Buttons & Checkboxes
    const selectAllCheckbox = document.getElementById('selectAllCheckbox');
    const deleteSelectedBtn = document.getElementById('deleteSelectedBtn');
    
    // Message/Loader Elements
    const loginMessage = document.getElementById('login-message');

    // --- State ---
    let isLoggedIn = sessionStorage.getItem('adminLoggedIn') === 'true';

    // --- Main UI Controller ---
    const updateUI = () => {
        if (isLoggedIn) {
            loginSection.classList.add('d-none');
            dashboardSection.classList.remove('d-none');
            logoutBtn.classList.remove('d-none');
            loadDashboardData();
        } else {
            loginSection.classList.remove('d-none');
            dashboardSection.classList.add('d-none');
            logoutBtn.classList.add('d-none');
        }
    };

    // --- API & Rendering Functions ---
    const loadDashboardData = () => {
        fetchCategories();
        fetchListings('get_pending', pendingListingsContainer, false);
        fetchListings('get_approved', approvedListingsBody, true);
    };

    const fetchCategories = async () => {
        categoryListContainer.innerHTML = '<div class="text-center"><div class="spinner"></div></div>';
        try {
            const response = await fetch('/api/categories.php');
            const categories = await response.json();
            categoryListContainer.innerHTML = '';
            if (categories.length === 0) {
                 categoryListContainer.innerHTML = `<p class="text-center text-muted">No categories found. Add one below.</p>`;
            } else {
                categories.forEach(cat => {
                    const item = document.createElement('div');
                    item.className = 'list-group-item category-item d-flex justify-content-between align-items-center';
                    item.dataset.id = cat.id;
                    item.innerHTML = `<span>${cat.name}</span><button class="btn btn-sm btn-outline-danger delete-category-btn">×</button>`;
                    categoryListContainer.appendChild(item);
                });
            }
        } catch (error) {
            categoryListContainer.innerHTML = `<p class="text-danger">Could not load categories.</p>`;
        }
    };
    
    const fetchListings = async (action, container, isTable = false) => {
        container.innerHTML = `<div class="text-center"><div class="spinner"></div></div>`;
        try {
            const response = await fetch(`/api/admin.php?action=${action}`);
            if (!response.ok) throw new Error(`Network error while fetching ${action}`);
            const listings = await response.json();
            container.innerHTML = '';
            if (listings.length === 0) {
                const message = `<p class="text-center" style="color: rgba(234, 234, 234, 0.6);">No listings in this section.</p>`;
                container.innerHTML = isTable ? `<tr><td colspan="5">${message}</td></tr>` : message;
                return;
            }
            listings.forEach(listing => {
                const html = isTable ? createTableRowHTML(listing) : createListItemHTML(listing);
                container.insertAdjacentHTML('beforeend', html);
            });
        } catch (error) {
            const message = `<p class="text-danger text-center">${error.message}</p>`;
            container.innerHTML = isTable ? `<tr><td colspan="5">${message}</td></tr>` : message;
        }
    };

    const createListItemHTML = (listing) => {
        const approveButton = listing.status == 0 ? `<button class="btn btn-sm btn-success approve-btn">Approve</button>` : '';
        return `<div class="list-group-item listing-item" data-id="${listing.id}">
                    <div class="d-flex w-100 justify-content-between align-items-start">
                        <div>
                            <h5 class="mb-1">${listing.name} <small class="text-muted">(${listing.category})</small></h5>
                            <p class="mb-1">${listing.description}</p>
                            <small class="text-muted">${listing.area} | ${listing.phone}</small>
                        </div>
                        <div class="actions mt-2 text-end d-flex gap-2">
                            ${approveButton}
                            <button class="btn btn-sm btn-danger delete-btn">Delete</button>
                        </div>
                    </div>
                </div>`;
    };

    const createTableRowHTML = (listing) => {
        return `<tr class="listing-item" data-id="${listing.id}">
                    <td><input type="checkbox" class="listing-checkbox"></td>
                    <td>${listing.name}</td><td>${listing.category}</td><td>${listing.area}</td>
                    <td>
                        <button class="btn-sm btn-info update-btn" disabled>Update</button>
                        <button class="btn-sm btn-danger delete-btn">Delete</button>
                    </td>
                </tr>`;
    };
    
    const handleAdminAction = async (action, ids) => {
        const formData = new FormData();
        formData.append('action', action);
        formData.append('ids', JSON.stringify(ids));
        try {
            const response = await fetch('/api/admin.php', { method: 'POST', body: formData });
            const result = await response.json();
            if (result.success) {
                loadDashboardData();
                if(action.includes('delete')) {
                    updateDeleteSelectedButtonState();
                }
            } else {
                alert(`Action failed: ${result.message}`);
            }
        } catch (error) {
            alert('An error occurred: ' + error.message);
        }
    };

    const handleCategoryDelete = async (id) => {
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('id', id);
        try {
            const response = await fetch('/api/categories.php', { method: 'POST', body: formData });
            const result = await response.json();
            if (result.success) {
                fetchCategories();
            } else { alert('Error: ' + result.message); }
        } catch (error) { alert('An error occurred: ' + error.message); }
    };
    
    // --- Event Handlers ---

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const submitButton = loginForm.querySelector('button[type="submit"]');
        loginMessage.innerHTML = '';
        submitButton.disabled = true;
        submitButton.innerHTML = `Logging in...`;
        const formData = new FormData(loginForm);
        formData.append('action', 'login');
        try {
            const response = await fetch('/api/admin.php', { method: 'POST', body: formData });
            const result = await response.json();
            if (response.ok && result.success) {
                sessionStorage.setItem('adminLoggedIn', 'true');
                isLoggedIn = true;
                updateUI();
            } else { throw new Error(result.message || 'Invalid credentials'); }
        } catch (error) {
            loginMessage.innerHTML = `<div class="alert-danger">${error.message}</div>`;
        } finally {
            submitButton.disabled = false;
            submitButton.textContent = 'Login';
        }
    });

    logoutBtn.addEventListener('click', async () => {
        await fetch('/api/admin.php?action=logout');
        sessionStorage.removeItem('adminLoggedIn');
        isLoggedIn = false;
        window.location.reload();
    });
    
    addCategoryForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const input = addCategoryForm.querySelector('input');
        const categoryName = input.value.trim();
        if (!categoryName) return;
        const formData = new FormData();
        formData.append('action', 'add');
        formData.append('name', categoryName);
        try {
            const response = await fetch('/api/categories.php', { method: 'POST', body: formData });
            const result = await response.json();
            if (result.success) {
                input.value = '';
                fetchCategories();
            } else { alert('Error: ' + result.message); }
        } catch { alert('An error occurred while adding the category.'); }
    });

    // Accordion Logic
    if (adminAccordion) {
        adminAccordion.addEventListener('click', (e) => {
            const header = e.target.closest('.admin-accordion-header');
            if (!header) return;
            const item = header.parentElement;
            const content = header.nextElementSibling;
            const isActive = item.classList.contains('active');
            item.parentElement.querySelectorAll('.admin-accordion-item').forEach(openItem => {
                if (openItem !== item) {
                    openItem.classList.remove('active');
                    openItem.querySelector('.admin-accordion-content').style.maxHeight = null;
                    openItem.querySelector('.admin-accordion-header i').style.transform = 'rotate(0deg)';
                }
            });
            item.classList.toggle('active');
            const icon = header.querySelector('i');
            if (item.classList.contains('active')) {
                icon.style.transform = 'rotate(180deg)';
                content.style.maxHeight = content.scrollHeight + 'px';
            } else {
                icon.style.transform = 'rotate(0deg)';
                content.style.maxHeight = null;
            }
        });
    }

    // Event Delegation for dynamic content actions
    dashboardSection.addEventListener('click', (e) => {
        const target = e.target;
        const listingItem = target.closest('.listing-item');
        if (listingItem) {
            const id = listingItem.dataset.id;
            if (target.classList.contains('approve-btn')) handleAdminAction('approve', [id]);
            if (target.classList.contains('delete-btn')) {
                if (confirm('Are you sure?')) handleAdminAction('delete', [id]);
            }
            if (target.classList.contains('update-btn')) alert(`Update functionality for Listing #${id} is not implemented.`);
        }
        const categoryItem = target.closest('.category-item');
        if (categoryItem && target.classList.contains('delete-category-btn')) {
            if (confirm('Are you sure?')) handleCategoryDelete(categoryItem.dataset.id);
        }
    });

    // Bulk Action Logic
    const updateDeleteSelectedButtonState = () => {
        if (!approvedListingsBody) return;
        const selectedCount = approvedListingsBody.querySelectorAll('.listing-checkbox:checked').length;
        deleteSelectedBtn.disabled = selectedCount === 0;
        deleteSelectedBtn.textContent = `Delete Selected (${selectedCount})`;
    };

    selectAllCheckbox?.addEventListener('change', (e) => {
        approvedListingsBody.querySelectorAll('.listing-checkbox').forEach(checkbox => checkbox.checked = e.target.checked);
        updateDeleteSelectedButtonState();
    });

    approvedListingsBody?.addEventListener('change', (e) => {
        if (e.target.classList.contains('listing-checkbox')) updateDeleteSelectedButtonState();
    });
    
    deleteSelectedBtn?.addEventListener('click', () => {
        const selectedIds = Array.from(approvedListingsBody.querySelectorAll('.listing-checkbox:checked'))
            .map(cb => cb.closest('tr').dataset.id);
        if (selectedIds.length === 0) return;
        if (confirm(`Are you sure you want to delete ${selectedIds.length} listings?`)) {
            handleAdminAction('bulk_delete', selectedIds);
        }
    });
    
    // --- Initial UI Setup ---
    updateUI();
});