/**
 * Main JavaScript for the LocalLink Frontend.
 * This script uses a page-specific initialization pattern to ensure
 * that code only runs on the page where its corresponding HTML elements exist.
 */
document.addEventListener('DOMContentLoaded', () => {

    // --- SHARED FUNCTION ---
    // This function runs on page load to display a success message if one was set in sessionStorage.
    // This is used for providing feedback after a form submission and redirect.
    const displayRedirectMessage = () => {
        const container = document.getElementById('redirect-message-container');
        const message = sessionStorage.getItem('formSubmissionMessage');
        // Only proceed if the container exists and a message is available
        if (container && message) {
            const alertType = sessionStorage.getItem('formSubmissionType') || 'success';
            container.innerHTML = `<div class="alert-${alertType}" style="padding: 1rem; border-radius: 8px; margin-bottom: 2rem;">${message}</div>`;
            // Clear the message from session storage after displaying it to prevent it from showing again on refresh
            sessionStorage.removeItem('formSubmissionMessage');
            sessionStorage.removeItem('formSubmissionType');
        }
    };

    // --- HOMEPAGE LOGIC INITIALIZER ---
    const initHomePage = () => {
        const accordionContainer = document.getElementById('category-accordion');
        const loader = document.getElementById('loader');
        const noResults = document.getElementById('no-results');
        const searchInput = document.getElementById('searchInput');
        const searchButton = document.getElementById('searchButton');
        let allListings = [];
        let groupedByCategory = {};

        // Fetches both listings and categories from the server API.
        const fetchListingsAndCategories = async () => {
            try {
                const [listingsRes] = await Promise.all([
                    fetch('/api/listings.php'),
                ]);

                if (!listingsRes.ok) {
                    throw new Error(`Failed to load listings. Server responded with ${listingsRes.status}`);
                }
                
                allListings = await listingsRes.json();
                
                groupListings();
                buildAccordionUI();

            } catch (error) {
                console.error("CRITICAL FETCH ERROR:", error);
                accordionContainer.innerHTML = `<p style="color:red; text-align:center;">Failed to load services. Please check the browser console (F12) for more details.</p>`;
            } finally {
                if (loader) loader.style.display = 'none';
            }
        };
        
        // Organizes the flat array of listings into an object keyed by category.
        const groupListings = () => {
            groupedByCategory = allListings.reduce((acc, listing) => {
                const category = listing.category || 'Uncategorized';
                if (!acc[category]) {
                    acc[category] = [];
                }
                acc[category].push(listing);
                return acc;
            }, {});
        };

        // Builds the entire accordion UI based on the grouped data and an optional search filter.
        const buildAccordionUI = (filter = '') => {
            accordionContainer.innerHTML = '';
            const searchTerm = filter.toLowerCase();
            
            const filteredCategories = Object.keys(groupedByCategory).filter(category => {
                if (!searchTerm) return true;
                return category.toLowerCase().includes(searchTerm) || 
                       groupedByCategory[category].some(l => l.name.toLowerCase().includes(searchTerm) || l.area.toLowerCase().includes(searchTerm));
            }).sort();

            if (filteredCategories.length === 0) {
                noResults.classList.remove('d-none');
                return;
            }
            noResults.classList.add('d-none');
            
            filteredCategories.forEach(category => {
                const listings = groupedByCategory[category];
                const group = document.createElement('div');
                group.className = 'category-group';
                
                const header = document.createElement('div');
                header.className = 'category-header';
                header.innerHTML = `<div><span class="category-title">${category}</span><span class="category-count">(${listings.length} services)</span></div><span class="category-toggle-icon">+</span>`;
                
                const cardContainer = document.createElement('div');
                cardContainer.className = 'tool-card-container';
                
                group.appendChild(header);
                group.appendChild(cardContainer);
                accordionContainer.appendChild(group);

                header.addEventListener('click', () => {
                    const isActive = group.classList.contains('active');
                    
                    document.querySelectorAll('.category-group.active').forEach(openGroup => {
                         if (openGroup !== group) {
                            openGroup.classList.remove('active');
                            openGroup.querySelector('.tool-card-container').style.maxHeight = '0px';
                            openGroup.querySelector('.category-toggle-icon').style.transform = 'rotate(0deg)';
                         }
                    });

                    group.classList.toggle('active');
                    const icon = group.querySelector('.category-toggle-icon');

                    if (!isActive) {
                        // THE CORE FIX: Check childElementCount instead of innerHTML to see if cards need to be rendered.
                        if (cardContainer.childElementCount === 0) {
                            listings.forEach(listing => {
                                cardContainer.insertAdjacentHTML('beforeend', createCardHTML(listing));
                            });
                        }
                        icon.style.transform = 'rotate(45deg)';
                        cardContainer.style.maxHeight = cardContainer.scrollHeight + 'px';
                    } else {
                        icon.style.transform = 'rotate(0deg)';
                        cardContainer.style.maxHeight = '0px';
                    }
                });
            });
        };

        // Generates the HTML string for a single service card.
        const createCardHTML = (listing) => {
            // Sanitize description to prevent potential HTML injection issues
            const tempDiv = document.createElement('div');
            tempDiv.textContent = listing.description;
            const sanitizedDescription = tempDiv.innerHTML;
            
            return `
                <div class="listing-card">
                    <div class="card-img-container">
                        <img src="${listing.image ? '/api/' + listing.image : 'https://via.placeholder.com/400x300.png?text=No+Image'}" alt="${listing.name}">
                    </div>
                    <div class="card-content">
                        <h3 class="card-title">${listing.name}</h3>
                        <p class="card-area"><i class="bi bi-geo-alt-fill"></i> ${listing.area}</p>
                        <p class="card-description">${sanitizedDescription}</p>
                        <div class="contact-buttons">
                            <a href="tel:${listing.phone}" class="btn"><i class="bi bi-telephone"></i> Call</a>
                            ${listing.whatsapp ? `<a href="https://wa.me/${listing.whatsapp.replace(/\D/g, '')}" target="_blank" class="btn btn-whatsapp"><i class="bi bi-whatsapp"></i> WhatsApp</a>` : ''}
                        </div>
                    </div>
                </div>`;
        };
        
        // Attach event listeners for search functionality.
        searchInput.addEventListener('input', (e) => buildAccordionUI(e.target.value));
        searchButton.addEventListener('click', () => buildAccordionUI(searchInput.value));
        
        // Initial data fetch and UI build.
        fetchListingsAndCategories();
    };

    // --- ADD SERVICE PAGE LOGIC ---
    const initAddServicePage = () => {
        const form = document.getElementById('addServiceForm');
        
        const populateCategoryDropdown = async () => {
            const dropdown = document.getElementById('category');
            if (!dropdown) return;
            try {
                const response = await fetch('/api/categories.php');
                const categories = await response.json();
                
                dropdown.innerHTML = '<option selected disabled value="">Choose a category...</option>'; 
                categories.forEach(cat => {
                    const option = document.createElement('option');
                    option.value = cat.name;
                    option.textContent = cat.name;
                    dropdown.appendChild(option);
                });
            } catch (error) {
                dropdown.innerHTML = '<option selected disabled value="">Could not load categories</option>';
                console.error("Failed to populate categories:", error);
            }
        };
        
        populateCategoryDropdown();

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            const submitButton = form.querySelector('button[type="submit"]');
            const messageDiv = document.getElementById('form-message');
            
            submitButton.disabled = true;
            submitButton.innerHTML = 'Submitting...';
            
            try {
                const response = await fetch('/api/listings.php', { method: 'POST', body: formData });
                const result = await response.json().catch(() => ({ success: false, message: 'Invalid server response.' }));

                if (response.ok && result.success) {
                    sessionStorage.setItem('formSubmissionMessage', 'Your service has been submitted successfully! It will be reviewed by an admin.');
                    sessionStorage.setItem('formSubmissionType', 'success');
                    window.location.href = '/';
                } else {
                    throw new Error(result.message || 'An unknown error occurred.');
                }
            } catch (error) {
                messageDiv.innerHTML = `<div class="alert-danger" style="padding: 1rem; border-radius: 8px;">${error.message}</div>`;
                submitButton.disabled = false;
                submitButton.textContent = 'Submit for Review';
            }
        });
    };

    // --- SIMPLE PAGE ROUTER ---
    // This runs the correct initialization function based on which page is currently loaded.
    
    // Always check for a redirect message first.
    displayRedirectMessage();

    if (document.getElementById('category-accordion')) {
        initHomePage();
    } else if (document.getElementById('addServiceForm')) {
        initAddServicePage();
    }
});