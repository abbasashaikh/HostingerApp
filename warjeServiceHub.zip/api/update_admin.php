<?php
require_once 'db.php'; // This includes our database connection

// --- PASTE THE HASH YOU COPIED FROM THE PREVIOUS STEP HERE ---
$newHashedPassword = 'PASTE_THE_LONG_HASH_STRING_HERE'; 

if (strlen($newHashedPassword) < 20) {
    die("<h1>Error: Please paste the full hash string into the script.</h1>");
}

// Prepare the SQL statement to update the admin password
$stmt = $db->prepare("UPDATE admin SET password = :password WHERE username = 'admin'");
$stmt->bindValue(':password', $newHashedPassword, SQLITE3_TEXT);

// Execute the update
if ($stmt->execute()) {
    echo "<h1>Success!</h1><p>The admin password has been updated successfully.</p>";
} else {
    echo "<h1>Error!</h1><p>Failed to update the password.</p>";
}

$db->close();
?>