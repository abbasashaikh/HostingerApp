<?php
/**
 * API Endpoint for Public Listings
 */

// Use the global init file for headers and DB connection.
require_once 'init.php'; 

$method = $_SERVER['REQUEST_METHOD'];

// Route based on the HTTP method.
if ($method === 'GET') {
    handleGet($db);
} elseif ($method === 'POST') {
    handlePost($db);
} else {
    send_json_response(['success' => false, 'message' => 'Method Not Allowed'], 405);
}

/**
 * Fetches all APPROVED (status = 1) listings.
 * @param SQLite3 $db The database connection object.
 */
function handleGet($db) {
    try {
        $query = "SELECT * FROM listings WHERE status = 1 ORDER BY createdAt DESC";
        $result = $db->query($query);
        if (!$result) {
             throw new Exception($db->lastErrorMsg());
        }
        $listings = [];
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $listings[] = $row;
        }
        send_json_response($listings);
    } catch (Exception $e) {
        send_json_response(['success' => false, 'message' => 'Failed to retrieve listings: ' . $e->getMessage()], 500);
    }
}

/**
 * Handles the submission of a new service listing from the public form.
 * @param SQLite3 $db The database connection object.
 */
function handlePost($db) {
    try {
        // Basic validation
        if (empty($_POST['name']) || empty($_POST['phone']) || empty($_POST['category']) || empty($_POST['area']) || empty($_POST['description'])) {
            send_json_response(['success' => false, 'message' => 'All required fields must be filled out.'], 400);
        }

        // Handle file upload
        $imagePath = '';
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $targetDir = __DIR__ . "/uploads/";
            if (!file_exists($targetDir)) {
                // Attempt to create the directory with web-server-writable permissions
                if (!mkdir($targetDir, 0755, true)) {
                     throw new Exception('Failed to create upload directory. Check permissions.');
                }
            }
            $fileName = time() . '_' . basename($_FILES["image"]["name"]);
            $targetFile = $targetDir . $fileName;
            
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                $imagePath = 'uploads/' . $fileName; // Store a relative path for the URL
            } else {
                throw new Exception('Failed to move uploaded file.');
            }
        }
        
        // Prepare and execute the database insert
        $stmt = $db->prepare("INSERT INTO listings (name, phone, whatsapp, category, area, description, image) VALUES (:name, :phone, :whatsapp, :category, :area, :description, :image)");
        // Sanitize by binding values
        $stmt->bindValue(':name', $_POST['name']);
        $stmt->bindValue(':phone', $_POST['phone']);
        $stmt->bindValue(':whatsapp', $_POST['whatsapp'] ?? '');
        $stmt->bindValue(':category', $_POST['category']);
        $stmt->bindValue(':area', $_POST['area']);
        $stmt->bindValue(':description', $_POST['description']);
        $stmt->bindValue(':image', $imagePath);

        if ($stmt->execute()) {
            send_json_response(['success' => true, 'message' => 'Listing submitted successfully for review.']);
        } else {
            throw new Exception('Database execution failed.');
        }
    } catch (Exception $e) {
        send_json_response(['success' => false, 'message' => 'Server error while submitting listing: ' . $e->getMessage()], 500);
    }
}

// Close the database connection at the end of the script.
$db->close();
?>