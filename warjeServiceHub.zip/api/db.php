<?php
// This script's only job is to ensure tables exist.
// It should not be included directly by endpoints, but by init.php.

// The $db variable is passed in from init.php where it was created.
// This prevents re-declaring it.

// SQL to create tables if they don't exist
$db->exec("CREATE TABLE IF NOT EXISTS listings (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL, whatsapp TEXT, area TEXT NOT NULL, category TEXT NOT NULL, description TEXT NOT NULL, image TEXT, status INTEGER DEFAULT 0, createdAt DATETIME DEFAULT CURRENT_TIMESTAMP);");
$db->exec("CREATE TABLE IF NOT EXISTS admin (id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE, password TEXT NOT NULL);");
$db->exec("CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE);");

// --- One-time Admin and Category Seeding ---
$adminCount = $db->querySingle("SELECT COUNT(*) as count FROM admin");
if ($adminCount == 0) {
    $username = 'admin';
    $password = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $db->prepare("INSERT INTO admin (id, username, password) VALUES (1, :username, :password)");
    $stmt->bindValue(':username', $username, SQLITE3_TEXT);
    $stmt->bindValue(':password', $password, SQLITE3_TEXT);
    $stmt->execute();
}

$categoryCount = $db->querySingle("SELECT COUNT(*) as count FROM categories");
if ($categoryCount == 0) {
    $default_categories = ["Plumber", "Electrician", "Tutor", "Carpenter", "Painter", "AC Repair", "Home Cleaning"];
    $stmt = $db->prepare("INSERT INTO categories (name) VALUES (:name)");
    foreach ($default_categories as $cat) {
        $stmt->bindValue(':name', $cat, SQLITE3_TEXT);
        $stmt->execute();
    }
}
?>