<?php
// --- IMPORTANT: CHANGE THIS TO YOUR NEW, STRONG PASSWORD ---
$newPassword = 'YourNewStrongPassword!@#$'; 

// Hash the new password
$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

// Display the generated hash
echo "<h1>Your New Password Hash</h1>";
echo "<p>Copy this entire string and save it for the next step:</p>";
echo "<pre style='background:#eee; padding:10px; border:1px solid #ccc; word-wrap:break-word;'>";
echo htmlspecialchars($hashedPassword);
echo "</pre>";
?>