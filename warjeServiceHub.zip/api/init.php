<?php
/**
 * Global Initialization File for the LocalLink API
 *
 * This script is included by all other API endpoints. Its jobs are:
 * 1. Configure PHP error logging for debugging on a live server.
 * 2. Start a user session securely.
 * 3. Set the global HTTP header to declare all responses will be JSON.
 * 4. Provide a robust, centralized function for sending JSON responses.
 * 5. Establish a connection to the SQLite database.
 * 6. Include the schema setup script (db.php) to ensure tables exist.
 */

// --- 1. Error Reporting ---
// On a live server, we don't want to show errors to the user.
// Instead, we log them to a file for the developer to review.
ini_set('display_errors', 0);
ini_set('log_errors', 1);
// __DIR__ is a PHP "magic constant" that gives the directory of the current file.
// This makes the path to the error log reliable.
ini_set('error_log', __DIR__ . '/error_log.txt');
error_reporting(E_ALL);

// --- 2. Session Management ---
// Checks if a session is already active before starting a new one.
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// --- 3. Global HTTP Header ---
// This tells the browser (and JavaScript's fetch API) that the response
// from this script will always be in JSON format.
header('Content-Type: application/json');

// --- 4. Global Helper Function for Responses ---
// Using a single function for all responses ensures consistency.
function send_json_response($data, $statusCode = 200) {
    http_response_code($statusCode);
    // Ensure the data is always an array or object before encoding
    if (is_string($data)) {
        // If we just get a string, wrap it in a standard message format.
        $data = ['message' => $data];
    }
    echo json_encode($data);
    // exit() is crucial to stop the script immediately after sending the response.
    exit();
}

// --- 5. Database Connection ---
$db = null; // Initialize to null
try {
    // Check if the SQLite3 PHP extension is enabled on the server.
    if (!class_exists('SQLite3')) {
        throw new Exception('SQLite3 PHP extension is not enabled on this server.');
    }
    // Use an absolute path to the database file for maximum reliability.
    $dbPath = __DIR__ . '/local_services.sqlite';
    $db = new SQLite3($dbPath);
    // Set a timeout to prevent "database is locked" errors during high traffic.
    $db->busyTimeout(5000);
} catch (Exception $e) {
    // If the database connection fails for any reason, send a clear JSON error and stop.
    send_json_response(['success' => false, 'message' => 'Critical Error: Database connection failed. Check file permissions and path.'], 500);
}

// --- 6. Include Schema Setup ---
// After a successful DB connection, we ensure the tables exist.
// The $db object is passed implicitly to the included script.
if ($db) {
    require_once 'db.php';
}

// The $db variable is now globally available to any script that 'requires' this init.php file.
?>