<?php
/**
 * API Endpoint for Managing Categories
 */

// Include the global initialization file.
require_once 'init.php';

// Determine the request method and action.
$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? '';

// --- Main Router for this Endpoint ---

// Anyone can GET the list of categories.
if ($method === 'GET') {
    handleGet($db);
} 
// Only a logged-in admin can perform POST actions (add/delete).
else if ($method === 'POST') {
    // First, verify the admin is logged in.
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        send_json_response(['success' => false, 'message' => 'Unauthorized'], 403);
    }
    
    // Route to the correct function based on the 'action' parameter.
    if ($action === 'add') {
        handleAdd($db);
    } elseif ($action === 'delete') {
        handleDelete($db);
    } else {
        send_json_response(['success' => false, 'message' => 'Invalid action for categories.'], 400);
    }
} else {
    send_json_response(['success' => false, 'message' => 'Method Not Allowed'], 405);
}


// --- Function Definitions ---

/**
 * Fetches and returns all categories, sorted alphabetically.
 * @param SQLite3 $db The database connection object.
 */
function handleGet($db) {
    $result = $db->query("SELECT * FROM categories ORDER BY name ASC");
    $categories = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $categories[] = $row;
    }
    send_json_response($categories); // Use the global helper to send the response
}

/**
 * Adds a new category to the database.
 * @param SQLite3 $db The database connection object.
 */
function handleAdd($db) {
    $name = trim($_POST['name'] ?? '');
    if (empty($name)) {
        send_json_response(['success' => false, 'message' => 'Category name is required.'], 400);
    }

    $stmt = $db->prepare("INSERT INTO categories (name) VALUES (:name)");
    $stmt->bindValue(':name', $name, SQLITE3_TEXT);
    
    // The execute can fail if the name is not unique.
    if ($stmt->execute()) {
        send_json_response(['success' => true, 'id' => $db->lastInsertRowID(), 'name' => $name]);
    } else {
        send_json_response(['success' => false, 'message' => 'Failed to add category. It may already exist.'], 500);
    }
}

/**
 * Deletes a category from the database.
 * @param SQLite3 $db The database connection object.
 */
function handleDelete($db) {
    $id = $_POST['id'] ?? 0;
    if (empty($id)) {
        send_json_response(['success' => false, 'message' => 'Category ID is required.'], 400);
    }

    $stmt = $db->prepare("DELETE FROM categories WHERE id = :id");
    $stmt->bindValue(':id', intval($id), SQLITE3_INTEGER);

    if ($stmt->execute()) {
        send_json_response(['success' => true, 'message' => 'Category deleted.']);
    } else {
        send_json_response(['success' => false, 'message' => 'Failed to delete category.'], 500);
    }
}

// Close the database connection at the end of the script.
$db->close();
?>