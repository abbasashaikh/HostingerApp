<?php
// This is the definitive, fully functional admin API endpoint.

// Include the global initialization file. This handles sessions, headers, and DB connection.
require_once 'init.php';

// Determine the requested action from the URL query or POST body.
$action = $_REQUEST['action'] ?? '';

// --- Main Router ---
// First, check if the action is 'login'. This is the only action allowed without a session.
if ($action === 'login') {
    handleLogin($db);
} else {
    // For all other actions, first verify the user is logged in as an admin.
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        send_json_response(['success' => false, 'message' => 'Unauthorized Access. Please log in.'], 403);
    }
    
    // If logged in, route to the appropriate function based on the action.
    switch ($action) {
        case 'logout':
            handleLogout();
            break;
        case 'get_pending':
            getListingsByStatus($db, 0);
            break;
        case 'get_approved':
            getListingsByStatus($db, 1);
            break;
        case 'approve':
            handleListingStatusUpdate($db, 1); // Pass 1 for 'approved' status
            break;
        case 'delete':
        case 'bulk_delete': // Both 'delete' and 'bulk_delete' will trigger the same function
            handleListingDelete($db);
            break;
        default:
            send_json_response(['success' => false, 'message' => 'Invalid action specified.'], 400);
            break;
    }
}

// =======================================================
// --- ALL REQUIRED HELPER FUNCTIONS ARE DEFINED BELOW ---
// =======================================================

/**
 * Handles admin login.
 * @param SQLite3 $db The database connection object.
 */
function handleLogin($db) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        send_json_response(['success' => false, 'message' => 'Username and password are required.'], 400);
    }

    $stmt = $db->prepare("SELECT password FROM admin WHERE username = :username");
    $stmt->bindValue(':username', $username, SQLITE3_TEXT);
    $result = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
    
    if ($result && password_verify($password, $result['password'])) {
        $_SESSION['admin_logged_in'] = true;
        send_json_response(['success' => true, 'message' => 'Login successful.']);
    } else {
        send_json_response(['success' => false, 'message' => 'Invalid credentials.'], 401);
    }
}

/**
 * Handles admin logout by destroying the session.
 */
function handleLogout() {
    session_destroy();
    send_json_response(['success' => true, 'message' => 'Logged out successfully.']);
}

/**
 * Fetches listings based on their status (0 for pending, 1 for approved).
 * @param SQLite3 $db The database connection object.
 * @param int $status The status to filter by.
 */
function getListingsByStatus($db, $status) {
    $stmt = $db->prepare("SELECT * FROM listings WHERE status = :status ORDER BY createdAt DESC");
    $stmt->bindValue(':status', $status, SQLITE3_INTEGER);
    $result = $stmt->execute();
    $listings = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $listings[] = $row;
    }
    send_json_response($listings);
}

/**
 * Updates the status of one or more listings (e.g., for approval).
 * @param SQLite3 $db The database connection object.
 * @param int $newStatus The new status to set (e.g., 1 for approved).
 */
function handleListingStatusUpdate($db, $newStatus) {
    $ids = json_decode($_POST['ids'] ?? '[]');
    if (!is_array($ids) || empty($ids)) {
        send_json_response(['success' => false, 'message' => 'No listing IDs provided.'], 400);
    }
    $sanitized_ids = array_map('intval', $ids);
    $placeholders = implode(',', $sanitized_ids);

    $stmt = $db->prepare("UPDATE listings SET status = :status WHERE id IN ($placeholders)");
    $stmt->bindValue(':status', $newStatus, SQLITE3_INTEGER);

    if ($stmt->execute()) {
        send_json_response(['success' => true, 'message' => 'Listings updated successfully.']);
    } else {
        send_json_response(['success' => false, 'message' => 'Failed to update listings.'], 500);
    }
}

/**
 * Deletes one or more listings from the database and their associated image files.
 * @param SQLite3 $db The database connection object.
 */
function handleListingDelete($db) {
    $ids = json_decode($_POST['ids'] ?? '[]');
    if (!is_array($ids) || empty($ids)) {
        send_json_response(['success' => false, 'message' => 'No listing IDs provided.'], 400);
    }
    $sanitized_ids = array_map('intval', $ids);
    $placeholders = implode(',', $sanitized_ids);

    // Step 1: Get the image paths of the listings to be deleted.
    $imgQuery = "SELECT image FROM listings WHERE id IN ($placeholders)";
    $results = $db->query($imgQuery);
    if ($results) {
        while($row = $results->fetchArray(SQLITE3_ASSOC)) {
            // Delete the physical image file if it exists
            if (!empty($row['image']) && file_exists(__DIR__ . '/' . $row['image'])) {
                @unlink(__DIR__ . '/' . $row['image']); // Use absolute path for reliability
            }
        }
    }
    
    // Step 2: Delete the records from the database.
    $stmt = $db->prepare("DELETE FROM listings WHERE id IN ($placeholders)");
    
    if ($stmt->execute()) {
        send_json_response(['success' => true, 'message' => 'Listings deleted successfully.']);
    } else {
        send_json_response(['success' => false, 'message' => 'Failed to delete listings from the database.'], 500);
    }
}

// Always close the database connection at the end of the script.
$db->close();
?>