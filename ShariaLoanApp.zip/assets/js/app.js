// assets/js/app.js
(async function(){
  const k = await fetch('api.php?action=kpis').then(r=>r.json());
  if (k.members !== undefined) {
    document.getElementById('kpi-members')?.innerText = k.members.toString();
    document.getElementById('kpi-savings')?.innerText = k.savings.toFixed(0);
    document.getElementById('kpi-loan')?.innerText = k.loan_principal.toFixed(0);
    document.getElementById('kpi-repay')?.innerText = k.repayments.toFixed(0);
  }

  const sel = document.getElementById('member-select');
  if (sel) {
    const load = async () => {
      const mid = sel.value;
      const data = await fetch('api.php?action=member_balance&member_id='+mid).then(r=>r.json());
      const labels = data.map(d=>d.as_of_month);
      const savings = data.map(d=>+d.saving_total);
      const outstanding = data.map(d=>+d.outstanding_loan);
      const net = data.map(d=>+d.net_balance);
      const ctx = document.getElementById('lineChart').getContext('2d');
      if (window._chart) window._chart.destroy();
      window._chart = new Chart(ctx, {
        type: 'line',
        data: {
          labels,
          datasets: [
            {label:'Savings', data:savings, borderColor:'#198754'},
            {label:'Outstanding Loan', data:outstanding, borderColor:'#dc3545'},
            {label:'Net', data:net, borderColor:'#0d6efd'}
          ]
        },
        options: { responsive:true, maintainAspectRatio:false }
      });
    };
    sel.addEventListener('change', load);
    if (sel.value) load();
  }
})();
