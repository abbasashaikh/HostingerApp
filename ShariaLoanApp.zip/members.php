<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';
$db = DB::conn();

// Safe blank record for add mode
$r = [
    'member_id' => '',
    'name' => '',
    'dob' => '',
    'mobile' => '',
    'address' => '',
    'nominee' => '',
    'attach_proof_path' => '',
    'special_status' => ''
];
$id = intval($_GET['id'] ?? 0);
$is_edit = false;

if ($id > 0) {
    $is_edit = true;
    $res = $db->query("SELECT * FROM members WHERE member_id=$id LIMIT 1");
    $row = $res->fetchArray(SQLITE3_ASSOC);
    if ($row) $r = $row;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_member'])) {
    $id = intval($_POST['member_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $dob = trim($_POST['dob'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $nominee = trim($_POST['nominee'] ?? '');
    $special_status = trim($_POST['special_status'] ?? '');

    $attach = null;
    if (!empty($_FILES['attach']['name'])) {
        $dir = __DIR__ . '/uploads';
        if (!is_dir($dir)) mkdir($dir, 0775, true);
        $fname = time().'_'.basename($_FILES['attach']['name']);
        move_uploaded_file($_FILES['attach']['tmp_name'], $dir.'/'.$fname);
        $attach = 'uploads/'.$fname;
    }
    if ($id > 0) {
        $stmt = $db->prepare(
            "UPDATE members SET name=:n, dob=:d, mobile=:m, address=:a, nominee=:no, special_status=:ss, updated_at=CURRENT_TIMESTAMP"
            . ($attach? ", attach_proof_path=:p" : "") . " WHERE member_id=:id"
        );
        $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
    } else {
        $stmt = $db->prepare(
            "INSERT INTO members(name,dob,mobile,address,nominee,attach_proof_path,special_status) VALUES(:n,:d,:m,:a,:no,:p,:ss)"
        );
    }
    $stmt->bindValue(':n', $name);
    $stmt->bindValue(':d', $dob);
    $stmt->bindValue(':m', $mobile);
    $stmt->bindValue(':a', $address);
    $stmt->bindValue(':no', $nominee);
    $stmt->bindValue(':ss', $special_status);
    $stmt->bindValue(':p', $attach ?? $r['attach_proof_path'] ?? '');
    $stmt->execute();
    header('Location: members.php?ok=1');
    exit;
}

if (isset($_GET['del'])) {
    $del_id = (int)$_GET['del'];
    $db->exec("DELETE FROM members WHERE member_id=$del_id");
    header('Location: members.php?ok=1');
    exit;
}

$count_members = (int)$db->querySingle("SELECT COUNT(*) FROM members");
$res = $db->query("SELECT * FROM members ORDER BY name");
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Members | SHG Manager</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background:#f7f9fb;font-family:sans-serif;}
    .navbar { background:linear-gradient(90deg,#2563eb 80%,#60a5fa 100%);}
    .navbar-brand { font-weight:700;font-size:1.3rem;}
    label.form-label { font-weight:500;}
    .card { border-radius:1rem;box-shadow:0 2px 12px #abc2e21a; }
    .form-select,.form-control { border-radius:.7rem; }
    .btn { border-radius:.7rem; }
    .small { font-size:.88em;}
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><i class="bi bi-bank"></i> SHG Manager</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
    <div id="nav" class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="members.php"><i class="bi bi-people"></i> Members</a></li>
        <li class="nav-item"><a class="nav-link" href="deposits.php"><i class="bi bi-piggy-bank"></i> Deposits</a></li>
        <li class="nav-item"><a class="nav-link" href="loans.php"><i class="bi bi-cash-stack"></i> Loans</a></li>
        <li class="nav-item"><a class="nav-link" href="reports.php"><i class="bi bi-bar-chart-line"></i> Reports</a></li>
        <li class="nav-item"><a class="nav-link" href="import.php"><i class="bi bi-upload"></i> Import</a></li>
      </ul>
      <a class="btn btn-secondary btn-sm" href="index.php"><i class="bi bi-grid"></i> Dashboard</a>
    </div>
  </div>
</nav>

<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4>Members <small class="text-muted">(<?= $count_members ?>)</small></h4>
    <a class="btn btn-primary" href="members.php"><i class="bi bi-person-plus"></i> Add Member</a>
  </div>

  <div class="card mb-4">
    <div class="card-header"><?= $is_edit ? 'Edit Member' : 'Add Member'; ?></div>
    <div class="card-body">
      <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="member_id" value="<?= $r['member_id'] ?? '' ?>">
        <input type="hidden" name="save_member" value="1">
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label">Name *</label>
            <input class="form-control" name="name" required value="<?= htmlspecialchars($r['name'] ?? '') ?>">
          </div>
          <div class="col-md-4">
            <label class="form-label">Date of Birth</label>
            <input type="date" class="form-control" name="dob" value="<?= htmlspecialchars($r['dob'] ?? '') ?>">
          </div>
          <div class="col-md-4">
            <label class="form-label">Mobile</label>
            <input class="form-control" name="mobile" value="<?= htmlspecialchars($r['mobile'] ?? '') ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">Address</label>
            <input class="form-control" name="address" value="<?= htmlspecialchars($r['address'] ?? '') ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">Nominee</label>
            <input class="form-control" name="nominee" value="<?= htmlspecialchars($r['nominee'] ?? '') ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">Attach Proof</label>
            <input type="file" class="form-control" name="attach">
            <?php if (!empty($r['attach_proof_path'])): ?>
              <div class="mt-2"><a href="<?= $r['attach_proof_path'] ?>" target="_blank">View Existing</a></div>
            <?php endif; ?>
            <div class="small text-muted">JPG, PDF up to 5MB</div>
          </div>
          <div class="col-md-6 mt-2">
            <label class="form-label">Member Status (Withdrawal eligibility)</label>
            <select class="form-select" name="special_status">
              <option value="" <?= ($r['special_status'] ?? '')=='' ? 'selected' : '' ?>>Active</option>
              <option value="expire" <?= ($r['special_status'] ?? '')=='expire' ? 'selected' : '' ?>>Deceased/Expired</option>
              <option value="major_loss" <?= ($r['special_status'] ?? '')=='major_loss' ? 'selected' : '' ?>>Major loss/disease</option>
            </select>
          </div>
        </div>
        <div class="mt-3">
          <button class="btn btn-success"><?= $is_edit ? 'Update' : 'Save'; ?> Member</button>
          <a href="members.php" class="btn btn-outline-secondary">Back to List</a>
        </div>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <table class="table table-sm table-striped">
        <thead>
          <tr>
            <th>Name</th><th>Mobile</th><th>Address</th><th>Nominee</th><th>Status</th><th>Proof</th><th></th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $res->fetchArray(SQLITE3_ASSOC)): ?>
            <tr>
              <td><?= htmlspecialchars($row['name'] ?? '') ?></td>
              <td><?= htmlspecialchars($row['mobile'] ?? '') ?></td>
              <td><?= htmlspecialchars($row['address'] ?? '') ?></td>
              <td><?= htmlspecialchars($row['nominee'] ?? '') ?></td>
              <td>
                <?php
                  if (($row['special_status'] ?? '')=='expire') echo 'Deceased';
                  elseif (($row['special_status'] ?? '')=='major_loss') echo 'Major loss';
                  else echo 'Active';
                ?>
              </td>
              <td>
                <?php if (!empty($row['attach_proof_path'])): ?>
                  <a href="<?= $row['attach_proof_path'] ?>" target="_blank">View</a>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <a href="members.php?id=<?= $row['member_id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                <a href="members.php?del=<?= $row['member_id'] ?>" class="btn btn-sm btn-outline-danger"
                   onclick="return confirm('Delete this member?');">Delete</a>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
