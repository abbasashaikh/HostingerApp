<?php
require_once 'db.php';
$db = DB::conn();
$members = (int)$db->querySingle("SELECT COUNT(*) FROM members");
$savings = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM deposits");
$loanPrincipal = (float)$db->querySingle("SELECT IFNULL(SUM(principal),0) FROM loans");
$repayments = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM repayments");
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>SHG Manager</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background:#f7f9fb;font-family:sans-serif;}
    .navbar { background:linear-gradient(90deg,#2563eb 80%,#60a5fa 100%);}
    .navbar-brand { font-weight:700;font-size:1.3rem;}
    .card { border-radius:1rem;box-shadow:0 2px 12px #abc2e21a;}
    .kpi-title { color:#2563eb;font-weight:600;font-size:0.98rem;}
    .kpi-val { font-size:2.2rem;font-weight:bold;color:#2563eb;}
    .btn-primary { background:linear-gradient(90deg,#2563eb 80%,#60a5fa 100%);border:none;}
    .card-header { background:#e0e7ef;border-radius:1rem 1rem 0 0;font-weight:600;color:#2563eb; }
    label.form-label { font-weight:500;}
    .form-select,.form-control { border-radius:.7rem;}
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><i class="bi bi-bank"></i> SHG Manager</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
    <div id="nav" class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="members.php"><i class="bi bi-people"></i> Members</a></li>
        <li class="nav-item"><a class="nav-link" href="deposits.php"><i class="bi bi-piggy-bank"></i> Deposits</a></li>
        <li class="nav-item"><a class="nav-link" href="loans.php"><i class="bi bi-cash-stack"></i> Loans</a></li>
        <li class="nav-item"><a class="nav-link" href="reports.php"><i class="bi bi-bar-chart-line"></i> Reports</a></li>
        <li class="nav-item"><a class="nav-link" href="import.php"><i class="bi bi-upload"></i> Import</a></li>
      </ul>
      <a class="btn btn-primary btn-sm" href="api.php?action=recalc"><i class="bi bi-arrow-repeat"></i> Recalculate</a>
    </div>
  </div>
</nav>

<main class="container my-4">
  <div class="row g-3">
    <div class="col-6 col-md-3">
      <div class="card text-center pb-2 pt-2">
        <div class="card-body">
          <div class="kpi-title"><i class="bi bi-person"></i> Members</div>
          <div id="kpi-members" class="kpi-val"><?php echo $members; ?></div>
        </div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card text-center pb-2 pt-2">
        <div class="card-body">
          <div class="kpi-title"><i class="bi bi-wallet2"></i> Total Savings</div>
          <div id="kpi-savings" class="kpi-val"><?php echo number_format($savings,2); ?></div>
        </div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card text-center pb-2 pt-2">
        <div class="card-body">
          <div class="kpi-title"><i class="bi bi-currency-rupee"></i> Loan Principal</div>
          <div id="kpi-loan" class="kpi-val"><?php echo number_format($loanPrincipal,2); ?></div>
        </div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card text-center pb-2 pt-2">
        <div class="card-body">
          <div class="kpi-title"><i class="bi bi-check-circle"></i> Repayments</div>
          <div id="kpi-repay" class="kpi-val"><?php echo number_format($repayments,2); ?></div>
        </div>
      </div>
    </div>
  </div>
 <div class="card mt-4">
    <div class="card-header">Savings vs Outstanding (sample member)</div>
    <div class="card-body">
      <div class="row g-2 align-items-end">
        <div class="col-12 col-md-3">
          <form method="get">
            <label class="form-label">Member</label>
            <select id="member-select" class="form-select">
              <?php
                $db = DB::conn();
                $res = $db->query("SELECT member_id, name FROM members ORDER BY name");
                while ($r = $res->fetchArray(SQLITE3_ASSOC)) {
                  echo '<option value="'.$r['member_id'].'">'.htmlspecialchars($r['name']).'</option>';
                }
              ?>
            </select>
          </form>
        </div>
      </div>
      <canvas id="lineChart" height="120"></canvas>
    </div>
  </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
