<?php
// File: header.php (new shared header)

// Protect pages
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: login.php');
    exit;
}
?>
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><i class="bi bi-bank"></i> SHG Manager</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
    <div id="nav" class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="bi bi-house-door"></i> Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="members.php"><i class="bi bi-people"></i> Members</a></li>
        <li class="nav-item"><a class="nav-link" href="deposits.php"><i class="bi bi-piggy-bank"></i> Deposits</a></li>
        <li class="nav-item"><a class="nav-link" href="loans.php"><i class="bi bi-cash-stack"></i> Loans</a></li>
        <li class="nav-item"><a class="nav-link" href="reports.php"><i class="bi bi-bar-chart-line"></i> Reports</a></li>
        <li class="nav-item"><a class="nav-link" href="import.php"><i class="bi bi-upload"></i> Import</a></li>
      </ul>
       <a class="btn btn-secondary btn-sm" href="index.php"><i class="bi bi-grid"></i> Dashboard</a>
      <div class="d-flex">
        <a class="btn btn-outline-light btn-sm me-2" href="api.php?action=recalc"><i class="bi bi-arrow-repeat"></i> Recalculate</a>
        <a class="btn btn-outline-light btn-sm" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout (<?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?>)</a>
      </div>
    </div>
  </div>
</nav>
