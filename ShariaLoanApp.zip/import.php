<?php
// Updated import.php

declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/logic.php';
require_once __DIR__ . '/header.php'; // Include header

$db = DB::conn();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv'])) {
  $type = $_POST['type'] ?? 'members';
  $tmp = $_FILES['csv']['tmp_name'];
  $fh = fopen($tmp, 'r');
  $header = fgetcsv($fh);
  $count = 0;

  $db->exec('BEGIN');
  try {
    if ($type === 'members') {
      $stmt = $db->prepare("INSERT INTO members(name,dob,mobile,address,nominee) VALUES(:n,:d,:m,:a,:no)");
      while (($row = fgetcsv($fh)) !== false) {
        $data = array_combine($header, $row);
        $stmt->bindValue(':n', $data['name'] ?? $data['Name'] ?? '');
        $stmt->bindValue(':d', $data['dob'] ?? $data['DoB'] ?? null);
        $stmt->bindValue(':m', $data['mobile'] ?? $data['MobileNo'] ?? null);
        $stmt->bindValue(':a', $data['address'] ?? $data['Address'] ?? null);
        $stmt->bindValue(':no', $data['nominee'] ?? $data['Nominee'] ?? null);
        $stmt->execute(); $count++;
      }
    } elseif ($type === 'deposits') {
      $stmt = $db->prepare("INSERT INTO deposits(member_id,date,amount,kind,note) VALUES(:m,:d,:a,:k,:n)");
      while (($row = fgetcsv($fh)) !== false) {
        $data = array_combine($header, $row);
        $stmt->bindValue(':m', (int)($data['member_id'] ?? $data['MemberId'] ?? 0));
        $stmt->bindValue(':d', $data['date'] ?? $data['Date'] ?? '');
        $stmt->bindValue(':a', (float)($data['amount'] ?? $data['Amount'] ?? 0));
        $stmt->bindValue(':k', strtoupper($data['kind'] ?? 'SAVING'));
        $stmt->bindValue(':n', $data['note'] ?? '');
        $stmt->execute(); $count++;
      }
    } elseif ($type === 'loans') {
      $stmt = $db->prepare("INSERT INTO loans(member_id,disbursed_date,principal,status,note) VALUES(:m,:d,:p,:s,:n)");
      while (($row = fgetcsv($fh)) !== false) {
        $data = array_combine($header, $row);
        $stmt->bindValue(':m', (int)($data['member_id'] ?? 0));
        $stmt->bindValue(':d', $data['disbursed_date'] ?? $data['Date'] ?? '');
        $stmt->bindValue(':p', (float)($data['principal'] ?? $data['amount'] ?? 0));
        $stmt->bindValue(':s', strtoupper($data['status'] ?? 'ACTIVE'));
        $stmt->bindValue(':n', $data['note'] ?? $data['Borrower'] ?? '');
        $stmt->execute(); $count++;
      }
    } elseif ($type === 'repayments') {
      $stmt = $db->prepare("INSERT INTO repayments(loan_id,member_id,repayment_date,amount,note) VALUES(:l,:m,:d,:a,:n)");
      while (($row = fgetcsv($fh)) !== false) {
        $data = array_combine($header, $row);
        $stmt->bindValue(':l', (int)($data['loan_id'] ?? 0));
        $stmt->bindValue(':m', (int)($data['member_id'] ?? 0));
        $stmt->bindValue(':d', $data['repayment_date'] ?? $data['Date'] ?? '');
        $stmt->bindValue(':a', (float)($data['amount'] ?? $data['Amount'] ?? 0));
        $stmt->bindValue(':n', $data['note'] ?? '');
        $stmt->execute(); $count++;
      }
    }
    $db->exec('COMMIT');
    recalc_all();
    $msg = "Imported $count rows successfully!";
  } catch (Throwable $e) {
    $db->exec('ROLLBACK');
    $msg = "Error: " . $e->getMessage();
  }
  fclose($fh);
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Import - SHG Manager</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    /* Reuse styles */
    :root {
      --primary-blue: #2563eb;
      --gradient-blue: linear-gradient(90deg, #2563eb 80%, #60a5fa 100%);
      --success-green: #10B981;
      --warning-orange: #F59E0B;
      --bg-light: #f7f9fb;
      --card-shadow: 0 2px 12px rgba(171, 194, 226, 0.1);
      --text-primary: #1f2937;
    }
    [data-theme="dark"] {
      --bg-light: #1f2937;
      --text-primary: #f9fafb;
      --card-shadow: 0 2px 12px rgba(0, 0, 0, 0.3);
    }
    body { background: var(--bg-light); color: var(--text-primary); font-family: sans-serif; }
    .card { border-radius: 1rem; box-shadow: var(--card-shadow); border: none; transition: transform 0.2s ease; }
    .card:hover { transform: translateY(-2px); }
    .btn-primary { background: var(--gradient-blue); border: none; }
    .form-control, .form-select { border-radius: 0.7rem; }
    label.form-label { font-weight: 500; color: var(--text-primary); }
  </style>
</head>
<body data-theme="light">
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4><i class="bi bi-upload"></i> CSV Import</h4>
   
  </div>

  <?php if (!empty($msg)): ?>
    <div class="alert alert-<?= strpos($msg, 'Error') !== false ? 'danger' : 'success' ?> alert-dismissible fade show" role="alert">
      <?= htmlspecialchars($msg) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <div class="card">
    <div class="card-header">
      <h5><i class="bi bi-filetype-csv"></i> Upload CSV File</h5>
    </div>
    <div class="card-body">
      <form class="row g-3" method="post" enctype="multipart/form-data">
        <div class="col-md-3">
          <label class="form-label">Type <span class="text-danger">*</span></label>
          <select class="form-select" name="type" required>
            <option value="members">Members</option>
            <option value="deposits">Deposits</option>
            <option value="loans">Loans</option>
            <option value="repayments">Repayments</option>
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label">CSV File <span class="text-danger">*</span></label>
          <input type="file" class="form-control" name="csv" accept=".csv" required>
          <small class="form-text text-muted">Header names are flexible (e.g., 'Name' or 'name' for members).</small>
        </div>
        <div class="col-md-3 align-self-end">
          <button class="btn btn-primary"><i class="bi bi-cloud-upload"></i> Upload & Import</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>