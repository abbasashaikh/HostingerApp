<?php
// index.php
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/logic.php';
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>SHG Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/styles.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">SHG Manager</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div id="nav" class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="members.php">Members</a></li>
        <li class="nav-item"><a class="nav-link" href="deposits.php">Deposits</a></li>
        <li class="nav-item"><a class="nav-link" href="loans.php">Loans</a></li>
        <li class="nav-item"><a class="nav-link" href="reports.php">Reports</a></li>
        <li class="nav-item"><a class="nav-link" href="import.php">Import</a></li>
      </ul>
      <a class="btn btn-outline-light btn-sm" href="api.php?action=recalc">Recalculate</a>
    </div>
  </div>
</nav>

<main class="container my-4">
  <div class="row g-3">
    <div class="col-6 col-md-3">
      <div class="card text-center">
        <div class="card-body">
          <h6>Members</h6>
          <div id="kpi-members" class="display-6">0</div>
        </div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card text-center">
        <div class="card-body">
          <h6>Total Savings</h6>
          <div id="kpi-savings" class="display-6">0</div>
        </div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card text-center">
        <div class="card-body">
          <h6>Loan Principal</h6>
          <div id="kpi-loan" class="display-6">0</div>
        </div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card text-center">
        <div class="card-body">
          <h6>Repayments</h6>
          <div id="kpi-repay" class="display-6">0</div>
        </div>
      </div>
    </div>
  </div>

  <div class="card mt-4">
    <div class="card-header">Savings vs Outstanding (sample member)</div>
    <div class="card-body">
      <div class="row g-2 align-items-end">
        <div class="col-12 col-md-3">
          <form method="get">
            <label class="form-label">Member</label>
            <select id="member-select" class="form-select">
              <?php
                $db = DB::conn();
                $res = $db->query("SELECT member_id, name FROM members ORDER BY name");
                while ($r = $res->fetchArray(SQLITE3_ASSOC)) {
                  echo '<option value="'.$r['member_id'].'">'.htmlspecialchars($r['name']).'</option>';
                }
              ?>
            </select>
          </form>
        </div>
      </div>
      <canvas id="lineChart" height="120"></canvas>
    </div>
  </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
