<?php
// api.php
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/logic.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

try {
  switch ($action) {
    case 'kpis':
      $db = DB::conn();
      $members = (int)$db->querySingle("SELECT COUNT(*) FROM members");
      $savings = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM deposits");
      $loanPrincipal = (float)$db->querySingle("SELECT IFNULL(SUM(principal),0) FROM loans");
      $repayments = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM repayments");
      echo json_encode(['members'=>$members,'savings'=>$savings,'loan_principal'=>$loanPrincipal,'repayments'=>$repayments]);
      break;

    case 'member_balance':
      $memberId = (int)($_GET['member_id'] ?? 0);
      $db = DB::conn();
      $rows = [];
      $res = $db->query("SELECT as_of_month, saving_total, outstanding_loan, net_balance FROM balances WHERE member_id=$memberId ORDER BY as_of_month");
      while ($r = $res->fetchArray(SQLITE3_ASSOC)) { $rows[] = $r; }
      echo json_encode($rows);
      break;

    case 'recalc':
      recalc_all();
      echo json_encode(['ok'=>true]);
      break;

    case 'export':
      $type = $_GET['type'] ?? 'members';
      $db = DB::conn();
      $map = [
        'members' => 'SELECT * FROM members',
        'deposits' => 'SELECT * FROM deposits',
        'loans' => 'SELECT * FROM loans',
        'repayments' => 'SELECT * FROM repayments'
      ];
      if (!isset($map[$type])) { http_response_code(400); echo json_encode(['error'=>'bad type']); exit;}
      $res = $db->query($map[$type]);
      $out = fopen('php://output', 'w');
      header('Content-Type: text/csv');
      header('Content-Disposition: attachment; filename="'.$type.'.csv"');
      $first = true;
      while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
        if ($first) { fputcsv($out, array_keys($row)); $first=false; }
        fputcsv($out, array_values($row));
      }
      fclose($out);
      break;

    default:
      echo json_encode(['error'=>'unknown action']);
  }
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['error'=>$e->getMessage()]);
}
