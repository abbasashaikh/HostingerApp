<?php?>

<footer class="bg-light text-center py-3 mt-auto">
  <div class="container">
    <p class="mb-0 text-muted">&copy; 2025 SHG Manager. All rights reserved. | <a href="#" class="text-muted" onclick="toggleDarkMode()">Toggle Dark Mode</a></p>
  </div>
</footer>
<script>
// Simple dark mode toggle (add to all pages)
function toggleDarkMode() {
  document.body.classList.toggle('dark-mode');
}
</script>
<style>
/* Dark mode styles (add to global CSS or inline) */
.dark-mode { background: #1f2937; color: #f9fafb; }
.dark-mode .card { background: #374151; color: #f9fafb; }
.dark-mode .navbar { background: linear-gradient(90deg, #1e3a8a 80%, #3b82f6 100%) !important; }
.dark-mode .table { color: #f9fafb; }
</style>