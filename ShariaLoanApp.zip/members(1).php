<?php
// Updated members.php - Fixed numRows() error
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/logic.php';
require_once __DIR__ . '/header.php'; // Include header

$db = DB::conn();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = (int)($_POST['member_id'] ?? 0);
  $name = trim($_POST['name'] ?? '');
  if ($name === '') { header('Location: members.php?err=Name required'); exit; }
  $dob = $_POST['dob'] ?? null;
  $mobile = $_POST['mobile'] ?? null;
  $address = $_POST['address'] ?? null;
  $nominee = $_POST['nominee'] ?? null;
  $attach = null;
  if (!empty($_FILES['attach']['name'])) {
    $dir = __DIR__ . '/uploads';
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    $fname = time().'_'.basename($_FILES['attach']['name']);
    move_uploaded_file($_FILES['attach']['tmp_name'], $dir.'/'.$fname);
    $attach = 'uploads/'.$fname;
  }
  if ($id) {
    $sql = "UPDATE members SET name=:n, dob=:d, mobile=:m, address=:a, nominee=:no, updated_at=CURRENT_TIMESTAMP" . ($attach ? ", attach_proof_path=:p" : "") . " WHERE member_id=:id";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
  } else {
    $stmt = $db->prepare("INSERT INTO members(name,dob,mobile,address,nominee,attach_proof_path) VALUES(:n,:d,:m,:a,:no,:p)");
  }
  $stmt->bindValue(':n', $name);
  $stmt->bindValue(':d', $dob);
  $stmt->bindValue(':m', $mobile);
  $stmt->bindValue(':a', $address);
  $stmt->bindValue(':no', $nominee);
  if ($attach) $stmt->bindValue(':p', $attach);
  $stmt->execute();
  header('Location: members.php?ok=1'); exit;
}

if (isset($_GET['del'])) {
  $id = (int)$_GET['del'];
  $db->exec("DELETE FROM members WHERE member_id=$id");
  header('Location: members.php?ok=1'); exit;
}

// Fixed: Separate count query instead of numRows() on result object
$count_members = (int)$db->querySingle("SELECT COUNT(*) FROM members");
$res = $db->query("SELECT * FROM members ORDER BY name"); // Renamed to $res for loop
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Members - SHG Manager</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    /* Reuse styles from dashboard */
    :root {
      --primary-blue: #2563eb;
      --gradient-blue: linear-gradient(90deg, #2563eb 80%, #60a5fa 100%);
      --success-green: #10B981;
      --warning-orange: #F59E0B;
      --bg-light: #f7f9fb;
      --card-shadow: 0 2px 12px rgba(171, 194, 226, 0.1);
      --text-primary: #1f2937;
    }
    [data-theme="dark"] {
      --bg-light: #1f2937;
      --text-primary: #f9fafb;
      --card-shadow: 0 2px 12px rgba(0, 0, 0, 0.3);
    }
    body { background: var(--bg-light); color: var(--text-primary); font-family: sans-serif; }
    .card { border-radius: 1rem; box-shadow: var(--card-shadow); border: none; transition: transform 0.2s ease; }
    .card:hover { transform: translateY(-2px); }
    .table { border-radius: 0.5rem; overflow: hidden; }
    .btn-primary { background: var(--gradient-blue); border: none; }
    .form-control, .form-select { border-radius: 0.7rem; }
    label.form-label { font-weight: 500; color: var(--text-primary); }
    .table th { background: #e0e7ef; color: var(--primary-blue); font-weight: 600; }
    @media (max-width: 768px) { .row.g-3 > div { margin-bottom: 1rem; } }
  </style>
</head>
<body data-theme="light">
<div class="container py-4">
  <?php if (isset($_GET['ok'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      Member saved successfully!
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>
  <?php if (isset($_GET['err'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <?= htmlspecialchars($_GET['err']) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
      <h5><i class="bi bi-person-plus"></i> Add/Edit Member</h5>
      <a href="members.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Back to List</a>
      <a class="btn btn-secondary" href="index.php">Dashboard</a>
    </div>
    <div class="card-body">
      <form class="row g-3" method="post" enctype="multipart/form-data">
        <input type="hidden" name="member_id" value="">
        <div class="col-md-4">
          <label class="form-label">Name <span class="text-danger">*</span></label>
          <input class="form-control" name="name" required>
        </div>
        <div class="col-md-4">
          <label class="form-label">Date of Birth</label>
          <input type="date" class="form-control" name="dob">
        </div>
        <div class="col-md-4">
          <label class="form-label">Mobile</label>
          <input class="form-control" name="mobile">
        </div>
        <div class="col-md-6">
          <label class="form-label">Address</label>
          <input class="form-control" name="address">
        </div>
        <div class="col-md-6">
          <label class="form-label">Nominee</label>
          <input class="form-control" name="nominee">
        </div>
        <div class="col-md-6">
          <label class="form-label">Attach Proof</label>
          <input type="file" class="form-control" name="attach" accept="image/*,.pdf">
          <small class="form-text text-muted">JPG, PDF up to 5MB</small>
        </div>
        <select name="special_status" class="form-select">
          <option value="">Active</option>
          <option value="expire" <?=($r['special_status']=='expire'?'selected':'')?>>Deceased/Expired</option>
          <option value="major_loss" <?=($r['special_status']=='major_loss'?'selected':'')?>>Major loss/disease</option>
        </select>

        <div class="col-12">
          <button class="btn btn-primary"><i class="bi bi-save"></i> Save Member</button>
        </div>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <h5><i class="bi bi-people"></i> Members List (<?= $count_members ?>)</h5>
    </div>
    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead class="table-light">
            <tr>
              <th>Name</th>
              <th>Mobile</th>
              <th>Address</th>
              <th>Nominee</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
            while ($r = $res->fetchArray(SQLITE3_ASSOC)) {
              echo "<tr>
                <td><strong>".htmlspecialchars($r['name'])."</strong></td>
                <td>".htmlspecialchars((string)$r['mobile'])."</td>
                <td>".htmlspecialchars((string)$r['address'])."</td>
                <td>".htmlspecialchars((string)$r['nominee'])."</td>
                <td class='text-end'>
                  <a class='btn btn-sm btn-outline-primary me-1' href='members.php?edit={$r['member_id']}'><i class='bi bi-pencil'></i> Edit</a>
                  <a class='btn btn-sm btn-outline-danger' href='members.php?del={$r['member_id']}' onclick='return confirm(\"Delete?\")'><i class='bi bi-trash'></i> Delete</a>
                </td>
              </tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Handle edit (populate form via JS)
<?php if (isset($_GET['edit'])): 
  $edit_id = (int)$_GET['edit'];
  $edit_member = $db->querySingle("SELECT * FROM members WHERE member_id = $edit_id", true);
  if ($edit_member): ?>
    document.addEventListener('DOMContentLoaded', function() {
      document.querySelector('[name="member_id"]').value = '<?= $edit_member['member_id'] ?>';
      document.querySelector('[name="name"]').value = '<?= addslashes($edit_member['name']) ?>';
      document.querySelector('[name="dob"]').value = '<?= $edit_member['dob'] ?? '' ?>';
      document.querySelector('[name="mobile"]').value = '<?= addslashes($edit_member['mobile'] ?? '') ?>';
      document.querySelector('[name="address"]').value = '<?= addslashes($edit_member['address'] ?? '') ?>';
      document.querySelector('[name="nominee"]').value = '<?= addslashes($edit_member['nominee'] ?? '') ?>';
    });
    // Show edit alert
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-info alert-dismissible fade show';
    alertDiv.innerHTML = 'Editing: <?= htmlspecialchars($edit_member['name']) ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    document.querySelector('.container').insertBefore(alertDiv, document.querySelector('.card'));
  <?php endif; 
endif; ?>
</script>
</body>
</html>