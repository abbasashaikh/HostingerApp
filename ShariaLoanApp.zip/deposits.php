<?php
// Updated deposits.php

declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/logic.php';
require_once __DIR__ . '/header.php'; // Include header

$db = DB::conn();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $stmt = $db->prepare("INSERT INTO deposits(member_id,date,amount,kind,note) VALUES(:m,:d,:a,:k,:n)");
  $stmt->bindValue(':m', (int)$_POST['member_id'], SQLITE3_INTEGER);
  $stmt->bindValue(':d', $_POST['date']);
  $stmt->bindValue(':a', (float)$_POST['amount']);
  $stmt->bindValue(':k', $_POST['kind']);
  $stmt->bindValue(':n', $_POST['note']);
  $stmt->execute();
  calc_member_balances((int)$_POST['member_id'], substr($_POST['date'],0,7));
  header('Location: deposits.php?ok=1'); exit;
}

$deposits_res = $db->query("SELECT d.*, m.name FROM deposits d JOIN members m ON m.member_id=d.member_id ORDER BY d.date DESC");
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Deposits - SHG Manager</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    /* Reuse styles from dashboard */
    :root {
      --primary-blue: #2563eb;
      --gradient-blue: linear-gradient(90deg, #2563eb 80%, #60a5fa 100%);
      --success-green: #10B981;
      --warning-orange: #F59E0B;
      --bg-light: #f7f9fb;
      --card-shadow: 0 2px 12px rgba(171, 194, 226, 0.1);
      --text-primary: #1f2937;
    }
    [data-theme="dark"] {
      --bg-light: #1f2937;
      --text-primary: #f9fafb;
      --card-shadow: 0 2px 12px rgba(0, 0, 0, 0.3);
    }
    body { background: var(--bg-light); color: var(--text-primary); font-family: sans-serif; }
    .card { border-radius: 1rem; box-shadow: var(--card-shadow); border: none; transition: transform 0.2s ease; }
    .card:hover { transform: translateY(-2px); }
    .table { border-radius: 0.5rem; overflow: hidden; }
    .btn-primary { background: var(--gradient-blue); border: none; }
    .form-control, .form-select { border-radius: 0.7rem; }
    label.form-label { font-weight: 500; color: var(--text-primary); }
    .table th { background: #e0e7ef; color: var(--primary-blue); font-weight: 600; }
    .table-success { background-color: rgba(16, 185, 129, 0.1); }
    @media (max-width: 768px) { .row.g-3 > div { margin-bottom: 1rem; } }
  </style>
</head>
<body data-theme="light">
<div class="container py-4">
  <?php if (isset($_GET['ok'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      Deposit added successfully!
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
      <h5><i class="bi bi-plus-circle"></i> Add Deposit</h5>
     
     
    </div>
    <div class="card-body">
      <form class="row g-3" method="post">
        <div class="col-md-4">
          <label class="form-label">Member <span class="text-danger">*</span></label>
          <select class="form-select" name="member_id" required>
            <?php
            $res = $db->query("SELECT member_id, name FROM members ORDER BY name");
            while ($r = $res->fetchArray(SQLITE3_ASSOC)) {
              echo '<option value="'.$r['member_id'].'">'.htmlspecialchars($r['name']).'</option>';
            }
            ?>
          </select>
        </div>
        <div class="col-md-3">
          <label class="form-label">Date <span class="text-danger">*</span></label>
          <input type="date" class="form-control" name="date" value="<?= date('Y-m-d') ?>" required>
        </div>
        <div class="col-md-3">
          <label class="form-label">Amount (₹) <span class="text-danger">*</span></label>
          <input type="number" step="0.01" class="form-control" name="amount" required min="0">
        </div>
        <div class="col-md-2">
          <label class="form-label">Type</label>
          <select class="form-select" name="kind">
            <option value="SAVING">Saving</option>
            <option value="EMI">EMI</option>
          </select>
        </div>
        <div class="col-12">
          <label class="form-label">Note</label>
          <input class="form-control" name="note" placeholder="e.g., Monthly EMI">
        </div>
        <div class="col-12">
          <button class="btn btn-primary"><i class="bi bi-download"></i> Add Deposit</button>
        </div>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <h5><i class="bi bi-list-ul"></i> Recent Deposits</h5>
    </div>
    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead class="table-light">
            <tr>
              <th>Date</th>
              <th>Member</th>
              <th>Type</th>
              <th class="text-end">Amount</th>
              <th>Note</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $sql = "SELECT d.date, m.name, d.kind, d.amount, d.note FROM deposits d JOIN members m ON m.member_id=d.member_id ORDER BY d.date DESC LIMIT 50";
            $res = $db->query($sql);
            while ($r = $res->fetchArray(SQLITE3_ASSOC)) {
              $rowClass = $r['kind'] === 'EMI' ? 'table-success' : '';
              echo "<tr class='$rowClass'>
                <td><strong>".htmlspecialchars($r['date'])."</strong></td>
                <td>".htmlspecialchars($r['name'])."</td>
                <td><span class='badge bg-success'>".htmlspecialchars($r['kind'])."</span></td>
                <td class='text-end fw-bold'>₹".number_format((float)$r['amount'],2)."</td>
                <td>".htmlspecialchars($r['note'] ?: '-')."</td>
              </tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>