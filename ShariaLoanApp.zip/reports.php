<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';
$db = DB::conn();
$ym = $_GET['month'] ?? date('Y-m');
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Reports</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4>Reports</h4>
    <a class="btn btn-secondary" href="index.php">Dashboard</a>
  </div>

  <form class="row g-2 mb-3">
    <div class="col-auto">
      <label class="form-label">Month</label>
      <input type="month" class="form-control" name="month" value="<?php echo htmlspecialchars($ym); ?>">
    </div>
    <div class="col-auto align-self-end"><button class="btn btn-primary">View</button></div>
    <div class="col-auto align-self-end">
      <a class="btn btn-outline-success" href="api.php?action=export&type=members">Export Members</a>
      <a class="btn btn-outline-success" href="api.php?action=export&type=deposits">Export Deposits</a>
      <a class="btn btn-outline-success" href="api.php?action=export&type=loans">Export Loans</a>
      <a class="btn btn-outline-success" href="api.php?action=export&type=repayments">Export Repayments</a>
    </div>
  </form>

  <div class="row g-3">
    <div class="col-lg-6">
      <div class="card">
        <div class="card-header">Monthly Totals</div>
        <div class="card-body">
          <?php
            $s = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM deposits WHERE substr(date,1,7)='$ym'");
            $l = (float)$db->querySingle("SELECT IFNULL(SUM(principal),0) FROM loans WHERE substr(disbursed_date,1,7)='$ym'");
            $r = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM repayments WHERE substr(repayment_date,1,7)='$ym'");
          ?>
          <ul>
            <li>Savings/EMI deposits: <?php echo number_format($s,2); ?></li>
            <li>Loans disbursed: <?php echo number_format($l,2); ?></li>
            <li>Repayments: <?php echo number_format($r,2); ?></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="card">
        <div class="card-header">Overall Totals</div>
        <div class="card-body">
          <?php
            $s2 = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM deposits");
            $l2 = (float)$db->querySingle("SELECT IFNULL(SUM(principal),0) FROM loans");
            $r2 = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM repayments");
          ?>
          <ul>
            <li>Total savings: <?php echo number_format($s2,2); ?></li>
            <li>Total loan principal: <?php echo number_format($l2,2); ?></li>
            <li>Total repayments: <?php echo number_format($r2,2); ?></li>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <div class="card mt-3">
    <div class="card-header">Balances by Member (as of <?php echo htmlspecialchars($ym); ?>)</div>
    <div class="card-body">
      <table class="table table-sm table-striped">
        <thead><tr><th>Member</th><th class="text-end">Savings Total</th><th class="text-end">Outstanding Loan</th><th class="text-end">Net Balance</th></tr></thead>
        <tbody>
          <?php
            $sql = "SELECT m.name, b.saving_total, b.outstanding_loan, b.net_balance
                    FROM balances b JOIN members m ON m.member_id=b.member_id
                    WHERE b.as_of_month='$ym' ORDER BY m.name";
            $res = $db->query($sql);
            while ($r = $res->fetchArray(SQLITE3_ASSOC)) {
              echo "<tr>
                <td>".htmlspecialchars($r['name'])."</td>
                <td class='text-end'>".number_format((float)$r['saving_total'],2)."</td>
                <td class='text-end'>".number_format((float)$r['outstanding_loan'],2)."</td>
                <td class='text-end'>".number_format((float)$r['net_balance'],2)."</td>
              </tr>";
            }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body>
</html>
