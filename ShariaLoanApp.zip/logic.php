<?php
// logic.php
declare(strict_types=1);
require_once __DIR__ . '/db.php';

function ym(string $date): string { return substr($date, 0, 7); } // YYYY-MM

function calc_member_balances(int $memberId, ?string $uptoYm = null): void {
  $db = DB::conn();

  // Determine range of months to recompute
  $minYm = null; $maxYm = $uptoYm;
  $res = $db->query("SELECT MIN(substr(date,1,7)) AS m FROM deposits WHERE member_id=$memberId");
  if ($row = $res->fetchArray(SQLITE3_ASSOC)) { $minYm = $row['m']; }
  $res = $db->query("SELECT MIN(substr(disbursed_date,1,7)) AS m FROM loans WHERE member_id=$memberId");
  if ($r = $res->fetchArray(SQLITE3_ASSOC)) { if ($r['m'] && (!$minYm || $r['m'] < $minYm)) $minYm = $r['m']; }
  $res = $db->query("SELECT MIN(substr(repayment_date,1,7)) AS m FROM repayments WHERE member_id=$memberId");
  if ($r = $res->fetchArray(SQLITE3_ASSOC)) { if ($r['m'] && (!$minYm || $r['m'] < $minYm)) $minYm = $r['m']; }
  if (!$minYm) { return; }

  if (!$maxYm) {
    $res = $db->query("SELECT MAX(m) as mx FROM (
      SELECT MAX(substr(date,1,7)) m FROM deposits WHERE member_id=$memberId
      UNION ALL
      SELECT MAX(substr(disbursed_date,1,7)) m FROM loans WHERE member_id=$memberId
      UNION ALL
      SELECT MAX(substr(repayment_date,1,7)) m FROM repayments WHERE member_id=$memberId
    )");
    $row = $res->fetchArray(SQLITE3_ASSOC);
    $maxYm = $row['mx'] ?? date('Y-m');
  }

  // Iterate months
  $cur = new DateTime($minYm.'-01');
  $end = new DateTime($maxYm.'-01');

  // Rolling aggregates
  $savingCum = 0.0;
  $loanPrincipalCum = 0.0;
  $repayCum = 0.0;

  while ($cur <= $end) {
    $curYm = $cur->format('Y-m');

    // Period increments
    $savingInc = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM deposits WHERE member_id=$memberId AND substr(date,1,7)='$curYm'");
    $loanInc = (float)$db->querySingle("SELECT IFNULL(SUM(principal),0) FROM loans WHERE member_id=$memberId AND substr(disbursed_date,1,7)='$curYm'");
    $repayInc = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM repayments WHERE member_id=$memberId AND substr(repayment_date,1,7)='$curYm'");

    $savingCum += $savingInc;
    $loanPrincipalCum += $loanInc;
    $repayCum += $repayInc;

    $outstanding = $loanPrincipalCum - $repayCum;
    $net = $savingCum - $outstanding;

    $stmt = $db->prepare("INSERT INTO balances(member_id, as_of_month, saving_total, loan_principal_total, repayment_total, outstanding_loan, net_balance)
      VALUES(:mid,:ym,:s,:lp,:rp,:out,:net)
      ON CONFLICT(member_id, as_of_month) DO UPDATE SET
        saving_total=excluded.saving_total,
        loan_principal_total=excluded.loan_principal_total,
        repayment_total=excluded.repayment_total,
        outstanding_loan=excluded.outstanding_loan,
        net_balance=excluded.net_balance
    ");
    $stmt->bindValue(':mid', $memberId, SQLITE3_INTEGER);
    $stmt->bindValue(':ym', $curYm, SQLITE3_TEXT);
    $stmt->bindValue(':s', $savingCum, SQLITE3_FLOAT);
    $stmt->bindValue(':lp', $loanPrincipalCum, SQLITE3_FLOAT);
    $stmt->bindValue(':rp', $repayCum, SQLITE3_FLOAT);
    $stmt->bindValue(':out', $outstanding, SQLITE3_FLOAT);
    $stmt->bindValue(':net', $net, SQLITE3_FLOAT);
    $stmt->execute();

    $cur->modify('+1 month');
  }
}

function recalc_all(): void {
  $db = DB::conn();
  $res = $db->query("SELECT member_id FROM members");
  while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
    calc_member_balances((int)$row['member_id'], null);
  }
}
