<?php
ob_start(); // Buffer output to allow headers
session_start(); // Explicit start at top

$error = $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Simple CSRF check (generate token on load)
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = 'Invalid request';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($username === 'admin' && $password === 'admin123') {
            $_SESSION['logged_in'] = true;
            $_SESSION['username'] = $username;
            ob_end_clean(); // Clear buffer
            header('Location: index.php');
            exit;
        } else {
            $error = 'Invalid credentials. Username: admin, Password: admin123';
        }
    }
}

// Generate CSRF token if not set
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
    header('Location: index.php');
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Login - SHG Manager</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); font-family: sans-serif; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
    .login-card { border-radius: 1rem; box-shadow: 0 10px 30px rgba(0,0,0,0.1); max-width: 400px; width: 100%; background: white; }
    .login-header { background: linear-gradient(90deg, #2563eb 80%, #60a5fa 100%); color: white; border-radius: 1rem 1rem 0 0; padding: 1.5rem; text-align: center; }
    .btn-primary { background: linear-gradient(90deg, #2563eb 80%, #60a5fa 100%); border: none; width: 100%; padding: 0.75rem; }
    .form-control:focus { border-color: #2563eb; box-shadow: 0 0 0 0.2rem rgba(37, 99, 235, 0.25); }
    .spinner-border-sm { width: 1rem; height: 1rem; }
  </style>
</head>
<body>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="login-card">
          <div class="login-header">
            <i class="bi bi-bank2" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
            <h4>SHG Manager</h4>
            <p class="mb-0 opacity-75">Admin Login</p>
          </div>
          <div class="card-body p-4">
            <?php if ($error): ?>
              <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>
            <?php endif; ?>
            <?php if ($success): ?>
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>
            <?php endif; ?>
            <form method="POST" id="loginForm">
              <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
              <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" value="admin" required autocomplete="username">
              </div>
              <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required autocomplete="current-password">
                <small class="form-text text-muted">Default: admin123</small>
              </div>
              <button type="submit" class="btn btn-primary" id="loginBtn">
                <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                Login
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.getElementById('loginForm').addEventListener('submit', function() {
      const btn = document.getElementById('loginBtn');
      const spinner = btn.querySelector('.spinner-border');
      spinner.classList.remove('d-none');
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Logging in...';
    });
  </script>
</body>
</html>