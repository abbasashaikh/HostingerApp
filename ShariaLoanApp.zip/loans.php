<?php
// Updated loans.php

declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/logic.php';
require_once __DIR__ . '/header.php'; // Include header

$db = DB::conn();

/*
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'loan') {
  $stmt = $db->prepare("INSERT INTO loans(member_id,disbursed_date,principal,status,note) VALUES(:m,:d,:p,'ACTIVE',:n)");
  $stmt->bindValue(':m', (int)$_POST['member_id'], SQLITE3_INTEGER);
  $stmt->bindValue(':d', $_POST['disbursed_date']);
  $stmt->bindValue(':p', (float)$_POST['principal']);
  $stmt->bindValue(':n', $_POST['note']);
  $stmt->execute();
  calc_member_balances((int)$_POST['member_id'], substr($_POST['disbursed_date'],0,7));
  header('Location: loans.php?ok=1'); exit;
}
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'loan') {
  $member_id = intval($_POST['member_id']);
  $principal = floatval($_POST['principal']);
  $g1 = intval($_POST['guarantor1_id']);
  $g2 = intval($_POST['guarantor2_id']);
  $note = $_POST['note'] ?? '';
  $disbursed_date = $_POST['disbursed_date'];

  // RULE: Must have two different guarantors who are existing members
  if (!$g1 || !$g2 || $g1 === $g2) {
    die("Guarantors are required and must be TWO different existing members.");
  }
  // RULE: Cannot borrow more than 3x deposits
  $total_deposits = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM deposits WHERE member_id=$member_id");
  $existing_loans = (float)$db->querySingle("SELECT IFNULL(SUM(principal),0) FROM loans WHERE member_id=$member_id AND status='ACTIVE'");
  // If you want to strictly accumulate current open principal, adjust as needed.

  if (($principal+$existing_loans) > 3*$total_deposits) {
    die("Loan limit exceeded. Max allowed is 3x total deposits: ".number_format(3*$total_deposits,2));
  }

  $stmt = $db->prepare("INSERT INTO loans(member_id,disbursed_date,principal,guarantor1_id,guarantor2_id,status,note)
      VALUES(:m,:d,:p,:g1,:g2,'ACTIVE',:n)");
  $stmt->bindValue(':m', $member_id, SQLITE3_INTEGER);
  $stmt->bindValue(':d', $disbursed_date);
  $stmt->bindValue(':p', $principal);
  $stmt->bindValue(':g1', $g1, SQLITE3_INTEGER);
  $stmt->bindValue(':g2', $g2, SQLITE3_INTEGER);
  $stmt->bindValue(':n', $note);
  $stmt->execute();
  calc_member_balances($member_id, substr($disbursed_date, 0, 7));
  header('Location: loans.php?ok=1'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'repay') {
  $stmt = $db->prepare("INSERT INTO repayments(loan_id,member_id,repayment_date,amount,note) VALUES(:l,:m,:d,:a,:n)");
  $stmt->bindValue(':l', (int)$_POST['loan_id'], SQLITE3_INTEGER);
  $stmt->bindValue(':m', (int)$_POST['member_id'], SQLITE3_INTEGER);
  $stmt->bindValue(':d', $_POST['repayment_date']);
  $stmt->bindValue(':a', (float)$_POST['amount']);
  $stmt->bindValue(':n', $_POST['note']);
  $stmt->execute();
  // Auto-close loan if fully repaid
  $loanId = (int)$_POST['loan_id'];
  $paid = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM repayments WHERE loan_id=$loanId");
  $principal = (float)$db->querySingle("SELECT principal FROM loans WHERE loan_id=$loanId");
  if ($paid >= $principal) { $db->exec("UPDATE loans SET status='CLOSED' WHERE loan_id=$loanId"); }
  calc_member_balances((int)$_POST['member_id'], substr($_POST['repayment_date'],0,7));
  header('Location: loans.php?ok=1'); exit;
}

$members = $db->query("SELECT member_id,name FROM members ORDER BY name");
$loans = $db->query("SELECT l.*, m.name FROM loans l JOIN members m ON m.member_id=l.member_id ORDER BY disbursed_date DESC");
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Loans - SHG Manager</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    /* Reuse styles */
    :root {
      --primary-blue: #2563eb;
      --gradient-blue: linear-gradient(90deg, #2563eb 80%, #60a5fa 100%);
      --success-green: #10B981;
      --warning-orange: #F59E0B;
      --bg-light: #f7f9fb;
      --card-shadow: 0 2px 12px rgba(171, 194, 226, 0.1);
      --text-primary: #1f2937;
    }
    [data-theme="dark"] {
      --bg-light: #1f2937;
      --text-primary: #f9fafb;
      --card-shadow: 0 2px 12px rgba(0, 0, 0, 0.3);
    }
    body { background: var(--bg-light); color: var(--text-primary); font-family: sans-serif; }
    .card { border-radius: 1rem; box-shadow: var(--card-shadow); border: none; transition: transform 0.2s ease; }
    .card:hover { transform: translateY(-2px); }
    .table { border-radius: 0.5rem; overflow: hidden; }
    .btn-primary { background: var(--gradient-blue); border: none; }
    .form-control, .form-select { border-radius: 0.7rem; }
    label.form-label { font-weight: 500; color: var(--text-primary); }
    .table th { background: #e0e7ef; color: var(--primary-blue); font-weight: 600; }
    .badge-success { background: var(--success-green); }
    @media (max-width: 768px) { .row.g-4 > div { margin-bottom: 1rem; } }
  </style>
</head>
<body data-theme="light">
<div class="container py-4">
  <?php if (isset($_GET['ok'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      Loan/Repayment recorded successfully!
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <div class="row g-4">
      
    <div class="col-lg-6">
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h5><i class="bi bi-cash-coin"></i> Disburse New Loan</h5>
        </div>
        <div class="card-body">
          <form class="row g-3" method="post">
            <input type="hidden" name="form" value="loan">
            <div class="col-12">
              <label class="form-label">Member <span class="text-danger">*</span></label>
              <select class="form-select" name="member_id" required>
                <?php while ($m = $members->fetchArray(SQLITE3_ASSOC)) { 
                  echo "<option value='{$m['member_id']}'>".htmlspecialchars($m['name'])."</option>";
                } ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Disbursed Date <span class="text-danger">*</span></label>
              <input type="date" class="form-control" name="disbursed_date" value="<?= date('Y-m-d') ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Principal Amount (₹) <span class="text-danger">*</span></label>
              <input type="number" step="0.01" class="form-control" name="principal" required min="0">
            </div>
            <div class="col-6">
              <label class="form-label">Guarantor 1</label>
              <select class="form-select" name="guarantor1_id" required>
                <option value="">Select Member</option>
                <?php
                  $mem_res1 = $db->query("SELECT member_id,name FROM members ORDER BY name");
                  while($m=$mem_res1->fetchArray(SQLITE3_ASSOC)) {
                    echo "<option value='{$m['member_id']}'>".htmlspecialchars($m['name'])."</option>";
                  }
                ?>
              </select>
                        </div>
            <div class="col-6">
              <label class="form-label">Guarantor 2</label>
              <select class="form-select" name="guarantor2_id" required>
                <option value="">Select Member</option>
                <?php
                  $mem_res2 = $db->query("SELECT member_id,name FROM members ORDER BY name");
                  while($m=$mem_res2->fetchArray(SQLITE3_ASSOC)) {
                    echo "<option value='{$m['member_id']}'>".htmlspecialchars($m['name'])."</option>";
                  }
                ?>
              </select>
            </div>
            <div class="col-12">
              <label class="form-label">Note</label>
              <input class="form-control" name="note" placeholder="e.g., Business loan">
            </div>
            <div class="col-12">
              <button class="btn btn-primary"><i class="bi bi-send"></i> Disburse Loan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h5><i class="bi bi-arrow-return-right"></i> Record Repayment</h5>
        </div>
        <div class="card-body">
          <form class="row g-3" method="post">
            <input type="hidden" name="form" value="repay">
            <div class="col-12">
              <label class="form-label">Loan <span class="text-danger">*</span></label>
              <select class="form-select" name="loan_id" required>
                <?php
                $lr = $db->query("SELECT l.loan_id, l.principal, l.status, m.name FROM loans l JOIN members m ON m.member_id=l.member_id WHERE l.status='ACTIVE' ORDER BY l.disbursed_date DESC");
                while ($l = $lr->fetchArray(SQLITE3_ASSOC)) {
                  $label = $l['loan_id']." - ".htmlspecialchars($l['name'])." (₹".number_format($l['principal'], 2).")";
                  echo "<option value='{$l['loan_id']}'>$label</option>";
                }
                ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Member <span class="text-danger">*</span></label>
              <select class="form-select" name="member_id" required>
                <?php
                $mr = $db->query("SELECT member_id,name FROM members ORDER BY name");
                while ($m = $mr->fetchArray(SQLITE3_ASSOC)) { 
                  echo "<option value='{$m['member_id']}'>".htmlspecialchars($m['name'])."</option>"; 
                }
                ?>
              </select>
            </div>
            <div class="col-md-3">
              <label class="form-label">Date <span class="text-danger">*</span></label>
              <input type="date" class="form-control" name="repayment_date" value="<?= date('Y-m-d') ?>" required>
            </div>
            <div class="col-md-3">
              <label class="form-label">Amount (₹) <span class="text-danger">*</span></label>
              <input type="number" step="0.01" class="form-control" name="amount" required min="0">
            </div>
            <div class="col-12">
              <label class="form-label">Note</label>
              <input class="form-control" name="note" placeholder="e.g., EMI Payment">
            </div>
            <div class="col-12">
              <button class="btn btn-success"><i class="bi bi-check-lg"></i> Record Repayment</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <div class="card mt-4">
    <div class="card-header">
      <h5><i class="bi bi-list-check"></i> All Loans</h5>
    </div>
    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead class="table-light">
            <tr>
              <th>Date</th>
              <th>Member</th>
              <th>Status</th>
              <th class="text-end">Principal</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php while ($l = $loans->fetchArray(SQLITE3_ASSOC)) {
              $statusBadge = $l['status'] === 'ACTIVE' ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Closed</span>';
              echo "<tr>
                <td><strong>".htmlspecialchars($l['disbursed_date'])."</strong></td>
                <td>".htmlspecialchars($l['name'])."</td>
                <td>$statusBadge</td>
                <td class='text-end fw-bold'>₹".number_format((float)$l['principal'],2)."</td>
                <td class='text-end'>
                  <a class='btn btn-sm btn-outline-info me-1' href='loan_details.php?id={$l['loan_id']}'><i class='bi bi-eye'></i> View</a>
                  <button class='btn btn-sm btn-outline-warning' onclick='editLoan({$l['loan_id']})'><i class='bi bi-pencil'></i> Edit</button>
                </td>
              </tr>";
            } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function editLoan(id) {
  // Modal for edit (expand as needed)
  alert('Edit functionality - open modal for loan ' + id);
}
</script>
</body>
</html>