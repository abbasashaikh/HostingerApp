<?php
// db.php
declare(strict_types=1);

// Ensure session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: login.php');
    exit;
}
class DB {
  private static ?SQLite3 $conn = null;

  public static function conn(): SQLite3 {
    if (self::$conn === null) {
      $dbPath = __DIR__ . '/data/shg.sqlite';
      if (!is_dir(dirname($dbPath))) { mkdir(dirname($dbPath), 0775, true); }
      self::$conn = new SQLite3($dbPath);
      self::$conn->exec('PRAGMA foreign_keys = ON;');
      self::migrate();
    }
    return self::$conn;
  }


  private static function migrate(): void {
    $sql = [
      "CREATE TABLE IF NOT EXISTS members (
        member_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        dob TEXT,
        mobile TEXT,
        address TEXT,
        nominee TEXT,
        attach_proof_path TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
      );",
      "CREATE TABLE IF NOT EXISTS deposits (
        deposit_id INTEGER PRIMARY KEY AUTOINCREMENT,
        member_id INTEGER NOT NULL,
        date TEXT NOT NULL,
        amount REAL NOT NULL CHECK(amount>=0),
        kind TEXT NOT NULL CHECK(kind IN ('SAVING','EMI')),
        note TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(member_id) REFERENCES members(member_id) ON DELETE CASCADE
      );",
      "CREATE TABLE IF NOT EXISTS loans (
        loan_id INTEGER PRIMARY KEY AUTOINCREMENT,
        member_id INTEGER NOT NULL,
        disbursed_date TEXT NOT NULL,
        principal REAL NOT NULL CHECK(principal>0),
        status TEXT NOT NULL CHECK(status IN ('ACTIVE','CLOSED')) DEFAULT 'ACTIVE',
        note TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(member_id) REFERENCES members(member_id) ON DELETE CASCADE
      );",
      "CREATE TABLE IF NOT EXISTS repayments (
        repayment_id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER NOT NULL,
        member_id INTEGER NOT NULL,
        repayment_date TEXT NOT NULL,
        amount REAL NOT NULL CHECK(amount>0),
        note TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(loan_id) REFERENCES loans(loan_id) ON DELETE CASCADE,
        FOREIGN KEY(member_id) REFERENCES members(member_id) ON DELETE CASCADE
      );",
      "CREATE TABLE IF NOT EXISTS balances (
        member_id INTEGER NOT NULL,
        as_of_month TEXT NOT NULL, /* YYYY-MM */
        saving_total REAL NOT NULL DEFAULT 0,
        loan_principal_total REAL NOT NULL DEFAULT 0,
        repayment_total REAL NOT NULL DEFAULT 0,
        outstanding_loan REAL NOT NULL DEFAULT 0,
        net_balance REAL NOT NULL DEFAULT 0,
        PRIMARY KEY(member_id, as_of_month),
        FOREIGN KEY(member_id) REFERENCES members(member_id) ON DELETE CASCADE
      );",
      "CREATE INDEX IF NOT EXISTS idx_deposits_member_date ON deposits(member_id, date);",
      "CREATE INDEX IF NOT EXISTS idx_loans_member_date ON loans(member_id, disbursed_date);",
      "CREATE INDEX IF NOT EXISTS idx_repayments_member_date ON repayments(member_id, repayment_date);"
    ];
    $db = self::conn();
    foreach ($sql as $q) { $db->exec($q); }
  }
}
