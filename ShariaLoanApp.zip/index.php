<?php
// Updated index.php (dashboard) - with improvements

declare(strict_types=1);
require_once 'db.php';
require_once 'logic.php';
require_once 'header.php'; // Include new header

$db = DB::conn();
$members = (int)$db->querySingle("SELECT COUNT(*) FROM members");
$savings = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM deposits");
$loanPrincipal = (float)$db->querySingle("SELECT IFNULL(SUM(principal),0) FROM loans");
$repayments = (float)$db->querySingle("SELECT IFNULL(SUM(amount),0) FROM repayments");
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Dashboard - SHG Manager</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    :root {
      --primary-blue: #2563eb;
      --gradient-blue: linear-gradient(90deg, #2563eb 80%, #60a5fa 100%);
      --success-green: #10B981;
      --warning-orange: #F59E0B;
      --bg-light: #f7f9fb;
      --card-shadow: 0 2px 12px rgba(171, 194, 226, 0.1);
      --text-primary: #1f2937;
    }
    [data-theme="dark"] {
      --bg-light: #1f2937;
      --text-primary: #f9fafb;
      --card-shadow: 0 2px 12px rgba(0, 0, 0, 0.3);
    }
    body { background: var(--bg-light); color: var(--text-primary); font-family: sans-serif; }
    .navbar { background: var(--gradient-blue); box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .navbar-brand { font-weight: 700; font-size: 1.3rem; }
    .card { border-radius: 1rem; box-shadow: var(--card-shadow); border: none; transition: transform 0.2s ease, box-shadow 0.2s ease; }
    .card:hover { transform: translateY(-4px); box-shadow: 0 8px 25px rgba(37, 99, 235, 0.15); }
    .kpi-title { color: var(--text-primary); font-weight: 600; font-size: 1rem; text-transform: uppercase; letter-spacing: 0.5px; }
    .kpi-val { font-size: 2.5rem; font-weight: 700; color: var(--primary-blue); margin: 0.5rem 0; line-height: 1.2; }
    .btn-primary { background: var(--gradient-blue); border: none; }
    .btn-primary:hover { transform: scale(1.05); }
    .card-header { background: #e0e7ef; border-radius: 1rem 1rem 0 0; font-weight: 600; color: var(--primary-blue); }
    label.form-label { font-weight: 500; }
    .form-select, .form-control { border-radius: 0.7rem; }
    #lineChart { max-height: 300px; }
    @media (max-width: 768px) { .kpi-val { font-size: 1.8rem; } .kpi-title { font-size: 0.9rem; } }
  </style>
</head>
<body data-theme="light">
<main class="container my-4">
  <div class="row g-3 justify-content-center">
    <div class="col-6 col-sm-3">
      <div class="card text-center h-100">
        <div class="card-body d-flex flex-column justify-content-center">
          <i class="bi bi-people-fill text-primary mb-2" style="font-size: 2rem;" aria-hidden="true"></i>
          <div class="kpi-title">Members</div>
          <div id="kpi-members" class="kpi-val"><?php echo $members; ?></div>
          <small class="text-muted">Active Users</small>
        </div>
      </div>
    </div>
    <div class="col-6 col-sm-3">
      <div class="card text-center h-100">
        <div class="card-body d-flex flex-column justify-content-center">
          <i class="bi bi-wallet2 text-success mb-2" style="font-size: 2rem;" aria-hidden="true"></i>
          <div class="kpi-title">Total Savings</div>
          <div id="kpi-savings" class="kpi-val"><?php echo number_format($savings,2); ?></div>
          <small class="text-muted">₹ Balance</small>
        </div>
      </div>
    </div>
    <div class="col-6 col-sm-3">
      <div class="card text-center h-100">
        <div class="card-body d-flex flex-column justify-content-center">
          <i class="bi bi-cash-stack text-warning mb-2" style="font-size: 2rem;" aria-hidden="true"></i>
          <div class="kpi-title">Loan Principal</div>
          <div id="kpi-loan" class="kpi-val"><?php echo number_format($loanPrincipal,2); ?></div>
          <small class="text-muted">₹ Outstanding</small>
        </div>
      </div>
    </div>
    <div class="col-6 col-sm-3">
      <div class="card text-center h-100">
        <div class="card-body d-flex flex-column justify-content-center">
          <i class="bi bi-check-circle-fill text-success mb-2" style="font-size: 2rem;" aria-hidden="true"></i>
          <div class="kpi-title">Repayments</div>
          <div id="kpi-repay" class="kpi-val"><?php echo number_format($repayments,2); ?></div>
          <small class="text-muted">₹ Paid</small>
        </div>
      </div>
    </div>
  </div>
  <div class="card mt-4">
    <div class="card-header d-flex justify-content-between align-items-center">
      <span>Savings vs Outstanding (Sample Member)</span>
      <div class="d-flex align-items-center">
        <form method="get" class="d-inline me-2">
          <select id="member-select" name="member" class="form-select form-select-sm" onchange="this.form.submit()" aria-label="Select Member">
            <?php
            $db = DB::conn();
            $res = $db->query("SELECT member_id, name FROM members ORDER BY name");
            while ($r = $res->fetchArray(SQLITE3_ASSOC)) {
              $selected = ($r['member_id'] == ($_GET['member'] ?? '')) ? 'selected' : '';
              echo '<option value="'.$r['member_id'].'" '.$selected.'>'.htmlspecialchars($r['name']).'</option>';
            }
            ?>
          </select>
        </form>
        <i class="bi bi-graph-up-arrow" style="font-size: 1.2rem; color: var(--primary-blue);" aria-hidden="true"></i>
      </div>
    </div>
    <div class="card-body p-0">
      <canvas id="lineChart" height="200" aria-label="Savings vs Outstanding Chart"></canvas>
      <div id="empty-state" class="text-center p-4 text-muted d-none">Select a member to view the chart.</div>
    </div>
  </div>
</main>
<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
  const ctx = document.getElementById('lineChart').getContext('2d');
  let chart = null;
  const memberSelect = document.getElementById('member-select');
  const emptyState = document.getElementById('empty-state');

  function loadChart(memberId) {
    if (!memberId) {
      emptyState.classList.remove('d-none');
      if (chart) chart.destroy();
      return;
    }

    // Simulate AJAX (replace with real fetch to api/get_member_data.php)
    // For demo, use static data; in production, fetch real data
    const data = {
      labels: ['Jan', 'Feb', 'Mar', 'Apr'],
      savings: [1000, 1500, 2000, 1800],
      outstanding: [2000, 1500, 1000, 1200]
    };

    emptyState.classList.add('d-none');
    if (chart) chart.destroy();
    chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: data.labels,
        datasets: [{
          label: 'Savings',
          data: data.savings,
          borderColor: '#10B981',
          backgroundColor: 'rgba(16, 185, 129, 0.1)',
          tension: 0.4,
          fill: true
        }, {
          label: 'Outstanding',
          data: data.outstanding,
          borderColor: '#F59E0B',
          backgroundColor: 'rgba(245, 158, 11, 0.1)',
          tension: 0.4,
          fill: true
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { tooltip: { enabled: true, mode: 'index' } },
        scales: { 
          y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.1)' } },
          x: { grid: { display: false } }
        },
        interaction: { intersect: false }
      }
    });
  }

  memberSelect.addEventListener('change', (e) => loadChart(e.target.value));
  loadChart(memberSelect.value); // Initial load
});
</script>
</body>
</html>