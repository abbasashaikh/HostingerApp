<?php
// This file handles all transaction-related logic: issuing goods, settling accounts, and generating reports.

// Include the global initialization file. This handles sessions, headers, DB connection, and helper functions.
require_once 'config.php';
// Include the notification service to send WhatsApp/SMS messages.
require_once 'whatsapp_service.php';

// All actions in this file require a logged-in user.
if (!isset($_SESSION['user_id'])) {
    send_json(['success' => false, 'message' => 'Unauthorized. Please log in.'], 403);
}

// --- MAIN ROUTER ---
// Determines which function to call based on the 'action' parameter in the request.
$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? '';

try {
    if ($method === 'GET') {
        handleGetRequest($conn, $action);
    } elseif ($method === 'POST') {
        // POST data can be tricky. This handles both JSON and standard form data.
        $input_data = [];
        if (strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
            $input_data = json_decode(file_get_contents('php://input'), true);
        } else {
            // This handles standard form data from our issue.js FormData
            $input_data = $_POST;
        }
        
        $post_action = $input_data['action'] ?? $action; // Get action from either payload or query string
        handlePostRequest($conn, $post_action, $input_data);
    } else {
        send_json(['success' => false, 'message' => 'Method Not Allowed'], 405);
    }
} catch (Exception $e) {
    // A global catch block for any unexpected errors within the functions.
    send_json(['success' => false, 'message' => 'A server error occurred: ' . $e->getMessage()], 500);
}


// --- ROUTER FUNCTIONS ---
function handleGetRequest($conn, $action) {
    $customerId = $_GET['customerId'] ?? null;
    $date = $_GET['date'] ?? null;
    $startDate = $_GET['startDate'] ?? null;
    $endDate = $_GET['endDate'] ?? null;
    $userId = $_SESSION['user_id'];
    $userRole = $_SESSION['role'];

    switch($action) {
        case 'get_open_issues':
            if ($customerId) getOpenIssuesForSettlement($conn, $customerId);
            else send_json(['success' => false, 'message' => 'Customer ID is required.'], 400);
            break;
        case 'get_ledger':
            if ($customerId) getCustomerLedger($conn, $customerId, $startDate, $endDate, $userId, $userRole);
            else send_json(['success' => false, 'message' => 'Customer ID is required.'], 400);
            break;
        case 'get_recent':
            getRecentTransactions($conn, $userId, $userRole);
            break;
        default:
            send_json(['success' => false, 'message' => 'Invalid GET action.'], 400);
            break;
    }
}

function handlePostRequest($conn, $action, $data) {
    switch($action) {
        case 'distribute':
            distributeToCustomer($conn, $data);
            break;
        case 'settle':
            settleTransaction($conn, $data);
            break;
        case 'delete_transaction':
            deleteTransaction($conn, $data);
            break;
        default:
            send_json(['success' => false, 'message' => 'Invalid POST action.'], 400);
            break;
    }
}

// --- LOGIC FUNCTIONS ---

function distributeToCustomer($conn, $data) {
    $conn->begin_transaction();
    try {
        $customerId = $data['customerId'];
        $items = json_decode($data['items'] ?? '[]', true); 
        $amountPaid = floatval($data['amountPaid'] ?? 0);
        $date = $data['transactionDate'];
        $created_by_user_id = $_SESSION['user_id'];

        if (!$customerId || empty($date) || empty($items)) {
            throw new Exception("Customer, date, and items are required.");
        }

        $totalAmount = array_reduce($items, fn($sum, $item) => $sum + (floatval($item['quantity']) * floatval($item['rate'])), 0);
        
        $stmt = $conn->prepare("INSERT INTO transactions (customer_id, date, type, total_amount, notes, created_by_user_id) VALUES (?, ?, 'issue', ?, ?, ?)");
        $stmt->bind_param("isdsi", $customerId, $date, $totalAmount, $data['notes'], $created_by_user_id);
        if(!$stmt->execute()) throw new Exception("Failed to create transaction record.");
        $transactionId = $conn->insert_id;
        
        $itemStmt = $conn->prepare("INSERT INTO transaction_items (transaction_id, fruit_id, quantity, rate, grade) VALUES (?, ?, ?, ?, ?)");
        foreach ($items as $item) {
            $itemStmt->bind_param("iidds", $transactionId, $item['fruitId'], $item['quantity'], $item['rate'], $item['grade']);
            if(!$itemStmt->execute()) throw new Exception("Failed to insert transaction item.");
        }
        
        if ($amountPaid > 0) {
            $paymentStmt = $conn->prepare("INSERT INTO payments (customer_id, transaction_id, amount, payment_date, payment_type) VALUES (?, ?, ?, ?, 'upfront')");
            $paymentStmt->bind_param("iids", $customerId, $transactionId, $amountPaid, $date);
            if(!$paymentStmt->execute()) throw new Exception("Failed to record upfront payment.");
        }
        
        $netChange = $totalAmount - $amountPaid;
        $updateStmt = $conn->prepare("UPDATE customers SET total_dues = total_dues + ? WHERE id = ?");
        $updateStmt->bind_param("di", $netChange, $customerId);
        $updateStmt->execute();
        
        $conn->commit();
        send_json(['success' => true, 'message' => 'Issue recorded successfully.']);
    } catch (Exception $e) {
        $conn->rollback();
        send_json(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

function settleTransaction($conn, $data) {
    $conn->begin_transaction();
    try {
        $customerId = intval($data['customerId']);
        $date = $data['date'];
        $cashCollected = floatval($data['cashCollected']);
        $returnedItems = $data['returnedItems'];
        $transactionIds = $data['transactionIds'];

        if (empty($transactionIds) || !$customerId) {
            throw new Exception("Transaction IDs and Customer ID are required for settlement.");
        }
        
        $returnedValue = array_reduce($returnedItems, fn($sum, $item) => $sum + (floatval($item['return_qty']) * floatval($item['rate'])), 0);
        
        $updateItemStmt = $conn->prepare("UPDATE transaction_items SET return_qty = ?, spoil_qty = ? WHERE id = ?");
        foreach($returnedItems as $item) {
            $updateItemStmt->bind_param("ddi", $item['return_qty'], $item['spoil_qty'], $item['id']);
            if(!$updateItemStmt->execute()) throw new Exception("Failed to update return item #" . $item['id']);
        }
        
        $totalCredit = $returnedValue + $cashCollected;
        
        if ($totalCredit > 0) {
            $updateDuesStmt = $conn->prepare("UPDATE customers SET total_dues = total_dues - ? WHERE id = ?");
            $updateDuesStmt->bind_param("di", $totalCredit, $customerId);
            if(!$updateDuesStmt->execute()) throw new Exception("Failed to update customer balance.");
        }
        
        $placeholders = implode(',', array_fill(0, count($transactionIds), '?'));
        $types = str_repeat('i', count($transactionIds));
        $updateTxStmt = $conn->prepare("UPDATE transactions SET type = 'settled' WHERE id IN ($placeholders) AND type = 'issue'");
        $updateTxStmt->bind_param($types, ...$transactionIds);
        $updateTxStmt->execute();

        if ($returnedValue > 0) {
            $returnTxStmt = $conn->prepare("INSERT INTO transactions (customer_id, date, type, total_amount, notes, created_by_user_id) VALUES (?, ?, 'return', ?, ?, ?)");
            $negativeReturnValue = -1 * $returnedValue;
            $returnNotes = "Return against Bill(s) #" . implode(', ', $transactionIds);
            $returnTxStmt->bind_param("isdsi", $customerId, $date, $negativeReturnValue, $returnNotes, $_SESSION['user_id']);
            $returnTxStmt->execute();
        }
        if ($cashCollected > 0) {
            $paymentStmt = $conn->prepare("INSERT INTO payments (customer_id, amount, payment_date, payment_type, notes) VALUES (?, ?, ?, 'settlement', ?)");
            $paymentStmt->bind_param("idss", $customerId, $cashCollected, $date, $data['notes']);
            $paymentStmt->execute();
        }

        $conn->commit();
        send_json(['success' => true, 'message' => 'Settlement successful.']);
    } catch (Exception $e) {
        $conn->rollback();
        send_json(['success' => false, 'message' => 'Settlement failed: ' . $e->getMessage()], 500);
    }
}

function getOpenIssuesForSettlement($conn, $customerId) {
    // Step 1: Find all transactions for the customer that are of type 'issue' (i.e., not yet settled).
    $stmt = $conn->prepare("SELECT id, total_amount FROM transactions WHERE customer_id = ? AND type = 'issue' ORDER BY date ASC");
    $stmt->bind_param("i", $customerId);
    $stmt->execute();
    $transactions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    if (empty($transactions)) {
        send_json(['success' => false, 'message' => 'No open (unsettled) bills found for this customer.'], 404);
    }
    
    // Step 2: Collect the IDs and sum the total bill amount from these transactions.
    $transactionIds = array_column($transactions, 'id');
    $totalIssueAmount = array_sum(array_column($transactions, 'total_amount'));
    
    // Step 3: THE CORE FIX - Query the `payments` table to get the sum of all upfront payments
    // that are linked to these specific issue transactions.
    $totalPaidAmount = 0;
    if (!empty($transactionIds)) {
        $placeholders = implode(',', array_fill(0, count($transactionIds), '?'));
        $types = str_repeat('i', count($transactionIds));
        
        $paymentStmt = $conn->prepare("SELECT SUM(amount) as total_paid FROM payments WHERE transaction_id IN ($placeholders) AND payment_type = 'upfront'");
        $paymentStmt->bind_param($types, ...$transactionIds);
        $paymentStmt->execute();
        $paymentResult = $paymentStmt->get_result()->fetch_assoc();
        $totalPaidAmount = floatval($paymentResult['total_paid'] ?? 0);
    }

    // Step 4: Fetch all the individual items from these transactions to display on the form.
    $placeholders = implode(',', array_fill(0, count($transactionIds), '?'));
    $types = str_repeat('i', count($transactionIds));
    $itemStmt = $conn->prepare("
        SELECT ti.id, ti.quantity, ti.rate, f.name, f.unit, ti.transaction_id 
        FROM transaction_items ti 
        JOIN fruits f ON ti.fruit_id = f.id 
        WHERE ti.transaction_id IN ($placeholders)
    ");
    $itemStmt->bind_param($types, ...$transactionIds);
    $itemStmt->execute();
    $items = $itemStmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Step 5: Send the complete and correct data back to the frontend.
    send_json(['success' => true, 'data' => [
        'totalIssueAmount' => $totalIssueAmount, 
        'totalPaidAmount' => $totalPaidAmount, 
        'transactionIds' => $transactionIds, 
        'items' => $items
    ]]);
}

function getRecentTransactions($conn, $userId, $userRole) {
    $query = "SELECT t.date, t.type, t.total_amount, (SELECT SUM(p.amount) FROM payments p WHERE p.transaction_id = t.id) as amount_paid, c.name as customer_name FROM transactions t JOIN customers c ON t.customer_id = c.id";
    $params = [];
    $types = "";
    if ($userRole !== 'admin') {
        $query .= " WHERE t.created_by_user_id = ?";
        $params[] = $userId;
        $types .= "i";
    }
    $query .= " ORDER BY t.id DESC LIMIT 10";
    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $transactions = $result->fetch_all(MYSQLI_ASSOC);
    send_json(['success' => true, 'data' => $transactions]);
}

function getCustomerLedger($conn, $customerId, $startDate, $endDate, $userId, $userRole) {
    $customer_stmt = $conn->prepare("SELECT name FROM customers WHERE id = ?");
    $customer_stmt->bind_param("i", $customerId);
    $customer_stmt->execute();
    $customer = $customer_stmt->get_result()->fetch_assoc();
    if (!$customer) send_json(['success' => false, 'message' => 'Customer not found.'], 404);

    $sql = "
        (SELECT t.id as transaction_id, t.date, t.total_amount as debit, 0 as credit, 'Goods Issued' as description FROM transactions t WHERE t.customer_id = ? AND t.type = 'issue')
        UNION ALL
        (SELECT p.transaction_id, p.payment_date as date, 0 as debit, p.amount as credit, CONCAT('Payment (', p.payment_type, ')') as description FROM payments p WHERE p.customer_id = ?)
        UNION ALL
        (SELECT t.id as transaction_id, t.date, 0 as debit, ABS(t.total_amount) as credit, 'Goods Returned' as description FROM transactions t WHERE t.customer_id = ? AND t.type = 'return')
    ";
    
    $final_sql = "SELECT * FROM ($sql) as ledger ORDER BY date, transaction_id";
    
    $stmt = $conn->prepare($final_sql);
    $stmt->bind_param("iii", $customerId, $customerId, $customerId);
    $stmt->execute();
    $result = $stmt->get_result();
    $ledgerEntries = $result->fetch_all(MYSQLI_ASSOC);

    send_json(['success' => true, 'customerName' => $customer['name'], 'data' => $ledgerEntries]);
}

function deleteTransaction($conn, $data) {
    $transactionId = intval($data['transactionId'] ?? 0);
    if ($transactionId <= 0) send_json(['success' => false, 'message' => 'Invalid Transaction ID.'], 400);

    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("SELECT * FROM transactions WHERE id = ?");
        $stmt->bind_param("i", $transactionId);
        $stmt->execute();
        $tx = $stmt->get_result()->fetch_assoc();
        if (!$tx) throw new Exception("Transaction not found.");

        $customerId = $tx['customer_id'];
        $netImpact = floatval($tx['total_amount']);

        $paymentStmt = $conn->prepare("SELECT SUM(amount) as total_paid FROM payments WHERE transaction_id = ?");
        $paymentStmt->bind_param("i", $transactionId);
        $paymentStmt->execute();
        $paymentResult = $paymentStmt->get_result()->fetch_assoc();
        if ($paymentResult && $paymentResult['total_paid'] > 0) {
            $netImpact -= floatval($paymentResult['total_paid']);
        }
        
        $updateCustomerStmt = $conn->prepare("UPDATE customers SET total_dues = total_dues - ? WHERE id = ?");
        $updateCustomerStmt->bind_param("di", $netImpact, $customerId);
        if (!$updateCustomerStmt->execute()) throw new Exception("Failed to reverse customer balance.");

        $conn->query("DELETE FROM payments WHERE transaction_id = $transactionId");
        $conn->query("DELETE FROM transaction_items WHERE transaction_id = $transactionId");
        $conn->query("DELETE FROM transactions WHERE id = $transactionId");

        $conn->commit();
        send_json(['success' => true, 'message' => 'Transaction #' . $transactionId . ' deleted successfully.']);

    } catch (Exception $e) {
        $conn->rollback();
        send_json(['success' => false, 'message' => 'Failed to delete transaction: ' . $e->getMessage()], 500);
    }
}

$conn->close();
?>