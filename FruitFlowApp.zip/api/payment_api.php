<?php
require_once 'config.php';
require_once 'whatsapp_service.php';

if (!isset($_SESSION['user_id'])) {
    send_json(['success' => false, 'message' => 'Unauthorized'], 403);
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $input_data = json_decode(file_get_contents('php://input'), true);
    handlePaymentCreation($conn, $input_data);
} else {
    send_json(['success' => false, 'message' => 'Method Not Allowed'], 405);
}

function handlePaymentCreation($conn, $data) {
    $customerId = intval($data['customerId'] ?? 0);
    $amount = floatval($data['amount'] ?? 0);
    $date = $data['payment_date'] ?? date('Y-m-d');
    $notes = $data['notes'] ?? '';

    if ($customerId <= 0 || $amount <= 0) {
        send_json(['success' => false, 'message' => 'Valid customer and positive amount are required.'], 400);
    }

    $conn->begin_transaction();
    try {
        // Step 1: Record the payment in the payments table
        $stmt = $conn->prepare("INSERT INTO payments (customer_id, amount, payment_date, payment_type, notes) VALUES (?, ?, ?, 'due_payment', ?)");
        $stmt->bind_param("idss", $customerId, $amount, $date, $notes);
        if (!$stmt->execute()) {
            throw new Exception("Failed to record payment: " . $stmt->error);
        }
        
        // Step 2: Decrease the customer's total dues
        $updateStmt = $conn->prepare("UPDATE customers SET total_dues = total_dues - ? WHERE id = ?");
        $updateStmt->bind_param("di", $amount, $customerId);
        if (!$updateStmt->execute()) {
            throw new Exception("Failed to update customer dues: " . $updateStmt->error);
        }

        $conn->commit();
        // Here you could add a WhatsApp notification for the payment
        send_json(['success' => true, 'message' => 'Payment recorded successfully.']);

    } catch (Exception $e) {
        $conn->rollback();
        send_json(['success' => false, 'message' => 'Failed to record payment: ' . $e->getMessage()], 500);
    }
}
?>