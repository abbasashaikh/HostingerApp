<?php
// This is the API for all User Management actions.
require_once 'config.php'; // This provides the $conn variable and send_json function.

// All actions in this file require the user to be a logged-in admin.
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    send_json(['success' => false, 'message' => 'Unauthorized: Admin access required.'], 403);
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? '';
$input_data = json_decode(file_get_contents('php://input'), true);

// --- API ROUTER ---
try {
    if ($method === 'GET' && $action === 'get_all') {
        
        // Prepare the SQL query. Using backticks ` is best practice for MySQL.
        $stmt = $conn->prepare("SELECT `id`, `name`, `username`, `phone`, `role`, `status` FROM `users` ORDER BY `name` ASC");
        
        if ($stmt === false) {
            throw new Exception("SQL prepare failed: " . $conn->error);
        }

        $stmt->execute();
        $result = $stmt->get_result();
        $users = $result->fetch_all(MYSQLI_ASSOC);
        
        send_json(['success' => true, 'data' => $users]);

    } elseif ($method === 'POST') {
        $post_action = $input_data['action'] ?? '';
        
        if ($post_action === 'create') {
            $name = $input_data['name'] ?? '';
            $username = $input_data['username'] ?? '';
            $phone = $input_data['phone'] ?? null;
            $password = $input_data['password'] ?? '';
            $role = $input_data['role'] ?? 'user';
            $status = $input_data['status'] ?? 'active';

            if (empty($username) || empty($password) || empty($name)) {
                send_json(['success' => false, 'message' => 'Full Name, Username, and Password are required.'], 400);
            }
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("INSERT INTO `users` (`name`, `username`, `phone`, `password`, `role`, `status`) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssss", $name, $username, $phone, $hashed_password, $role, $status);
            
            if ($stmt->execute()) {
                send_json(['success' => true, 'message' => 'User created successfully.']);
            } else {
                send_json(['success' => false, 'message' => 'Failed to create user. Username may already exist.'], 500);
            }

        } elseif ($post_action === 'update') {
            $id = $input_data['id'] ?? 0;
            $name = $input_data['name'] ?? '';
            $username = $input_data['username'] ?? '';
            $phone = $input_data['phone'] ?? null;
            $password = $input_data['password'] ?? '';
            $role = $input_data['role'] ?? 'user';
            $status = $input_data['status'] ?? 'active';

            if (empty($id) || empty($name) || empty($username)) {
                 send_json(['success' => false, 'message' => 'User ID, Name, and Username are required.'], 400);
            }

            if (!empty($password)) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE `users` SET `name`=?, `username`=?, `phone`=?, `password`=?, `role`=?, `status`=? WHERE `id`=?");
                $stmt->bind_param("ssssssi", $name, $username, $phone, $hashed_password, $role, $status, $id);
            } else {
                $stmt = $conn->prepare("UPDATE `users` SET `name`=?, `username`=?, `phone`=?, `role`=?, `status`=? WHERE `id`=?");
                $stmt->bind_param("sssssi", $name, $username, $phone, $role, $status, $id);
            }

            if ($stmt->execute()) {
                send_json(['success' => true, 'message' => 'User updated successfully.']);
            } else {
                send_json(['success' => false, 'message' => 'Failed to update user. Username may already exist.'], 500);
            }
        } else {
            send_json(['success' => false, 'message' => 'Invalid POST action for users.'], 400);
        }
    } else {
        send_json(['success' => false, 'message' => 'Invalid request method or action.'], 400);
    }
} catch (Exception $e) {
    send_json(['success' => false, 'message' => 'Server Error: ' . $e->getMessage()], 500);
}
?>