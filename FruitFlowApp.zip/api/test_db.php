<?php
// This is a diagnostic script. Access it at: /api/test_db.php
// DELETE this file after you are done.

header('Content-Type: text/plain');

echo "--- DATABASE CONNECTION & SCHEMA TEST ---\n\n";

// --- 1. Load your configuration ---
require_once 'config.php';
echo "Step 1: config.php loaded.\n";
echo "   - DB_NAME defined as: " . DB_NAME . "\n";
echo "   - DB_USER defined as: " . DB_USER . "\n\n";

// --- 2. Test the connection ($conn comes from config.php) ---
if ($conn && !$conn->connect_error) {
    echo "Step 2: [SUCCESS] Successfully connected to the MySQL server.\n";
    echo "   - Server Version: " . $conn->server_info . "\n";
    echo "   - Connected as: " . $conn->host_info . "\n\n";
} else {
    echo "Step 2: [FATAL ERROR] FAILED to connect to the MySQL server.\n";
    echo "   - Error: " . ($conn->connect_error ?? 'Unknown connection error.');
    exit();
}

// --- 3. Explicitly select the database ---
if ($conn->select_db(DB_NAME)) {
    echo "Step 3: [SUCCESS] Successfully selected the database '" . DB_NAME . "'.\n\n";
} else {
    echo "Step 3: [FATAL ERROR] FAILED to select the database '" . DB_NAME . "'.\n";
    echo "   - Error: " . $conn->error;
    exit();
}

// --- 4. Describe the `users` table ---
echo "Step 4: Checking the structure of the `users` table...\n";
$result = $conn->query("DESCRIBE `users`");

if ($result) {
    echo "   [SUCCESS] `users` table exists. Here are its columns:\n";
    echo "   ---------------------------------------------------\n";
    echo "   Field\t\tType\n";
    echo "   ---------------------------------------------------\n";
    while ($row = $result->fetch_assoc()) {
        echo "   " . $row['Field'] . "\t\t" . $row['Type'] . "\n";
    }
    echo "   ---------------------------------------------------\n\n";
} else {
    echo "   [FATAL ERROR] FAILED to describe the `users` table.\n";
    echo "   - Error: " . $conn->error . "\n";
    exit();
}

echo "--- DIAGNOSTIC COMPLETE ---";

$conn->close();
?>