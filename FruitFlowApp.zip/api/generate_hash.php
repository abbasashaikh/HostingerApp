<?php
// This script is for ONE-TIME use to generate a secure password hash.
// 1. Change the value of $myPassword below to what you want your password to be.
// 2. Upload this file to your /api/ folder.
// 3. Access it from your browser: https://fruitflowleger.abstechsolution.co.in/api/generate_hash.php
// 4. Copy the ENTIRE output string.
// 5. DELETE this file from your server for security.

header('Content-Type: text/plain');

// --- SET YOUR DESIRED PASSWORD HERE ---
$myPassword = 'admin123'; 

// --- DO NOT EDIT BELOW THIS LINE ---

echo "--- Password Hash Generator ---\n\n";
echo "Password to hash: " . htmlspecialchars($myPassword) . "\n\n";

// Generate the hash using PHP's standard, secure bcrypt algorithm.
$hashedPassword = password_hash($myPassword, PASSWORD_DEFAULT);

echo "Generated Hash (copy this entire line):\n";
echo "-------------------------------------------\n";
echo $hashedPassword;
echo "\n-------------------------------------------\n\n";
echo "Instructions:\n";
echo "1. Copy the long hash string above.\n";
echo "2. Go to Hostinger -> phpMyAdmin and open your 'users' table.\n";
echo "3. Edit the row for the 'admin' user.\n";
echo "4. Paste this hash into the 'password' column and save.\n";
echo "5. DELETE this generate_hash.php file from your server.";

?>