<?php
require_once 'config.php';

// All actions in this file require a logged-in user.
if (!isset($_SESSION['user_id'])) {
    send_json(['success' => false, 'message' => 'Unauthorized. Please log in.'], 403);
}

$action = $_GET['action'] ?? '';

try {
    switch($action) {
        case 'get_dashboard_stats':
            getDashboardStats($conn);
            break;
        case 'get_dues_report':
            getDuesReport($conn);
            break;
        case 'get_inventory_report':
            getInventoryReport($conn);
            break;
        case 'recalculate_dues':
            // This is a POST action but is kept in reports for logical grouping.
            // Ensure the request method is POST for this specific action.
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                recalculateAllDues($conn);
            } else {
                send_json(['success' => false, 'message' => 'Invalid request method for recalculate action.'], 405);
            }
            break;
        default:
            send_json(['success' => false, 'message' => 'Invalid report action specified.'], 400);
            break;
    }
} catch (Exception $e) {
    send_json(['success' => false, 'message' => 'Report generation failed: ' . $e->getMessage()], 500);
}

/**
 * Fetches the four key performance indicators (KPIs) for the dashboard.
 */
function getDashboardStats($conn) {
    $today = date('Y-m-d');

    // 1. Total Outstanding Dues & Count of Customers with Dues
    $duesResult = $conn->query("SELECT SUM(total_dues) as total_outstanding, COUNT(id) as customers_with_dues FROM customers WHERE total_dues > 0.01");
    if (!$duesResult) throw new Exception("Failed to query dues stats: " . $conn->error);
    $duesData = $duesResult->fetch_assoc();

    // 2. Today's Net Sales = (Value of Issues) - (Value of Returns)
    $salesResult = $conn->query("
        SELECT 
            (SELECT COALESCE(SUM(total_amount), 0) FROM transactions WHERE date = '{$today}' AND type = 'issue') 
            - 
            (SELECT COALESCE(SUM(ABS(total_amount)), 0) FROM transactions WHERE date = '{$today}' AND type = 'return') 
        AS net_sales
    ");
    if (!$salesResult) throw new Exception("Failed to query sales stats: " . $conn->error);
    $salesData = $salesResult->fetch_assoc();

    // 3. Low Stock Items - Counts fruits where remaining stock is at or below the threshold
    $lowStockQuery = "
        SELECT 
            COUNT(f.id) as low_stock_count
        FROM 
            fruits f
        WHERE 
            (
                (SELECT COALESCE(SUM(quantity), 0) FROM stock_purchases WHERE fruit_id = f.id)
                - 
                (SELECT COALESCE(SUM(quantity - return_qty), 0) FROM transaction_items WHERE fruit_id = f.id)
            ) <= f.low_stock_threshold
    ";
    $lowStockResult = $conn->query($lowStockQuery);
    if (!$lowStockResult) throw new Exception("Low stock query failed: " . $conn->error);
    $lowStockData = $lowStockResult->fetch_assoc();

    $stats = [
        'total_outstanding' => floatval($duesData['total_outstanding'] ?? 0),
        'customers_with_dues' => intval($duesData['customers_with_dues'] ?? 0),
        'todays_sales' => floatval($salesData['net_sales'] ?? 0),
        'low_stock_items' => intval($lowStockData['low_stock_count'] ?? 0)
    ];

    send_json(['success' => true, 'data' => $stats]);
}

/**
 * Fetches a list of all customers with a non-zero outstanding balance.
 */
function getDuesReport($conn) {
    $result = $conn->query("SELECT id, name, type, phone, total_dues FROM customers WHERE total_dues > 0.01 ORDER BY total_dues DESC");
    if (!$result) {
        throw new Exception("Database query failed: " . $conn->error);
    }
    $customers = $result->fetch_all(MYSQLI_ASSOC);
    send_json(['success' => true, 'data' => $customers]);
}

/**
 * Fetches a summary of fruit inventory.
 */
function getInventoryReport($conn) {
    $query = "
        SELECT 
            f.name, 
            f.unit,
            f.low_stock_threshold,
            (SELECT COALESCE(SUM(quantity), 0) FROM stock_purchases WHERE fruit_id = f.id) as total_purchased,
            (SELECT COALESCE(SUM(quantity - return_qty), 0) FROM transaction_items WHERE fruit_id = f.id) as total_sold
        FROM fruits f
        ORDER BY f.name ASC
    ";
    $result = $conn->query($query);
    if (!$result) {
        throw new Exception("Database query failed: " . $conn->error);
    }
    
    $inventory = [];
    while($row = $result->fetch_assoc()) {
        $row['remaining_stock'] = floatval($row['total_purchased']) - floatval($row['total_sold']);
        $inventory[] = $row;
    }
    send_json(['success' => true, 'data' => $inventory]);
}

/**
 * A powerful admin tool to fix data inconsistencies by recalculating all dues from scratch.
 */
function recalculateAllDues($conn) {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        send_json(['success' => false, 'message' => 'Unauthorized. Admin access required.'], 403);
    }

    $conn->begin_transaction();
    try {
        // Step 1: Reset all customer dues to zero
        $conn->query("UPDATE customers SET total_dues = 0");

        // Step 2: Calculate total debits (issues) for each customer
        $debitResult = $conn->query("SELECT customer_id, SUM(total_amount) as total_debit FROM transactions WHERE type = 'issue' GROUP BY customer_id");
        $balances = [];
        while($row = $debitResult->fetch_assoc()) {
            $balances[$row['customer_id']] = floatval($row['total_debit']);
        }

        // Step 3: Calculate total credits (payments and returns) for each customer
        $creditPaymentsResult = $conn->query("SELECT customer_id, SUM(amount) as total_credit FROM payments GROUP BY customer_id");
        while($row = $creditPaymentsResult->fetch_assoc()) {
            if (!isset($balances[$row['customer_id']])) $balances[$row['customer_id']] = 0;
            $balances[$row['customer_id']] -= floatval($row['total_credit']);
        }
        
        $creditReturnsResult = $conn->query("SELECT customer_id, SUM(ABS(total_amount)) as total_credit FROM transactions WHERE type = 'return' GROUP BY customer_id");
         while($row = $creditReturnsResult->fetch_assoc()) {
            if (!isset($balances[$row['customer_id']])) $balances[$row['customer_id']] = 0;
            $balances[$row['customer_id']] -= floatval($row['total_credit']);
        }

        // Step 4: Update each customer with their newly calculated balance
        foreach($balances as $customerId => $balance) {
            $stmt = $conn->prepare("UPDATE customers SET total_dues = ? WHERE id = ?");
            $rounded_balance = round($balance, 2);
            $stmt->bind_param("di", $rounded_balance, $customerId);
            $stmt->execute();
        }

        $conn->commit();
        send_json(['success' => true, 'message' => 'All customer dues have been recalculated successfully.']);

    } catch (Exception $e) {
        $conn->rollback();
        send_json(['success' => false, 'message' => 'Failed to recalculate dues: ' . $e->getMessage()], 500);
    }
}

$conn->close();
?>