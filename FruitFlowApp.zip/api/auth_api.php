<?php
require_once 'config.php'; // This handles the DB connection and all setup.

$input_data = json_decode(file_get_contents('php://input'), true);
$action = $input_data['action'] ?? '';

if ($action === 'login') {
    $username = $input_data['username'] ?? '';
    $password = $input_data['password'] ?? '';

    if (empty($username) || empty($password)) {
        send_json(['success' => false, 'message' => 'Username and password are required.'], 400);
    }

    try {
        $stmt = $conn->prepare("SELECT * FROM `users` WHERE `username` = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['username'] = $user['username'];
                
                send_json([
                    'success' => true,
                    'data' => [
                        'id' => $user['id'],
                        'username' => $user['username'],
                        'role' => $user['role']
                    ]
                ]);
            }
        }
        // If user not found or password does not match, send a generic error
        send_json(['success' => false, 'message' => 'Invalid credentials.'], 401);

    } catch (Exception $e) {
        send_json(['success' => false, 'message' => 'An error occurred during login.'], 500);
    }

} else {
    send_json(['success' => false, 'message' => 'Invalid action.'], 400);
}
?>