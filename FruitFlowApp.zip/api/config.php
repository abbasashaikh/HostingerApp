<?php
// This is the global initialization file for the API.

// HIGHLIGHT: Start the session at the absolute beginning of the script execution.
// This is the most important fix for the 500 error on the users page.
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// --- DATABASE CONFIGURATION ---
define('DB_HOST', 'localhost');
define('DB_USER', 'u107561845_fruitadmin'); // Use your correct user from hPanel
define('DB_PASS', 'Tas@2010');   // Use your correct password
define('DB_NAME', 'u107561845_fruit_ledger'); // Use your correct DB name

// --- OTHER SETTINGS ---
define('SESSION_SECRET_KEY', 'a_very_strong_and_unique_secret_key_for_fruit_leger_v3_final_!@#$');

// --- ERROR HANDLING & HELPERS ---
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error_log.txt');
error_reporting(E_ALL);

// Establish database connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check for connection errors
if ($conn->connect_error) {
    http_response_code(500);
    // This is sent if the credentials are wrong
    echo json_encode(['success' => false, 'message' => 'Database Connection Failed: ' . $conn->connect_error]);
    exit();
}

// Set global header for all API responses to be JSON.
header('Content-Type: application/json');

// Global helper function to send JSON responses and exit the script cleanly.
function send_json($data, $statusCode = 200) {
    http_response_code($statusCode);
    if (!isset($data['success'])) {
        $data['success'] = ($statusCode >= 200 && $statusCode < 300);
    }
    echo json_encode($data);
    exit();
}
// The $conn variable is now available to any script that requires this file.
?>