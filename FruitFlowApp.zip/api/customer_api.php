<?php
require_once 'config.php';

// Protect all actions in this file with a session check
if (!isset($_SESSION['user_id'])) {
    send_json(['message' => 'Unauthorized'], 403);
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? '';

if ($method === 'GET') {
    if ($action === 'get_all') {
        $stmt = $conn->prepare("SELECT * FROM customers ORDER BY name ASC");
        $stmt->execute();
        $result = $stmt->get_result();
        $customers = $result->fetch_all(MYSQLI_ASSOC);
        send_json(['success' => true, 'data' => $customers]);
    } 
    elseif ($action === 'get_one' && isset($_GET['id'])) {
        $stmt = $conn->prepare("SELECT * FROM customers WHERE id = ?");
        $stmt->bind_param("i", $_GET['id']);
        $stmt->execute();
        $customer = $stmt->get_result()->fetch_assoc();
        if ($customer) {
            send_json(['success' => true, 'data' => $customer]);
        } else {
            send_json(['message' => 'Customer not found.'], 404);
        }
    }
} elseif ($method === 'POST') {
    $input_data = json_decode(file_get_contents('php://input'), true);
    $action = $input_data['action'] ?? '';

    if ($action === 'create') {
        $stmt = $conn->prepare("INSERT INTO customers (name, phone, type, address, status) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $input_data['name'], $input_data['phone'], $input_data['type'], $input_data['address'], $input_data['status']);
        if ($stmt->execute()) {
            send_json(['success' => true, 'message' => 'Customer created.']);
        } else {
            send_json(['message' => 'Failed to create customer. Phone number might already exist.'], 500);
        }
    } 
    elseif ($action === 'update') {
        $stmt = $conn->prepare("UPDATE customers SET name = ?, phone = ?, type = ?, address = ?, status = ? WHERE id = ?");
        $stmt->bind_param("sssssi", $input_data['name'], $input_data['phone'], $input_data['type'], $input_data['address'], $input_data['status'], $input_data['id']);
        if ($stmt->execute()) {
            send_json(['success' => true, 'message' => 'Customer updated.']);
        } else {
            send_json(['message' => 'Failed to update customer.'], 500);
        }
    }
}
?>