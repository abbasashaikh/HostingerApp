<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    send_json(['success' => false, 'message' => 'Unauthorized'], 403);
}

$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET') {
        $action = $_GET['action'] ?? '';
        if ($action === 'get_rates' && isset($_GET['date'])) {
            getRatesByDate($conn, $_GET['date']);
        } else {
            send_json(['success' => false, 'message' => 'Invalid GET action.'], 400);
        }
    } elseif ($method === 'POST') {
        $input_data = json_decode(file_get_contents('php://input'), true);
        $action = $input_data['action'] ?? '';
        if ($action === 'set_rates') {
            setDailyRates($conn, $input_data);
        } else {
            send_json(['success' => false, 'message' => 'Invalid POST action.'], 400);
        }
    }
} catch (Exception $e) {
    send_json(['success' => false, 'message' => 'An error occurred in rate API: ' . $e->getMessage()], 500);
}

function getRatesByDate($conn, $date) {
    $stmt = $conn->prepare("SELECT fruit_id, customer_type, grade, rate FROM daily_rates WHERE date = ?");
    $stmt->bind_param("s", $date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $rates = [];
    while($row = $result->fetch_assoc()) {
        // Create a unique key like "1-Hawker-A" for easy lookup in JavaScript
        $key = $row['fruit_id'] . '-' . $row['customer_type'] . '-' . $row['grade'];
        $rates[$key] = $row['rate'];
    }
    send_json(['success' => true, 'data' => $rates]);
}

function setDailyRates($conn, $data) {
    $date = $data['date'];
    $rates = $data['rates'];

    if (empty($date) || empty($rates) || !is_array($rates)) {
        send_json(['success' => false, 'message' => 'Invalid data provided.'], 400);
    }

    // Use a transaction to ensure all rates are saved or none are.
    $conn->begin_transaction();
    try {
        // Use INSERT...ON DUPLICATE KEY UPDATE for an efficient "upsert" operation
        $stmt = $conn->prepare("
            INSERT INTO daily_rates (fruit_id, customer_type, grade, date, rate) 
            VALUES (?, ?, ?, ?, ?) 
            ON DUPLICATE KEY UPDATE rate = VALUES(rate)
        ");

        foreach ($rates as $key => $rate) {
            // The key contains all necessary info, e.g., "1-Hawker-A"
            list($fruit_id, $customer_type, $grade) = explode('-', $key);
            $stmt->bind_param("isssd", $fruit_id, $customer_type, $grade, $date, $rate);
            if (!$stmt->execute()) {
                // Throw an exception to trigger the rollback
                throw new Exception("Execution failed for key {$key}: " . $stmt->error);
            }
        }
        $conn->commit();
        send_json(['success' => true, 'message' => 'Rates saved successfully.']);
    } catch (Exception $e) {
        $conn->rollback();
        send_json(['success' => false, 'message' => 'Failed to save rates: ' . $e->getMessage()], 500);
    }
}
?>