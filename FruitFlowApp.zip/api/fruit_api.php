<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    send_json(['success' => false, 'message' => 'Unauthorized'], 403);
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? '';
$input_data = json_decode(file_get_contents('php://input'), true);

if ($method === 'GET') {
    if ($action === 'get_all') {
        $stmt = $conn->prepare("SELECT * FROM fruits ORDER BY name ASC");
        $stmt->execute();
        $result = $stmt->get_result();
        $fruits = $result->fetch_all(MYSQLI_ASSOC);
        send_json(['success' => true, 'data' => $fruits]);
    }
    elseif ($action === 'get_purchases') {
        $stmt = $conn->prepare("SELECT sp.*, f.name as fruit_name, f.unit FROM stock_purchases sp JOIN fruits f ON sp.fruit_id = f.id ORDER BY sp.purchase_date DESC, sp.id DESC LIMIT 20");
        $stmt->execute();
        $result = $stmt->get_result();
        $purchases = $result->fetch_all(MYSQLI_ASSOC);
        send_json(['success' => true, 'data' => $purchases]);
    }
} elseif ($method === 'POST') {
    $action = $input_data['action'] ?? '';
    if ($action === 'create' || $action === 'update') {
        $name = $input_data['name'] ?? '';
        $unit = $input_data['unit'] ?? '';
        if (empty($name) || empty($unit)) send_json(['success' => false, 'message' => 'Name and unit are required.'], 400);

        if ($action === 'create') {
            $stmt = $conn->prepare("INSERT INTO fruits (name, unit) VALUES (?, ?)");
            $stmt->bind_param("ss", $name, $unit);
        } else {
            $id = $input_data['id'] ?? 0;
            $stmt = $conn->prepare("UPDATE fruits SET name = ?, unit = ? WHERE id = ?");
            $stmt->bind_param("ssi", $name, $unit, $id);
        }
        if ($stmt->execute()) {
            send_json(['success' => true, 'message' => 'Fruit saved successfully.']);
        } else {
            send_json(['success' => false, 'message' => 'Failed to save fruit. Name might already exist.'], 500);
        }
    } 
    elseif ($action === 'add_stock') {
        $stmt = $conn->prepare("INSERT INTO stock_purchases (fruit_id, quantity, grade, purchase_date, purchase_price, supplier_name) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("idssds", $input_data['fruit_id'], $input_data['quantity'], $input_data['grade'], $input_data['purchase_date'], $input_data['purchase_price'], $input_data['supplier_name']);
        if ($stmt->execute()) {
            send_json(['success' => true, 'message' => 'Stock added successfully.']);
        } else {
            send_json(['success' => false, 'message' => 'Failed to add stock.' . $conn->error], 500);
        }
    }
}
?>