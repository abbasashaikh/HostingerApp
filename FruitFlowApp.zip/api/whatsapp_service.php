<?php
// This service handles formatting and sending all notifications.
// For the MVP, it logs messages to a file. To send real messages,
// you only need to modify the sendWhatsAppMessage function.

require_once 'config.php';

/**
 * The core function to send a message.
 * In a real application, this would contain the API call to Twilio, Gupshup, etc.
 *
 * @param string $phone The customer's phone number.
 * @param string $message The text message to be sent.
 * @return bool True on success, false on failure.
 */
function sendWhatsAppMessage($phone, $message) {
    // Basic phone number cleaning for Indian numbers
    $cleanPhone = preg_replace('/[^0-9]/', '', $phone);
    if (strlen($cleanPhone) === 10) {
        $cleanPhone = '91' . $cleanPhone; // Prepend country code
    }

    $logEntry = "[" . date('Y-m-d H:i:s') . "] TO: {$cleanPhone} | MESSAGE: " . str_replace("\n", " ", $message) . PHP_EOL;

    // Log the message to a file in the same directory.
    // In a real app, you would replace this with your API call.
    file_put_contents(__DIR__ . '/sent_notifications.log', $logEntry, FILE_APPEND | LOCK_EX);
    
    if (defined('WHATSAPP_API_ENABLED') && WHATSAPP_API_ENABLED === true) {
        // EXAMPLE of a real API call (conceptual)
        // $postData = json_encode(['to' => $cleanPhone, 'message' => $message]);
        // $ch = curl_init(WHATSAPP_API_URL);
        // curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Authorization: Bearer ' . WHATSAPP_API_TOKEN]);
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // curl_setopt($ch, CURLOPT_POST, true);
        // curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        // $response = curl_exec($ch);
        // curl_close($ch);
        // return $response; // Return the actual API response
    }
    
    return true; // Simulate success for the MVP
}

/**
 * Creates the message body for a morning issue/sale transaction.
 * @param object $customer The customer object (must have ->name).
 * @param object $transaction The transaction object.
 * @return string The formatted message.
 */
function formatIssueMessage($customer, $transaction) {
    $date = date("d-M-Y", strtotime($transaction->date));
    $due = $transaction->total_amount - $transaction->amount_paid;

    $message  = "Dear {$customer->name},\n\n";
    $message .= "Your transaction summary for {$date}:\n";
    $message .= "-----------------------------------\n";
    $message .= "Total Goods Value: Rs. " . number_format($transaction->total_amount, 2) . "\n";
    $message .= "Cash Paid: Rs. " . number_format($transaction->amount_paid, 2) . "\n";
    $message .= "Today's Due: Rs. " . number_format($due, 2) . "\n";
    $message .= "-----------------------------------\n";
    $message .= "Thank you,\nFruitLegerManagement";
    
    return $message;
}

/**
 * Creates the message body for an evening settlement transaction.
 * @param object $customer The customer object with the *new* total dues.
 * @param object $tx_details An object with settlement details.
 * @return string The formatted message.
 */
function formatSettleMessage($customer, $tx_details) {
    $date = date("d-M-Y", strtotime($tx_details->date));

    $message  = "Dear {$customer->name},\n\n";
    $message .= "Your evening settlement for {$date}:\n";
    $message .= "-----------------------------------\n";
    $message .= "Morning Due: Rs. " . number_format($tx_details->morningDueAmount, 2) . "\n";
    $message .= "Returned Goods Value: Rs. " . number_format($tx_details->eveningReturnedValue, 2) . "\n";
    $message .= "Cash Collected: Rs. " . number_format($tx_details->eveningCollectedAmount, 2) . "\n";
    $message .= "Today's Balance: Rs. " . number_format($tx_details->dailyBalance, 2) . "\n";
    $message .= "-----------------------------------\n";
    $message .= "Your Total Outstanding Due: Rs. " . number_format($customer->total_dues, 2) . "\n\n";
    $message .= "Thank you,\nFruitLegerManagement";

    return $message;
}
?>