document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Element References ---
    const customerSelect = document.getElementById('customerSelect');
    const dateInput = document.getElementById('returnDate');
    const settlementContainer = document.getElementById('settlement-details-container');
    const issueSummaryDiv = document.getElementById('morning-issue-summary');
    const itemsToSettleContainer = document.getElementById('items-to-settle-container');
    const messageContainer = document.getElementById('message-container');
    const returnForm = document.getElementById('returnForm');
    const finalSummaryDiv = document.getElementById('final-summary');
    
    // --- State ---
    let currentSettlementData = null;

    // --- Initial Data Loading ---
    const fetchCustomers = async () => {
        try {
            const response = await fetch('/api/customer_api.php?action=get_all');
            const result = await response.json();
            if (result.success) {
                customerSelect.innerHTML = '<option value="" selected disabled>Select a customer...</option>';
                result.data.forEach(c => {
                    customerSelect.innerHTML += `<option value="${c.id}">${c.name} (${c.type})</option>`;
                });
            } else {
                customerSelect.innerHTML = '<option value="">Failed to load customers</option>';
            }
        } catch (error) {
            console.error('Error fetching customers:', error);
        }
    };

    // --- Core Logic ---
    const fetchOpenIssues = async () => {
        const customerId = customerSelect.value;
        if (!customerId) {
            settlementContainer.classList.add('d-none');
            return;
        }

        try {
            // HIGHLIGHT: Calling the new, more flexible API action
            const response = await fetch(`/api/transaction_api.php?action=get_open_issues&customerId=${customerId}`);
            
            messageContainer.classList.add('d-none'); // Hide any previous messages
            
            if (!response.ok) {
                const errorResult = await response.json().catch(() => null);
                throw new Error(errorResult?.message || `Server responded with status ${response.status}`);
            }

            const result = await response.json();
            
            if (result.success) {
                currentSettlementData = result.data;
                renderSettlementForm();
                settlementContainer.classList.remove('d-none');
            } else {
                // This case is hit when the 404 "No open bills" message is sent
                throw new Error(result.message);
            }
        } catch (error) {
            currentSettlementData = null;
            settlementContainer.classList.add('d-none');
            messageContainer.textContent = error.message;
            messageContainer.className = 'alert alert-warning mt-4';
        }
    };

    const renderSettlementForm = () => {
        issueSummaryDiv.innerHTML = `Total Open Bill Amount: <strong>₹${parseFloat(currentSettlementData.totalIssueAmount).toFixed(2)}</strong> (Already Paid: ₹${parseFloat(currentSettlementData.totalPaidAmount).toFixed(2)})`;
        itemsToSettleContainer.innerHTML = `<table class="table"><thead><tr><th>Item (from Bill)</th><th class="text-center">Issued Qty</th><th style="width: 120px;">Return Qty</th><th style="width: 120px;">Spoiled Qty</th></tr></thead><tbody></tbody></table>`;
        const tbody = itemsToSettleContainer.querySelector('tbody');
        tbody.innerHTML = '';
        currentSettlementData.items.forEach(item => {
            tbody.innerHTML += `
                <tr class="item-settle-row" data-item-id="${item.id}" data-rate="${item.rate}">
                    <td>${item.name} <small class="text-muted">(Bill #${item.transaction_id})</small></td>
                    <td class="text-center">${item.quantity} ${item.unit}</td>
                    <td><input type="number" class="form-control return-qty" value="0" step="0.01" min="0" max="${item.quantity}"></td>
                    <td><input type="number" class="form-control spoil-qty" value="0" step="0.01" min="0"></td>
                </tr>`;
        });
        updateFinalSummary();
    };
    
    const updateFinalSummary = () => {
        if (!currentSettlementData) return;
        let returnedValue = 0;
        document.querySelectorAll('.item-settle-row').forEach(row => {
            const returnQty = parseFloat(row.querySelector('.return-qty').value) || 0;
            const rate = parseFloat(row.dataset.rate);
            returnedValue += returnQty * rate;
        });
        
        const cashCollected = parseFloat(document.getElementById('amountCollected').value) || 0;
        const morningBill = parseFloat(currentSettlementData.totalIssueAmount);
        const morningPaid = parseFloat(currentSettlementData.totalPaidAmount);

        const netAmountDue = (morningBill - morningPaid) - returnedValue;
        const dailyBalance = netAmountDue - cashCollected;

        finalSummaryDiv.innerHTML = `
            <div class="d-flex justify-content-between"><span>Total Open Bills:</span> <span>₹${morningBill.toFixed(2)}</span></div>
            <div class="d-flex justify-content-between"><span>(-) Already Paid:</span> <span>₹${morningPaid.toFixed(2)}</span></div>
            <div class="d-flex justify-content-between"><span>(-) Value of Returns:</span> <span>₹${returnedValue.toFixed(2)}</span></div>
            <hr>
            <div class="d-flex justify-content-between fw-bold"><span>Net Amount Due:</span> <span>₹${netAmountDue.toFixed(2)}</span></div>
            <div class="d-flex justify-content-between"><span>(-) Cash Collected Now:</span> <span>₹${cashCollected.toFixed(2)}</span></div>
            <hr>
            <div class="d-flex justify-content-between fw-bold h5">
                <span>Today's Balance (to be added to dues):</span> 
                <span class="${dailyBalance >= 0 ? 'text-danger' : 'text-success'}">₹${dailyBalance.toFixed(2)}</span>
            </div>`;
    };

    // --- Event Listeners ---
    customerSelect.addEventListener('change', fetchOpenIssues);
    returnForm.addEventListener('input', e => {
        if (e.target.matches('.return-qty, .spoil-qty, #amountCollected')) {
            updateFinalSummary();
        }
    });

    returnForm.addEventListener('submit', async e => {
        e.preventDefault();
        if (!currentSettlementData) { alert("No open bills loaded to settle."); return; }
        
        const settlementData = {
            action: 'settle',
            customerId: customerSelect.value,
            date: dateInput.value,
            transactionIds: currentSettlementData.transactionIds,
            cashCollected: document.getElementById('amountCollected').value,
            notes: document.getElementById('notes').value,
            returnedItems: Array.from(document.querySelectorAll('.item-settle-row')).map(row => ({
                id: row.dataset.itemId,
                return_qty: row.querySelector('.return-qty').value,
                spoil_qty: row.querySelector('.spoil-qty').value,
                rate: row.dataset.rate
            }))
        };
        try {
            const response = await fetch('/api/transaction_api.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(settlementData) });
            const result = await response.json();
            if (result.success) {
                alert('Settlement successful!');
                window.location.href = '/dashboard.html';
            } else { throw new Error(result.message); }
        } catch (error) {
            messageContainer.textContent = 'Error: ' + error.message;
            messageContainer.className = 'alert alert-danger mt-4';
        }
    });

    // --- Initial Load ---
    dateInput.value = new Date().toISOString().slice(0, 10);
    fetchCustomers();
});