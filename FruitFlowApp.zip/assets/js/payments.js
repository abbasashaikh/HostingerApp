document.addEventListener('DOMContentLoaded', () => {
    const customerSelect = document.getElementById('customerSelect');
    const paymentForm = document.getElementById('paymentForm');
    const messageDiv = document.getElementById('payment-message');
    const dateInput = document.getElementById('paymentDate');

    dateInput.value = new Date().toISOString().slice(0, 10);

    const fetchCustomers = async () => {
        try {
            const response = await fetch('/api/customer_api.php?action=get_all');
            const result = await response.json();
            if (result.success) {
                customerSelect.innerHTML = '<option value="" selected disabled>Select a customer...</option>';
                result.data.forEach(c => {
                    customerSelect.innerHTML += `<option value="${c.id}">${c.name} (Due: ₹${c.total_dues})</option>`;
                });
            }
        } catch (error) { console.error('Error fetching customers:', error); }
    };

    paymentForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const submitButton = paymentForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.innerHTML = 'Recording...';
        messageDiv.innerHTML = '';
        
        const paymentData = {
            action: 'record_payment',
            customerId: document.getElementById('customerSelect').value,
            amount: document.getElementById('paymentAmount').value,
            payment_date: document.getElementById('paymentDate').value,
            notes: document.getElementById('paymentNotes').value
        };

        try {
            const response = await fetch('/api/payment_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(paymentData)
            });
            const result = await response.json();
            if (result.success) {
                messageDiv.innerHTML = `<div class="alert alert-success">${result.message}</div>`;
                paymentForm.reset();
                dateInput.value = new Date().toISOString().slice(0, 10);
                fetchCustomers(); // Refresh dropdown with new due amounts
            } else {
                throw new Error(result.message);
            }
        } catch (error) {
            messageDiv.innerHTML = `<div class="alert alert-danger">${error.message}</div>`;
        } finally {
            submitButton.disabled = false;
            submitButton.textContent = 'Record Payment';
        }
    });
    
    fetchCustomers();
});