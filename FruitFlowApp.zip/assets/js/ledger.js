document.addEventListener('DOMContentLoaded', () => {
    const ledgerTitle = document.getElementById('ledger-title');
    const ledgerTableBody = document.getElementById('ledger-table');
    const startDateInput = document.getElementById('startDate');
    const endDateInput = document.getElementById('endDate');
    const filterBtn = document.getElementById('filterBtn');

    const urlParams = new URLSearchParams(window.location.search);
    const customerId = urlParams.get('customerId');

    if (!customerId) {
        if(ledgerTitle) ledgerTitle.textContent = 'No Customer Selected';
        if(ledgerTableBody) ledgerTableBody.innerHTML = '<tr><td colspan="5" class="text-center">Please select a customer from the Manage Customers page.</td></tr>';
        return;
    }
    
    const fetchLedger = async () => {
        const startDate = startDateInput.value;
        const endDate = endDateInput.value;
        
        let apiUrl = `/api/transaction_api.php?action=get_ledger&customerId=${customerId}`;
        if(startDate) apiUrl += `&startDate=${startDate}`;
        if(endDate) apiUrl += `&endDate=${endDate}`;
        
        ledgerTableBody.innerHTML = '<tr><td colspan="5" class="text-center">Loading ledger...</td></tr>';
        try {
            const response = await fetch(apiUrl);
            const result = await response.json();

            if (result.success) {
                ledgerTitle.textContent = `${result.customerName}'s Ledger`;
                renderLedger(result.data);
            } else {
                throw new Error(result.message);
            }
        } catch (error) {
            ledgerTableBody.innerHTML = `<tr><td colspan="5" class="text-center text-danger">Failed to load ledger: ${error.message}</td></tr>`;
        }
    };
    
    const renderLedger = (entries) => {
        ledgerTableBody.innerHTML = '';
        if (entries.length === 0) {
            ledgerTableBody.innerHTML = '<tr><td colspan="5" class="text-center">No transactions found for this period.</td></tr>';
            return;
        }

        let balance = 0;
        entries.forEach(entry => {
            balance += parseFloat(entry.debit) - parseFloat(entry.credit);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${new Date(entry.date + 'T00:00:00').toLocaleDateString('en-IN', {day: '2-digit', month: 'short', year: 'numeric'})}</td>
                <td>${entry.description}</td>
                <td class="text-danger">${parseFloat(entry.debit) > 0 ? '₹' + parseFloat(entry.debit).toFixed(2) : '-'}</td>
                <td class="text-success">${parseFloat(entry.credit) > 0 ? '₹' + parseFloat(entry.credit).toFixed(2) : '-'}</td>
                <td class="fw-bold">₹${balance.toFixed(2)}</td>
            `;
            ledgerTableBody.appendChild(row);
        });
    };

    filterBtn.addEventListener('click', fetchLedger);

    // Set default dates for the last 30 days
    const today = new Date();
    const thirtyDaysAgo = new Date(new Date().setDate(today.getDate() - 30));
    endDateInput.value = today.toISOString().slice(0,10);
    startDateInput.value = thirtyDaysAgo.toISOString().slice(0,10);

    // Initial load
    fetchLedger();
});