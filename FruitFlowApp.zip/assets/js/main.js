document.addEventListener("DOMContentLoaded", function() {
    // 1. Auth Guard: Redirect to login if user data is not in sessionStorage
    const user = JSON.parse(sessionStorage.getItem('user'));
    if (!user && !window.location.pathname.endsWith('index.html') && window.location.pathname !== '/') {
        window.location.href = '/index.html';
        return; // Stop further execution on the page
    }

    const sidebarContainer = document.getElementById('sidebar');
    if (sidebarContainer) {
        const currentPage = window.location.pathname;
        const isAdmin = user && user.role === 'admin';
        
        // HIGHLIGHT: Rewritten sidebar structure for correct layout
        sidebarContainer.innerHTML = `
            <div class="sidebar-header">
                <h3 class="nav-brand text-white h4">FruitLeger</h3>
            </div>
            <div class="sidebar-content">
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link ${currentPage.includes('dashboard') ? 'active' : ''}" href="/dashboard.html"><i class="bi bi-grid-1x2-fill"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link ${currentPage.includes('issue') ? 'active' : ''}" href="/issue.html"><i class="bi bi-arrow-up-right-circle-fill"></i> Issue / Sell</a></li>
                    <li class="nav-item"><a class="nav-link ${currentPage.includes('return') ? 'active' : ''}" href="/return.html"><i class="bi bi-box-arrow-in-down-left"></i> Returns & Payments</a></li>
                    <li class="nav-item"><a class="nav-link ${currentPage.includes('payments') ? 'active' : ''}" href="/payments.html"><i class="bi bi-wallet2"></i> Record Payment</a></li>
                    <hr class="text-white-50">
                    <h6 class="text-white-50 ps-3 text-uppercase small">Manage</h6>
                    <li class="nav-item"><a class="nav-link ${currentPage.includes('fruits') ? 'active' : ''}" href="/fruits.html"><i class="bi bi-apple"></i> Fruits & Stock</a></li>
                    <li class="nav-item"><a class="nav-link ${currentPage.includes('customers') ? 'active' : ''}" href="/customers.html"><i class="bi bi-people-fill"></i> Customers</a></li>
                    ${isAdmin ? `<li class="nav-item"><a class="nav-link ${currentPage.includes('users') ? 'active' : ''}" href="/users.html"><i class="bi bi-person-badge-fill"></i> Manage Users</a></li>` : ''}
                </ul>
            </div>
            <div class="sidebar-footer">
                <hr class="text-white-50">
                <a id="logoutBtn" class="nav-link" href="#">
                    <i class="bi bi-box-arrow-left"></i> Logout (${user?.username || ''})
                </a>
            </div>
        `;
        
        // HIGHLIGHT: Logic to add user welcome message to the top bar
        const topBar = document.querySelector('.top-bar');
        if (topBar && user) {
            // Check if welcome message already exists to avoid duplication
            if (!topBar.querySelector('.welcome-message')) {
                const userDisplay = document.createElement('div');
                userDisplay.className = 'welcome-message';
                userDisplay.innerHTML = `Welcome, <strong>${user.username}</strong>`;
                // Prepend to put it on the left
                topBar.prepend(userDisplay);
            }
        }
        
        document.getElementById('logoutBtn').addEventListener('click', (e) => {
            e.preventDefault();
            sessionStorage.removeItem('user');
            window.location.href = '/index.html';
        });

        // Mobile sidebar toggle logic
        const hamburgerBtn = document.getElementById('hamburger-btn');
        const sidebar = document.getElementById('sidebar');
        const backdrop = document.getElementById('sidebar-backdrop');
        const toggleSidebar = () => {
            sidebar.classList.toggle('active');
            backdrop.classList.toggle('active');
        };
        if (hamburgerBtn && backdrop) {
            hamburgerBtn.addEventListener('click', toggleSidebar);
            backdrop.addEventListener('click', toggleSidebar);
        }
    }
});