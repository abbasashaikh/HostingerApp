document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Element References ---
    const customerModalEl = document.getElementById('customerModal');
    const customerModal = new bootstrap.Modal(customerModalEl);
    const customerForm = document.getElementById('customerForm');
    const customerModalLabel = document.getElementById('customerModalLabel');
    const customersTableBody = document.getElementById('customers-table');
    const addCustomerBtn = document.getElementById('addCustomerBtn');
    
    // --- API Call Functions ---

    /**
     * Fetches all customers from the backend and triggers rendering.
     */
    const fetchCustomers = async () => {
        try {
            const response = await fetch('/api/customer_api.php?action=get_all');
            const result = await response.json();
            if (result.success) {
                renderCustomers(result.data);
            } else {
                customersTableBody.innerHTML = `<tr><td colspan="6" class="text-center text-danger">${result.message}</td></tr>`;
            }
        } catch (error) {
            customersTableBody.innerHTML = `<tr><td colspan="6" class="text-center text-danger">Failed to load data. Please check API connection.</td></tr>`;
        }
    };

    /**
     * Sends data to the backend to create or update a customer.
     * @param {object} customerData - The customer data from the form.
     */
    const saveCustomer = async (customerData) => {
        try {
            const response = await fetch('/api/customer_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(customerData)
            });
            const result = await response.json();
            if (result.success) {
                customerModal.hide(); // Close the modal on success
                fetchCustomers(); // Refresh the table with the new data
            } else {
                alert('Error: ' + result.message);
            }
        } catch (error) {
            alert('A network error occurred while saving the customer.');
        }
    };

    // --- DOM Rendering ---

    /**
     * Renders the customer data into the main table.
     * @param {Array} customers - An array of customer objects.
     */
    const renderCustomers = (customers) => {
        customersTableBody.innerHTML = '';
        if (customers.length === 0) {
            customersTableBody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No customers found. Click "Add New Customer" to start.</td></tr>';
            return;
        }
        customers.forEach(customer => {
            const dues = parseFloat(customer.total_dues).toFixed(2);
            const duesClass = parseFloat(customer.total_dues) > 0 ? 'text-danger fw-bold' : '';
            
            const row = `
                <tr>
                    <td><a href="/ledger.html?customerId=${customer.id}" class="fw-bold text-decoration-none">${customer.name}</a></td>
                    <td><span class="badge bg-info">${customer.type}</span></td>
                    <td>${customer.phone}</td>
                    <td><span class="badge bg-${customer.status === 'active' ? 'success' : 'secondary'} text-capitalize">${customer.status}</span></td>
                    <td class="text-end ${duesClass}">₹${dues}</td>
                    <td>
                        <button class="btn btn-sm btn-info edit-btn" data-id="${customer.id}"><i class="bi bi-pencil-fill"></i> Edit</button>
                    </td>
                </tr>
            `;
            customersTableBody.insertAdjacentHTML('beforeend', row);
        });
    };
    
    // --- Event Listeners ---

    // When "Add New Customer" is clicked, clear the form for a new entry.
    addCustomerBtn.addEventListener('click', () => {
        customerModalLabel.textContent = 'Add New Customer';
        customerForm.reset();
        document.getElementById('customerId').value = '';
    });

    // Handle the form submission for both creating and updating customers.
    customerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const customerData = {
            // Check if there's an ID to determine if it's an update or create action
            action: document.getElementById('customerId').value ? 'update' : 'create',
            id: document.getElementById('customerId').value,
            name: document.getElementById('customerName').value,
            phone: document.getElementById('customerPhone').value,
            type: document.getElementById('customerType').value,
            address: document.getElementById('customerAddress').value,
            status: document.getElementById('customerStatus').value,
        };
        saveCustomer(customerData);
    });

    // Use event delegation on the table body to handle clicks on future "Edit" buttons.
    customersTableBody.addEventListener('click', async (e) => {
        const editButton = e.target.closest('.edit-btn');
        if (editButton) {
            const id = editButton.dataset.id;
            try {
                const response = await fetch(`/api/customer_api.php?action=get_one&id=${id}`);
                const result = await response.json();
                if (result.success) {
                    const customer = result.data;
                    // Populate the modal form with the fetched customer data
                    document.getElementById('customerId').value = customer.id;
                    document.getElementById('customerName').value = customer.name;
                    document.getElementById('customerPhone').value = customer.phone;
                    document.getElementById('customerType').value = customer.type;
                    document.getElementById('customerAddress').value = customer.address;
                    document.getElementById('customerStatus').value = customer.status;
                    customerModalLabel.textContent = 'Edit Customer';
                    customerModal.show();
                } else {
                    alert('Error fetching customer data.');
                }
            } catch (error) {
                alert('An error occurred while fetching customer details.');
            }
        }
    });

    // --- Initial data load when the page is ready ---
    fetchCustomers();
});