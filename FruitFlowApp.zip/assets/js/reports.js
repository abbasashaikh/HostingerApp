document.addEventListener('DOMContentLoaded', () => {
    const reportTableBody = document.getElementById('dues-report-table');

    const fetchDuesReport = async () => {
        if (!reportTableBody) return;
        reportTableBody.innerHTML = '<tr><td colspan="4" class="text-center">Loading Report...</td></tr>';
        try {
            const response = await fetch('/api/transaction_api.php?action=get_dues_report');
            const result = await response.json();
            if (!result.success) throw new Error(result.message);
            
            renderReport(result.data);
        } catch (error) {
            reportTableBody.innerHTML = `<tr><td colspan="4" class="text-center text-danger">${error.message}</td></tr>`;
        }
    };

    const renderReport = (customers) => {
        reportTableBody.innerHTML = '';
        if (customers.length === 0) {
            reportTableBody.innerHTML = '<tr><td colspan="4" class="text-center">No outstanding dues found.</td></tr>';
            return;
        }
        customers.forEach(customer => {
            reportTableBody.innerHTML += `
                <tr>
                    <td><a href="/ledger.html?customerId=${customer.id}">${customer.name}</a></td>
                    <td><span class="badge bg-info">${customer.type}</span></td>
                    <td>${customer.phone}</td>
                    <td class="text-end text-danger fw-bold">₹${parseFloat(customer.total_dues).toFixed(2)}</td>
                </tr>
            `;
        });
    };

    fetchDuesReport();
});