document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Element References ---
    const issueForm = document.getElementById('issueForm');
    if (!issueForm) return; // Stop if not on the issue page

    const customerSelect = document.getElementById('customerSelect');
    const dateInput = document.getElementById('issueDate');
    const itemsContainer = document.getElementById('items-to-issue-container');
    const addItemBtn = document.getElementById('addItemRowBtn');

    // --- State Variables ---
    let fruits = [];
    let dailyRates = {}; // This will store rates like {"1-Hawker-A": 150}

    // --- Initial Setup ---
    // Set date to today by default for convenience
    dateInput.value = new Date().toISOString().slice(0, 10);

    // --- API Calls ---
    /**
     * Fetches all necessary data (customers, fruits, today's rates) to initialize the form.
     */
    const fetchInitialData = async () => {
        try {
            // Use Promise.all to fetch data in parallel for better performance
            const [customersRes, fruitsRes, ratesRes] = await Promise.all([
                fetch('/api/customer_api.php?action=get_all'),
                fetch('/api/fruit_api.php?action=get_all'),
                fetch(`/api/rate_api.php?action=get_rates&date=${dateInput.value}`)
            ]);

            const customersResult = await customersRes.json();
            const fruitsResult = await fruitsRes.json();
            const ratesResult = await ratesRes.json();

            // Populate the customer dropdown
            if (customersResult.success) {
                customerSelect.innerHTML = '<option value="" selected disabled>Select Customer...</option>';
                customersResult.data.forEach(c => {
                    // Store the customer type in a data attribute for easy access
                    customerSelect.innerHTML += `<option value="${c.id}" data-type="${c.type}">${c.name} (${c.type})</option>`;
                });
            }

            // Store fruits and rates data in global state for this page
            if (fruitsResult.success) fruits = fruitsResult.data;
            if (ratesResult.success) dailyRates = ratesResult.data;

        } catch (error) {
            alert('Failed to load initial data for the form. Please check your connection and refresh.');
            console.error('Initial Data Fetch Error:', error);
        }
    };

    /**
     * Creates a new HTML row for adding a fruit item to the transaction.
     */
    const createItemRow = () => {
        const row = document.createElement('div');
        row.className = 'row g-3 mb-3 align-items-center item-row';
        
        let fruitOptions = fruits.map(f => `<option value="${f.id}">${f.name} (${f.unit})</option>`).join('');
        
        row.innerHTML = `
            <div class="col-md-5">
                <select class="form-select item-select" required>
                    <option value="" selected disabled>Select Fruit...</option>
                    ${fruitOptions}
                </select>
            </div>
            <div class="col-md-2">
                <select class="form-select grade-select" required>
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                </select>
            </div>
            <div class="col-md-2">
                <input type="number" class="form-control quantity-input" placeholder="Quantity" required step="0.01" min="0">
            </div>
            <div class="col-md-2">
                <div class="input-group">
                    <span class="input-group-text">₹</span>
                    <input type="number" class="form-control rate-input" placeholder="Rate" required step="0.01" min="0">
                </div>
            </div>
            <div class="col-md-1 text-end">
                <button type="button" class="btn btn-danger btn-sm remove-item-btn" aria-label="Remove Item">×</button>
            </div>
        `;
        itemsContainer.appendChild(row);
    };

    /**
     * Updates the rate automatically when fruit, grade, or customer type changes.
     */
    const updateRateForRow = (row) => {
        const customerType = customerSelect.options[customerSelect.selectedIndex]?.dataset.type;
        const fruitId = row.querySelector('.item-select').value;
        const grade = row.querySelector('.grade-select').value;

        if (fruitId && customerType && grade) {
            // Construct the key to look up the rate, e.g., "1-Hawker-A"
            const rateKey = `${fruitId}-${customerType}-${grade}`;
            const rateInput = row.querySelector('.rate-input');
            // Set the rate from our fetched data, or 0 if not found
            rateInput.value = dailyRates[rateKey] || 0;
        }
    };

    // --- Event Listeners ---

    // When the customer selection changes, update all item rows with the correct rates
    customerSelect.addEventListener('change', () => {
        document.querySelectorAll('.item-row').forEach(row => {
            updateRateForRow(row);
        });
    });

    // Use event delegation on the container for dynamically added rows
    itemsContainer.addEventListener('change', e => {
        if (e.target.matches('.item-select, .grade-select')) {
            const row = e.target.closest('.item-row');
            updateRateForRow(row);
        }
    });

    itemsContainer.addEventListener('click', e => {
        if (e.target.classList.contains('remove-item-btn')) {
            e.target.closest('.item-row').remove();
        }
    });
    
    addItemBtn.addEventListener('click', createItemRow);
    
    issueForm.addEventListener('submit', async e => {
        e.preventDefault();
        const submitButton = issueForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Submitting...`;

        // We build a FormData object because it's simpler for PHP to read $_POST
        const formData = new FormData();
        formData.append('action', 'distribute');
        formData.append('customerId', customerSelect.value);
        formData.append('transactionDate', dateInput.value);
        formData.append('amountPaid', document.getElementById('amountPaid').value);
        formData.append('notes', document.getElementById('notes').value);

        // PHP's $_POST can't handle nested arrays well from FormData directly.
        // So, we collect the item data into a JS array...
        const itemsData = Array.from(document.querySelectorAll('.item-row')).map(row => ({
            fruitId: row.querySelector('.item-select').value,
            grade: row.querySelector('.grade-select').value,
            quantity: row.querySelector('.quantity-input').value,
            rate: row.querySelector('.rate-input').value
        }));
        // ...and then stringify it. The PHP script will decode this string.
        formData.append('items', JSON.stringify(itemsData));
        
        try {
            const response = await fetch('/api/transaction_api.php', {
                method: 'POST',
                body: formData // Send the FormData object
            });
            const result = await response.json();
            if(result.success) {
                alert('Transaction recorded successfully!');
                window.location.href = '/dashboard.html';
            } else { 
                throw new Error(result.message);
            }
        } catch (error) { 
            alert('An error occurred: ' + error.message);
            console.error('Submission Error:', error);
        } finally {
            submitButton.disabled = false;
            submitButton.innerHTML = 'Submit Transaction';
        }
    });

    // --- Initial Load ---
    fetchInitialData().then(() => {
        // Add one item row by default after all data is loaded
        createItemRow();
    });
});