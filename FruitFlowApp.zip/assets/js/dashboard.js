document.addEventListener('DOMContentLoaded', () => {
    const kpiContainer = document.getElementById('kpi-cards-container');
    const duesTableBody = document.getElementById('dues-report-table');
    const inventoryTableBody = document.getElementById('inventory-report-table');
    const recalculateDuesBtn = document.getElementById('recalculateDuesBtn');
    const user = JSON.parse(sessionStorage.getItem('user'));

    const formatCurrency = (value) => `₹${parseFloat(value).toFixed(2)}`;

    const renderKpiCards = (stats) => {
        if(!kpiContainer) return;
        kpiContainer.innerHTML = `
            <div class="col-md-6 col-lg-3"><div class="card kpi-card bg-danger"><div class="card-body"><div class="kpi-value">${formatCurrency(stats.total_outstanding)}</div><div class="kpi-label">Total Outstanding Dues</div></div></div></div>
            <div class="col-md-6 col-lg-3"><div class="card kpi-card bg-warning"><div class="card-body"><div class="kpi-value">${stats.customers_with_dues}</div><div class="kpi-label">Customers with Dues</div></div></div></div>
            <div class="col-md-6 col-lg-3"><div class="card kpi-card bg-success"><div class="card-body"><div class="kpi-value">${formatCurrency(stats.todays_sales)}</div><div class="kpi-label">Today's Sales</div></div></div></div>
            <div class="col-md-6 col-lg-3"><div class="card kpi-card bg-info"><div class="card-body"><div class="kpi-value">${stats.low_stock_items}</div><div class="kpi-label">Low Stock Items</div></div></div></div>
        `;
    };

    const renderDuesReport = (customers) => {
        if(!duesTableBody) return;
        duesTableBody.innerHTML = '';
        if (customers.length === 0) {
            duesTableBody.innerHTML = `<tr><td colspan="4" class="text-center text-muted">No outstanding dues found.</td></tr>`;
            return;
        }
        customers.forEach(customer => {
            duesTableBody.innerHTML += `<tr><td><a href="/ledger.html?customerId=${customer.id}">${customer.name}</a></td><td><span class="badge bg-secondary">${customer.type}</span></td><td>${customer.phone}</td><td class="text-end fw-bold">${formatCurrency(customer.total_dues)}</td></tr>`;
        });
    };
    
    const renderInventoryReport = (inventory) => {
        if(!inventoryTableBody) return;
        inventoryTableBody.innerHTML = '';
        if (inventory.length === 0) {
            inventoryTableBody.innerHTML = `<tr><td colspan="3" class="text-center text-muted">No inventory data. Add stock to begin.</td></tr>`;
            return;
        }
        inventory.forEach(item => {
            const stockClass = parseFloat(item.remaining_stock) <= parseFloat(item.low_stock_threshold) ? 'text-danger fw-bold' : '';
            inventoryTableBody.innerHTML += `<tr><td>${item.name}</td><td>${item.unit}</td><td class="text-end ${stockClass}">${parseFloat(item.remaining_stock).toFixed(2)}</td></tr>`;
        });
    };

    const loadDashboardData = async () => {
        try {
            const [statsRes, duesRes, inventoryRes] = await Promise.all([
                fetch('/api/report_api.php?action=get_dashboard_stats'),
                fetch('/api/report_api.php?action=get_dues_report'),
                fetch('/api/report_api.php?action=get_inventory_report')
            ]);
            const statsResult = await statsRes.json();
            const duesResult = await duesRes.json();
            const inventoryResult = await inventoryRes.json();

            if (statsResult.success) renderKpiCards(statsResult.data);
            if (duesResult.success) renderDuesReport(duesResult.data);
            if (inventoryResult.success) renderInventoryReport(inventoryResult.data);

        } catch (error) {
            console.error("Failed to load dashboard data:", error);
            if(duesTableBody) duesTableBody.innerHTML = `<tr><td colspan="4" class="text-center text-danger">Failed to load reports.</td></tr>`;
            if(inventoryTableBody) inventoryTableBody.innerHTML = `<tr><td colspan="3" class="text-center text-danger">Failed to load reports.</td></tr>`;
        }
    };
    
    if (recalculateDuesBtn && user && user.role === 'admin') {
        recalculateDuesBtn.classList.remove('d-none');
        recalculateDuesBtn.addEventListener('click', async () => {
            if (!confirm('This will reset and recalculate all customer dues based on transaction history. This action should only be used to fix data inconsistencies. Continue?')) return;
            recalculateDuesBtn.disabled = true;
            recalculateDuesBtn.innerHTML = `<span class="spinner-border spinner-border-sm"></span> Syncing...`;
            try {
                const response = await fetch('/api/report_api.php?action=recalculate_dues', { method: 'POST' });
                const result = await response.json();
                if (result.success) {
                    alert(result.message);
                    loadDashboardData(); 
                } else { throw new Error(result.message); }
            } catch (error) {
                alert('Error during recalculation: ' + error.message);
            } finally {
                recalculateDuesBtn.disabled = false;
                recalculateDuesBtn.innerHTML = `<i class="bi bi-arrow-repeat"></i> Recalculate All Dues`;
            }
        });
    }
    
    loadDashboardData();
});