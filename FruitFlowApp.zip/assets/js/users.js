document.addEventListener('DOMContentLoaded', () => {
    const userModalEl = document.getElementById('userModal');
    const userModal = new bootstrap.Modal(userModalEl);
    const userForm = document.getElementById('userForm');
    const userModalLabel = document.getElementById('userModalLabel');
    const usersTableBody = document.getElementById('users-table');
    const addUserBtn = document.getElementById('addUserBtn');
    let allUsers = [];
    const loggedInUser = JSON.parse(sessionStorage.getItem('user'));

    const fetchUsers = async () => {
        usersTableBody.innerHTML = '<tr><td colspan="6" class="text-center">Loading users...</td></tr>';
        try {
            const response = await fetch('/api/user_api.php?action=get_all');
            const result = await response.json();
            if (result.success) {
                allUsers = result.data;
                renderUsers(allUsers);
            } else { throw new Error(result.message); }
        } catch (error) {
            usersTableBody.innerHTML = `<tr><td colspan="6" class="text-center text-danger">Failed to load users: ${error.message}</td></tr>`;
        }
    };

    const renderUsers = (users) => {
        usersTableBody.innerHTML = '';
        if (users.length === 0) {
            usersTableBody.innerHTML = '<tr><td colspan="6" class="text-center">No users found.</td></tr>';
            return;
        }
        users.forEach(user => {
            const isCurrentUser = user.id == loggedInUser.id;
            const deactivateBtn = isCurrentUser ? 
                `<button class="btn btn-sm btn-secondary" disabled title="Cannot change your own status">Deactivate</button>` :
                `<button class="btn btn-sm btn-${user.status === 'active' ? 'danger' : 'success'} deactivate-btn" data-id="${user.id}" data-status="${user.status}">
                    ${user.status === 'active' ? 'Deactivate' : 'Activate'}
                </button>`;
            
            const row = `
                <tr>
                    <td>${user.name || 'N/A'}</td>
                    <td>${user.username}</td>
                    <td>${user.phone || 'N/A'}</td>
                    <td><span class="badge bg-secondary text-capitalize">${user.role}</span></td>
                    <td><span class="badge bg-${user.status === 'active' ? 'success' : 'danger'} text-capitalize">${user.status}</span></td>
                    <td>
                        <button class="btn btn-sm btn-info edit-btn" data-id="${user.id}">Edit</button>
                        ${deactivateBtn}
                    </td>
                </tr>
            `;
            usersTableBody.insertAdjacentHTML('beforeend', row);
        });
    };

    addUserBtn.addEventListener('click', () => {
        userModalLabel.textContent = 'Add New User';
        userForm.reset();
        document.getElementById('userId').value = '';
        document.getElementById('password').required = true;
        document.getElementById('password').placeholder = "Min. 6 characters";
    });

    usersTableBody.addEventListener('click', (e) => {
        const target = e.target;
        if (target.classList.contains('edit-btn')) {
            const userId = target.dataset.id;
            const user = allUsers.find(u => u.id == userId);
            if (user) {
                userModalLabel.textContent = 'Edit User';
                document.getElementById('userId').value = user.id;
                document.getElementById('name').value = user.name;
                document.getElementById('username').value = user.username;
                document.getElementById('phone').value = user.phone;
                document.getElementById('role').value = user.role;
                document.getElementById('status').value = user.status;
                document.getElementById('password').value = '';
                document.getElementById('password').required = false;
                document.getElementById('password').placeholder = "Leave blank to keep unchanged";
                userModal.show();
            }
        } else if (target.classList.contains('deactivate-btn')) {
            const userId = target.dataset.id;
            const currentStatus = target.dataset.status;
            const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
            if (confirm(`Are you sure you want to ${newStatus === 'active' ? 'activate' : 'deactivate'} this user?`)) {
                const user = allUsers.find(u => u.id == userId);
                const updatedData = { ...user, action: 'update', status: newStatus, password: '' }; // Send empty password
                saveUser(updatedData);
            }
        }
    });

    userForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const userData = {
            action: document.getElementById('userId').value ? 'update' : 'create',
            id: document.getElementById('userId').value,
            name: document.getElementById('name').value,
            username: document.getElementById('username').value,
            phone: document.getElementById('phone').value,
            password: document.getElementById('password').value,
            role: document.getElementById('role').value,
            status: document.getElementById('status').value,
        };
        saveUser(userData);
    });

    const saveUser = async (userData) => {
        try {
            const response = await fetch('/api/user_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
            const result = await response.json();
            if (result.success) {
                userModal.hide();
                fetchUsers();
            } else { alert('Error: ' .concat(result.message)); }
        } catch (error) { alert('An error occurred while saving the user.'); }
    };

    fetchUsers();
});