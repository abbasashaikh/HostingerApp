document.addEventListener('DOMContentLoaded', () => {
    const fruitModalEl = document.getElementById('fruitModal');
    const fruitModal = new bootstrap.Modal(fruitModalEl);
    const fruitForm = document.getElementById('fruitForm');
    const fruitModalLabel = document.getElementById('fruitModalLabel');
    const fruitsTableBody = document.getElementById('fruits-table');
    const addNewFruitBtn = document.getElementById('addNewFruitBtn');
    
    const purchaseForm = document.getElementById('purchaseForm');
    const purchaseFruitSelect = document.getElementById('purchaseFruit');
    const purchasesTableBody = document.getElementById('purchases-table');

    let allFruits = [];

    const fetchData = async () => {
        try {
            const [fruitsRes, purchasesRes] = await Promise.all([
                fetch('/api/fruit_api.php?action=get_all'),
                fetch('/api/fruit_api.php?action=get_purchases')
            ]);
            const fruitsResult = await fruitsRes.json();
            const purchasesResult = await purchasesRes.json();

            if (fruitsResult.success) {
                allFruits = fruitsResult.data;
                renderFruits(allFruits);
                populatePurchaseDropdown(allFruits);
            } else { alert('Failed to load fruits.'); }
            if (purchasesResult.success) {
                renderPurchases(purchasesResult.data);
            }
        } catch (error) { console.error('Error fetching data:', error); }
    };
    
    const renderFruits = (fruits) => {
        fruitsTableBody.innerHTML = '';
        if (fruits.length === 0) {
            fruitsTableBody.innerHTML = '<tr><td colspan="4" class="text-center">No fruits found.</td></tr>';
            return;
        }
        fruits.forEach(fruit => {
            fruitsTableBody.innerHTML += `<tr><td>${fruit.name}</td><td>${fruit.unit}</td><td>${fruit.low_stock_threshold}</td><td><button class="btn btn-sm btn-info edit-fruit-btn" data-id="${fruit.id}">Edit</button></td></tr>`;
        });
    };
    
    const renderPurchases = (purchases) => {
        purchasesTableBody.innerHTML = '';
        if (purchases.length === 0) {
            purchasesTableBody.innerHTML = '<tr><td colspan="6" class="text-center">No recent stock purchases.</td></tr>';
            return;
        }
        purchases.forEach(p => {
            purchasesTableBody.innerHTML += `<tr><td>${new Date(p.purchase_date + 'T00:00:00').toLocaleDateString('en-IN')}</td><td>${p.fruit_name}</td><td>${p.quantity} ${p.unit}</td><td>${p.grade}</td><td>₹${p.purchase_price}</td><td>${p.supplier_name || '-'}</td></tr>`;
        });
    };

    const populatePurchaseDropdown = (fruits) => {
        purchaseFruitSelect.innerHTML = '<option value="">Select Fruit...</option>';
        fruits.forEach(fruit => {
            purchaseFruitSelect.innerHTML += `<option value="${fruit.id}">${fruit.name}</option>`;
        });
    };

    addNewFruitBtn.addEventListener('click', () => {
        fruitModalLabel.textContent = 'Add New Fruit';
        fruitForm.reset();
        document.getElementById('fruitId').value = '';
    });
    
    fruitsTableBody.addEventListener('click', (e) => {
        if (e.target.classList.contains('edit-fruit-btn')) {
            const fruitId = e.target.dataset.id;
            const fruit = allFruits.find(f => f.id == fruitId);
            if (fruit) {
                fruitModalLabel.textContent = 'Edit Fruit';
                document.getElementById('fruitId').value = fruit.id;
                document.getElementById('fruitName').value = fruit.name;
                document.getElementById('fruitUnit').value = fruit.unit;
                document.getElementById('lowStockThreshold').value = fruit.low_stock_threshold;
                fruitModal.show();
            }
        }
    });

    fruitForm.addEventListener('submit', async e => {
        e.preventDefault();
        const id = document.getElementById('fruitId').value;
        const fruitData = {
            action: id ? 'update' : 'create',
            id: id,
            name: document.getElementById('fruitName').value,
            unit: document.getElementById('fruitUnit').value,
            low_stock_threshold: document.getElementById('lowStockThreshold').value
        };
        const response = await fetch('/api/fruit_api.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(fruitData) });
        const result = await response.json();
        if (result.success) {
            fruitModal.hide();
            fetchData();
        } else { alert('Error: ' .concat(result.message)); }
    });
    
    purchaseForm.addEventListener('submit', async e => {
        e.preventDefault();
        const purchaseData = {
            action: 'add_stock',
            fruit_id: document.getElementById('purchaseFruit').value,
            quantity: document.getElementById('purchaseQty').value,
            grade: document.getElementById('purchaseGrade').value,
            purchase_date: document.getElementById('purchaseDate').value,
            purchase_price: document.getElementById('purchasePrice').value,
            supplier_name: document.getElementById('supplierName').value
        };
        const response = await fetch('/api/fruit_api.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(purchaseData) });
        const result = await response.json();
        if (result.success) {
            alert('Stock added successfully!');
            purchaseForm.reset();
            document.getElementById('purchaseDate').value = new Date().toISOString().slice(0,10);
            fetchData();
        } else { alert('Error: ' .concat(result.message)); }
    });

    document.getElementById('purchaseDate').value = new Date().toISOString().slice(0,10);
    fetchData();
});