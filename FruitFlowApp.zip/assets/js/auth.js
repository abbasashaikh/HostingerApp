document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');

    // If the user is already logged in, redirect them to the dashboard.
    if (sessionStorage.getItem('user')) {
        window.location.href = '/dashboard.html';
    }

    if(loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const messageDiv = document.getElementById('login-message');
            const submitButton = loginForm.querySelector('button[type="submit"]');

            messageDiv.innerHTML = '';
            submitButton.disabled = true;
            submitButton.textContent = 'Logging in...';

            try {
                const response = await fetch('/api/auth_api.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'login', username, password })
                });

                const result = await response.json();

                if (result.success) {
                    sessionStorage.setItem('user', JSON.stringify(result.data));
                    window.location.href = '/dashboard.html';
                } else {
                    // Display the specific error message from the server
                    messageDiv.innerHTML = `<div class="alert alert-danger">${result.message || 'An unknown error occurred.'}</div>`;
                }
            } catch (error) {
                // This catches network errors or if the response is not valid JSON
                messageDiv.innerHTML = `<div class="alert alert-danger">Network error. Please try again.</div>`;
                console.error('Login Fetch Error:', error);
            } finally {
                submitButton.disabled = false;
                submitButton.textContent = 'Login';
            }
        });
    }
});